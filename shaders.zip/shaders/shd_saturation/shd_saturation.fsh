//
// Desaturation effect
//
varying vec2 v_vTexcoord; // texture coordinates maybe
varying vec4 v_vColour; // colors or something

uniform float u_saturation; // 0 - completely unsaturated; 1 - no effect; <1 - oversaturation

void main() // hollow knight reference?????
{
	vec4 texColor = texture2D( gm_BaseTexture, v_vTexcoord ); // color of a pixel
	float gray = dot(texColor.rgb, vec3(0.299, 0.587, 0.114)); // rgb of a pixel turned into fully grayscale
	vec3 desaturation = mix(vec3(gray), texColor.rgb, u_saturation); // mixing fully grayscaled and original rgb using saturation value
    gl_FragColor = v_vColour * vec4(desaturation, texColor.a); // output pixel, with retained alpha value
}
