// Inherit the parent event
event_inherited();

button_description = game_mode