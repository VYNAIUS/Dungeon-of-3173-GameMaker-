if button_pressed
{
	global.game_original_mode = game_mode
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	var easy = instance_create_depth(xcoord - 192, ycoord - 128, depth - 11, obj_button_difficulty_parent)
	var medium = instance_create_depth(xcoord + 192, ycoord - 128, depth - 11, obj_button_difficulty_parent)
	var hard = instance_create_depth(xcoord - 192, ycoord + 64, depth - 11, obj_button_difficulty_parent)
	var absurd = instance_create_depth(xcoord + 192, ycoord + 64, depth - 11, obj_button_difficulty_parent)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var text = instance_create_depth(xcoord, ycoord - 256, depth - 11, obj_text)
	text.text = "Pick the difficulty."
	text.scale = 0.25
	easy.button_text = "Easy"
	easy.difficulty = "easy"
	medium.button_text = "Medium"
	medium.difficulty = "medium"
	hard.button_text = "Hard"
	hard.difficulty = "hard"
	absurd.button_text = "Absurd"
	absurd.difficulty = "absurd"
	global.button_description = "none"
}
event_inherited()