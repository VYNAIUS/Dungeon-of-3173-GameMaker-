if not(instance_exists(obj_fight_death))
{
	scr_battle_spawn(obj_fight_death)
}