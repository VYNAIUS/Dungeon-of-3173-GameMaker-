event_inherited()
if is_splitted
{
	x = x_hover_position
	y = ystart
	is_immune = false
}
else
{
	if global.death_state != 1
	{
		is_immune = true
	}
	else if hp - total_dealt_damage < original_max_hp * 0.1
	{
		hp = round(original_max_hp * 0.1)
		total_dealt_damage = 0
	}
}