if global.death_state == 1
{
	if times_splitted > 0
	{
		animation_type = "idle"
		global.fighting_turn -= 1
	}
	else if sympathy < 1
	{
		if not(is_immune) and hp <= original_max_hp * 0.5
		{
			is_immune = true
			dialogue_place("Boat Person Battle: HP Too Low")
			animation_type = "idle"
			global.fighting_turn -= 1
		}
		else if global.fighting_turn < 9
		{
			animation_type = "fight"
			if global.fighting_turn == 1 and not(is_inside_array("Boat Person Battle: Tutorial 0", global.boatperson_told_dialog))
			{
				dialogue_place("Boat Person Battle: Tutorial 0")
				array_push(global.boatperson_told_dialog, "Boat Person Battle: Tutorial 0")
			}
			else if global.fighting_turn == 3 and not(is_inside_array("Boat Person Battle: Tutorial 1", global.boatperson_told_dialog))
			{
				dialogue_place("Boat Person Battle: Tutorial 1")
				array_push(global.boatperson_told_dialog, "Boat Person Battle: Tutorial 1")
			}
		}
		else if global.fighting_turn == 9 and not(is_inside_array("Boat Person Battle: Tutorial Almost", global.boatperson_told_dialog))
		{
			dialogue_place("Boat Person Battle: Tutorial Almost")
			array_push(global.boatperson_told_dialog, "Boat Person Battle: Tutorial Almost")
			animation_type = "idle"
		}
		else if global.fighting_turn < 13
		{
			if instance_exists(obj_fight_player) and not(obj_fight_player.death_played)
			{
				action_target = obj_fight_player.id
				animation_type = "soul_reap"
			}
			else
			{
				animation_type = "idle"
			}
		}
		else
		{
			dialogue_place("Boat Person Battle: Tutorial Done")
			animation_type = "none"
		}
	}
	else
	{
		animation_type = "idle"
		sympathy = -1
		sympathy_factor = 0
		crit_chance *= 2
		dmg *= 2
		dialogue_place("Boat Person Battle: Trick")
		global.fighting_turn -= 1
	}

	if stunned > 0
	{
		global.fighting_turn -= 1
	}
}
else
{
	if is_splitted
	{
		animation_type = "idle"
		sympathy = 0
	}
	else if sympathy < 1
	{
		animation_type = "fight"
	}
	else
	{
		animation_type = "idle"
		sympathy = -1
		sympathy_factor = 0
		crit_chance *= 2
		dmg *= 2
		dialogue_place("Boat Person Battle: Trick")
		global.fighting_turn -= 1
	}
}