event_inherited()
is_splitted = false
times_splitted = 0