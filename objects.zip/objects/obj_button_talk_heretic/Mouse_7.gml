if button_pressed
{
	var possible_dialogue = ["Heretic Talk: Altar", "Heretic Talk: Job", "Heretic Talk: Shopkeeper"]
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.heretic_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		if global.heretic_reputation == 1
		{
			confirmed_dialog = ["Heretic Talk: No Dialog Brin"]
		}
		else
		{
			confirmed_dialog = ["Heretic Talk: No Dialog"]
		}
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if not(is_inside_array(confirmed_dialog[random_index], ["Heretic Talk: No Dialog", "Heretic Talk: No Dialog Brin"]))
	{
		array_push(global.heretic_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()