if button_pressed
{
	scr_meta_save()
	global.is_map_transitioning = true
	global.is_paused = false
	global.current_ui_layer = 0
	global.transition_type = "main_menu"
	with (obj_settings_box)
	{
		event_user(0)
	}
	transition_to_quit_game()
}

event_inherited()