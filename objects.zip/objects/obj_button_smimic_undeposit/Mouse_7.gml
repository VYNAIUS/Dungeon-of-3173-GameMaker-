if button_pressed
{
	if global.smimic_money >= 10
	{
		global.player_money += 10
		global.smimic_money -= 10
	}
	else
	{
		global.player_money += global.smimic_money
		global.smimic_money = 0
	}
}
event_inherited()