if dialogue_progress == 0
{
	if original_max_hp * 0.95 > hp
	{
		dialogue_progress = 1
		dialogue_place("Change Battling: 95% HP")
	}
}
else if dialogue_progress == 1
{
	if original_max_hp * 0.3 > hp
	{
		dialogue_progress = 2
		dialogue_place("Change Battling: 30% HP")
	}
}

if summoned_units == 0
{
	if original_max_hp * 0.7 > hp
	{
		summoned_units = 0.5
		dialogue_place("Change Battling: Ask Help")
	}
}
else if summoned_units == 0.5
{
	if original_max_hp * 0.6 > hp
	{
		summoned_units = 1
		scr_battle_spawn(obj_fight_crystal_assasin)
		scr_battle_spawn(obj_fight_crystal_assasin)
		dialogue_place("Change Battling: Help Arrived")
	}
}
else if summoned_units == 1
{
	if instance_number(obj_fight_crystal_assasin) == 0
	{
		dialogue_place("Change Battling: Help Lost")
		summoned_units = 1.5
	}
}

if instance_number(obj_fight_crystal_assasin) > 0 and (mana_factor < 1.5 or (defense < 0 and dmg < original_dmg) or hp < max_hp * 0.75)
{
	animation_type = "mana_regen"
}
else if mana_factor > 0.1
{
	animation_type = "magic_fight"
}
else
{
	animation_type = "fight"
}