event_inherited()

if hp <= 0 and not(global.is_dialogue)
{
	if global.player_consume <= 0
	{
		dialogue_place("Change Battling: Defeated Cleanse")
	}
	else
	{
		if global.death_state != -2
		{
			dialogue_place("Change Battling: Defeated Consume")
		}
		else
		{
			dialogue_place("Change Battling: Defeated Consume & Death")
		}
	}
}
if mana_factor == original_mana_factor
{
	is_immune = true
}
else
{
	is_immune = false
}