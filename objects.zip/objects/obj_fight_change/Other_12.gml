if hp > max_hp * 0.5
{
	var randomthing = round(random(2))
	if randomthing == 0
	{
		audio_play_sound(snd_mana_hit_change_0, 0, false, 1)
	}
	else if randomthing == 1
	{
		audio_play_sound(snd_mana_hit_change_1, 0, false, 1)
	}
	else
	{
		audio_play_sound(snd_mana_hit_change_2, 0, false, 1)
	}
}
else
{
	audio_play_sound(snd_mana_hit_generic, 0, false, 1)
}