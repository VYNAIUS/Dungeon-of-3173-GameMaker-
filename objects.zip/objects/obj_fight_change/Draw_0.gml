shader_set(shd_saturation)
shader_set_uniform_f(shader_get_uniform(shd_saturation, "u_saturation"), mana_factor * 0.375 + 0.25)
event_inherited()