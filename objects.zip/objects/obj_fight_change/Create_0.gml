event_inherited()

dialogue_progress = 0
summoned_units = 0