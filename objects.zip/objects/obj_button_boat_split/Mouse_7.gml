if pressed_amount == 0
{
	dialogue_place("Boat Person Split Warning")
}
else
{
	if global.npc_song_played != undefined
	{
		audio_sound_gain(global.npc_song_played, 0, 1000)
	}
	dialogue_place("Boat Person Fight Split")
}
pressed_amount += 1
event_inherited()