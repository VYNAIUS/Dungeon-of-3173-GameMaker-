event_inherited()
pressed_amount = 0