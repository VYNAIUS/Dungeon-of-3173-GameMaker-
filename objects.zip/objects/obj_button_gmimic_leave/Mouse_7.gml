// Inherit the parent event
if button_pressed
{
	if global.gmimic_item_shown
	{
		dialogue_place("Golden Mimic Stop")
	}
	else
	{
		transition_to_map()
	}
}
event_inherited();