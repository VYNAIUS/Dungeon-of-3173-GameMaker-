event_inherited()
text = global.area_names[global.area_id]
text_color = global.area_map_colors[global.area_id]
fade_away = false
reset_fighting()

if global.game_mode == "story" and global.area_visited == 0 and array_length(global.saved_tiles) == 0
{
	dialogue_place("Cycle Story Start")
}
else if global.area_id == 5 and array_length(global.saved_tiles) == 0 and global.fear_encounters > 0
{
	dialogue_place("Fear Desert")
}
else if global.final_area and array_length(global.saved_tiles) == 0
{
	dialogue_place("Cycle Story Final Area")
}