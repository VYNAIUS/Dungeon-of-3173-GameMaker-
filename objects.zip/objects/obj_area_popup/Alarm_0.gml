fade_away = true
global.is_map_transitioning = true