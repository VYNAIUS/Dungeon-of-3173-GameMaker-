event_inherited()

if image_alpha == 0 and fade_away
{
	image_alpha = 0
	global.is_map_transitioning = false
	room_goto(rom_map)
}
else if image_alpha < 1 and image_alpha > 0.5
{
	if ((global.area_ambiance_played != undefined and (not(audio_is_playing(global.area_ambiance_played)) or audio_sound_get_gain(global.area_ambiance_played) == 0)) or (global.area_ambiance_played == undefined)) and
	((global.area_song_played != undefined and (not(audio_is_playing(global.area_song_played)) or audio_sound_get_gain(global.area_song_played) == 0)) or (global.area_song_played == undefined)) and
	((global.blizzard_ambiance_played != undefined and (not(audio_is_playing(global.blizzard_ambiance_played)) or audio_sound_get_gain(global.blizzard_ambiance_played) <= 0.5)) or (global.blizzard_ambiance_played == undefined)) and
	((global.rain_ambiance_played != undefined and (not(audio_is_playing(global.rain_ambiance_played)) or audio_sound_get_gain(global.rain_ambiance_played) <= 0.5)) or (global.rain_ambiance_played == undefined)) and
	((global.sandstorm_ambiance_played != undefined and (not(audio_is_playing(global.sandstorm_ambiance_played)) or audio_sound_get_gain(global.sandstorm_ambiance_played) <= 0.5)) or (global.sandstorm_ambiance_played == undefined))
	{
		audio_stop_all()
	}
}
else if image_alpha == 1
{
	if alarm[0] <= 0
	{
		alarm[0] = 120
	}
	for (var i = 0; i < global.level_ups_area_screen; i++)
	{
		instance_create_layer(random_range(200, 1166), random_range(100, 668), "Instances_UI", obj_text_level_up)
	}
	if global.level_ups_area_screen > 0
	{
		audio_play_sound(snd_level_up, 0, false)
	}
	global.level_ups_area_screen = 0
}