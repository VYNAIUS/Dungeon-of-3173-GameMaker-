if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	var inf = instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_mode_parent)
	var story = instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_mode_parent)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var text = instance_create_depth(xcoord, ycoord - 192, depth - 11, obj_text)
	inf.button_text = "Infinite"
	inf.game_mode = "infinite"
	story.button_text = "Story"
	story.game_mode = "story"
	text.text = "Choose game mode\nfor the run."
}
event_inherited()