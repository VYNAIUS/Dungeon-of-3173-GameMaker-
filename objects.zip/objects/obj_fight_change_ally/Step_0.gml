event_inherited()

if mana_factor == original_mana_factor
{
	is_immune = true
}
else
{
	is_immune = false
}

shadow_clone_cooldown -= 1
if shadow_clone_cooldown <= 0
{
	vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone_god_2)
	vfx.follower = id
	vfx.speed = 0.2
	vfx.direction = random_range(0, 360)
	shadow_clone_cooldown = 40 - (mana_factor * 15) 
}