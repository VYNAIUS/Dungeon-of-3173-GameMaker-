if mana_factor <= 0.8 or hp / original_max_hp < 0.5
{
	animation_type = "mana_regen"
}
else
{
	animation_type = "magic_fight"
}