if x < xstart and hspeed < 1
{
	hspeed += random_range(0.01, 0.05)	
}
else if hspeed > - 1
{
	hspeed -= random_range(0.01, 0.05)	
}
if y < ystart and vspeed < 1
{
	vspeed += random_range(0.01, 0.05)	
}
else if vspeed > - 1
{
	vspeed -= random_range(0.01, 0.05)	
}
if image_angle < 0 and angle_acceleration < 0.25
{
	angle_acceleration += random_range(0.01, 0.05)
}
else if angle_acceleration > - 0.25
{
	angle_acceleration -= random_range(0.01, 0.05)
}

shadow_clone_cooldown -= 1
if shadow_clone_cooldown <= 0
{
	vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone)
	vfx.follower = id
	vfx.speed = 1
	vfx.direction = random_range(0, 360)
	shadow_clone_cooldown = round(3 + instance_number(obj_fight_vf_shadowclone) / 200)
}

image_angle += angle_acceleration

if global.altar_choice == glyph_name
{
	image_xscale += 0.02
	image_yscale += 0.02
	image_alpha -= 0.01
	if image_alpha <= 0
	{instance_destroy()}
}
else if global.altar_choice != "none"
{
	image_xscale -= 0.01
	image_yscale -= 0.01
	image_alpha -= 0.025
	if image_alpha <= 0
	{instance_destroy()}
}

if global.is_map_transitioning
{
	image_alpha -= 0.05
}

draw_self()