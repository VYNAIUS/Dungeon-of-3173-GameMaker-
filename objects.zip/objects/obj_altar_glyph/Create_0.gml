hspeed = random_range(-0.5, 0.5)	
vspeed = random_range(-0.5, 0.5)
angle_acceleration = random_range(-0.25, 0.25)
shadow_clone_cooldown = 10