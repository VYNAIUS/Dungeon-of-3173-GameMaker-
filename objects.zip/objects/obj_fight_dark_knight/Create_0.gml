event_inherited()
special_attack_done = false