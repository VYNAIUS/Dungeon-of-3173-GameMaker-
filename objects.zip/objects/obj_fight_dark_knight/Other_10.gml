if random(1) > 0.5
{
	audio_play_sound(snd_hit_dark_knight_0, 0, false, 1, 0, random_range(0.95, 1.05))
}
else
{
	audio_play_sound(snd_hit_dark_knight_1, 0, false, 1, 0, random_range(0.95, 1.05))
}