lifegiver = scr_battle_spawn(obj_fight_lifegiver)
lifegiver.max_hp = round(lifegiver.max_hp * 0.75)
lifegiver.hp = lifegiver.max_hp