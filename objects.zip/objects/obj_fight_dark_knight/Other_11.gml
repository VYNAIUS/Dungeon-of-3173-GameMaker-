if hp < original_max_hp * 0.75 and not(special_attack_done)
{
	animation_type = "summon"
	special_attack_done = true
}
else
{
	var are_there_others = false
	with obj_fight_entity
	{
		if is_enemy and id_name != "dark_knight"
		{
			are_there_others = true
		}
	}
	if are_there_others
	{
		original_sprite = spr_dark_knight_compact
		sprite_index = original_sprite
		if regeneration < original_regeneration
		{
			var funny_amount = ceil(original_regeneration * 0.05)
			regeneration += funny_amount
			if not(is_hidden)
			{
				var dmg_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				dmg_text.text = "+" + string(funny_amount) + "% REG"
				dmg_text.text_color = #00FF00
			}
		}
		if not(is_immune)
		{
			is_immune = true
		}
		animation_type = "idle"
	}
	else
	{
		original_sprite = spr_dark_knight
		sprite_index = original_sprite
		animation_type = "fight"
		if is_immune
		{
			is_immune = false
		}
	}
}