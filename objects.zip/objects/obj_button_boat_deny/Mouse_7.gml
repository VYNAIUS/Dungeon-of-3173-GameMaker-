if button_pressed
{
	dialogue_place("Boat Person Deny")
}
event_inherited()