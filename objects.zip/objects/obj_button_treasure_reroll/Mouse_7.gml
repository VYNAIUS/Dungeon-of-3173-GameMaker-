if button_pressed
{
	with obj_shop_item
	{
		event_user(0)
	}
	event_user(0)
	treasure_new_item()
}
event_inherited()