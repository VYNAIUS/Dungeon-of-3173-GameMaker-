image_blend = merge_color(c_black, c_white, blend_percentage)
draw_sprite_ext(id.sprite_index, -1, x, y + image_yoffset,
image_xscale, image_yscale, image_angle, image_blend, image_alpha)
draw_set_font(Cascadia_Code_1)

draw_set_halign(fa_center)
draw_set_valign(fa_middle)

draw_set_color(text_color)
draw_set_alpha(image_alpha)

draw_text_transformed(x, y + image_yoffset, button_text, text_scale, text_scale, 0)

draw_set_alpha(1)
draw_set_halign(fa_left)
draw_set_valign(fa_top)

draw_set_color(#FFFFFF)

if button_hover == false and blend_percentage < 1
{
	 blend_percentage += 0.02
}
else if button_hover == true
{
	if blend_percentage > 0.5
	{blend_percentage -= 0.1}
	else if  blend_percentage < 0.5
	{blend_percentage += 0.05}
	if blend_percentage > 0.47 and blend_percentage < 0.53
	{blend_percentage = 0.5}
}

if image_alpha < target_alpha
{
	image_alpha += 0.07
	if image_alpha > target_alpha
	{
		image_alpha = target_alpha
	}
}
else if image_alpha > target_alpha
{
	image_alpha -= 0.07
	if image_alpha < target_alpha
	{
		image_alpha = target_alpha
	}
}