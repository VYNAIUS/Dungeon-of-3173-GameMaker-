if pressable
{
	button_hover = true
	image_yoffset = 2
	if affected_by_is_turn == false or (affected_by_is_turn and not(global.is_turn))
	if button_description != "none"
	{
		global.button_description = button_description
	}
}