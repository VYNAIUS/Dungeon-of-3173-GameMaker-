if pressable
{
	button_pressed = true
	image_yoffset = 7
	audio_play_sound(snd_click_1, 0, false, 0.5, 0, random_range(0.9, 1.1))
}