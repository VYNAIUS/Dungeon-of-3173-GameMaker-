image_yoffset = 0
button_pressed = false