if global.is_map_transitioning or global.is_dialogue or destroy_self
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0
	pressable = false
}
else if global.current_ui_layer != ui_layer or (global.is_turn and affected_by_is_turn) or global.is_keybind_change or global.entity_choose_type != "none"
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0.3
	pressable = false
}
else
{
	if not(pressable)
	{
		pressable = true
		if abs(mouse_x - x) <= sprite_width / 2 and abs(mouse_y - y) <= sprite_height / 2
		{
			event_user(1)
		}
	}
	target_alpha = 1
	pressable = true
}

if destroy_self and image_alpha == target_alpha
{
	if global.button_description == button_description
	{
		global.button_description = "none"
	}
	instance_destroy()
}

if pressable == false
{
	button_pressed = false
}

