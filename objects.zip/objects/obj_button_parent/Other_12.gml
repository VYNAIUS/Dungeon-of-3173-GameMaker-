image_yoffset = 0
button_pressed = false
button_hover = false
if global.button_description == button_description and global.current_ui_layer == ui_layer
{
	global.button_description = "none"
}