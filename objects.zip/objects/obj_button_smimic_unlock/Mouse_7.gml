if button_pressed
{
	global.smimic_locked = false
	with obj_shop_smimic
	{
		event_user(0)
	}
	event_user(0)
}
event_inherited()