if button_pressed
{
	var new_shopkeeper_items_array = []
	for (var i = 0; i < array_length(global.shopkeeper_items); i++)
	{
		var shop_item = global.shopkeeper_items[i]
		array_push(new_shopkeeper_items_array, shop_item.id_name)
	}
	global.shopkeeper_items = new_shopkeeper_items_array
	if not(global.shopkeeper_leave_tutorial)
	{
		global.shopkeeper_leave_tutorial = true
		dialogue_place("Shopkeeper Leave Tutorial")
		scr_meta_save()
	}
	else
	{
		transition_to_map()
	}
}
event_inherited()