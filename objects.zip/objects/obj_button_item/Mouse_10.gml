event_inherited()

if pressable
{
	global.shop_index_selected = shop_item_index
}