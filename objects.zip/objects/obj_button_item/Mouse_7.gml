if button_pressed
{
	if shop_type == "shopkeeper"
	{
		if global.game_time >= 6 or global.shopkeeper_dead_rn or global.shopkeeper_items[shop_item_index].cost == 0
		{
			if global.player_money >= global.shopkeeper_items[shop_item_index].cost or global.shopkeeper_dead_rn or (global.heretic_reputation == 1 and global.player_money >= round(global.shopkeeper_items[shop_item_index].cost * 0.5))
			{
				shop_buy(shop_item_index)
				if global.shopkeeper_dead_rn == false
				{
					if global.heretic_reputation == 1
					{
						global.player_money -= round(global.shopkeeper_items[shop_item_index].cost * 0.5)
					}
					else
					{
						global.player_money -= global.shopkeeper_items[shop_item_index].cost
					}
				}
				instance_destroy(global.shopkeeper_items[shop_item_index])
				global.shopkeeper_items[shop_item_index] = instance_create_layer(obj_shop_initator.x, obj_shop_initator.y, "Instances", obj_shop_item_nothing)
				global.shopkeeper_items[shop_item_index].self_index = shop_item_index
				button_text = global.shopkeeper_items[shop_item_index].name
				if string_length(button_text) > 6
				{
					text_scale = 3 / (string_length(button_text) + 5)
				}
			}
			else
			{
				audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
				dialogue_place("Shopkeeper Poor")
			}
		}
		else
		{
			if global.player_money >= global.shopkeeper_items[shop_item_index].cost or (global.heretic_reputation == 1 and round(global.player_money >= global.shopkeeper_items[shop_item_index].cost * 0.5))
			{
				var xcoord = 683
				var ycoord = 384
				create_settings_box(xcoord, ycoord - 20, 3, 1.5)
				var buy = instance_create_depth(xcoord - 192, ycoord - 50, depth - 11, obj_button_buy_confirm)
				var no = instance_create_depth(xcoord, ycoord + 80, depth - 11, obj_button_settings_quit)
				var yes = instance_create_depth(xcoord + 192, ycoord - 50, depth - 11, obj_button_steal)
				var text = instance_create_depth(xcoord, ycoord - 158, depth - 11, obj_text)
				no.button_text = "Cancel"
				no.text_scale = 0.25
				yes.button_text = "Steal"
				yes.shop_item_index = shop_item_index
				buy.shop_item_index = shop_item_index
				text.text = "Steal it or buy it? He probably won't notice."
				text.scale = 0.1875
			}
			else
			{
				var xcoord = 683
				var ycoord = 384
				create_settings_box(xcoord, ycoord - 20, 3, 1)
				var no = instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_settings_quit)
				var yes = instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_steal)
				var text = instance_create_depth(xcoord, ycoord - 108, depth - 11, obj_text)
				no.button_text = "No"
				no.text_scale = 0.25
				yes.shop_item_index = shop_item_index
				text.text = "Steal it? He probably won't notice."
				text.scale = 0.1875
			}
		}
	}
	else if shop_type == "alchemist"
	{
		if global.player_money >= global.alchemist_items[shop_item_index].cost
		{
			if global.alchemist_items[shop_item_index].cost > 0
			{
				global.alchemist_bought = true
				global.alchemist_anger -= 0.2
				if global.alchemist_anger < 0
				{
					global.alchemist_anger = 0
				}
			}
			shop_buy(shop_item_index)
			global.player_money -= global.alchemist_items[shop_item_index].cost
			instance_destroy(global.alchemist_items[shop_item_index])
			global.alchemist_items[shop_item_index] = instance_create_layer(obj_shop_initator_alchemist.x, obj_shop_initator_alchemist.y, "Instances", obj_shop_item_nothing)
			global.alchemist_items[shop_item_index].self_index = shop_item_index
			button_text = global.alchemist_items[shop_item_index].name
			if string_length(button_text) > 6
			{
				text_scale = 3 / (string_length(button_text) + 5)
			}
		}
		else
		{
			audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
			if global.game_time >= 6
			{
				if random(1) > 0.5
				{
					dialogue_place("Alchemist Poor 0")
				}
				else
				{
					dialogue_place("Alchemist Poor 1")
				}
			}
			else
			{
				
				if random(1) > 0.5
				{
					dialogue_place("Alchemist Poor Night 0")
				}
				else
				{
					dialogue_place("Alchemist Poor Night 1")
				}
			}
		}
	}
}
event_inherited()