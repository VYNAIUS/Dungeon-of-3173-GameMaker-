event_inherited()

switch shop_type
{
	case "shopkeeper":
		button_text = global.shopkeeper_items[shop_item_index].name
		break
	case "alchemist":
		button_text = global.alchemist_items[shop_item_index].name
		break
}
var max_length = 0
var current_length = 0
for (var i = 1; i <= string_length(button_text); i++)
{
	if string_char_at(button_text, i) == "\n"
	{
		current_length = 0
	}
	else
	{
		current_length += 1
	}
	if max_length < current_length
	{
		max_length = current_length
	}
}
text_scale = 3 / (max_length + 5)
	