event_inherited()

button_description = "shop_item" + string(shop_item_index)