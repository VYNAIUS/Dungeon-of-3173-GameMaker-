if button_pressed
{
	global.button_description = "none"
	create_settings_box(683, 384, 3, 2.25)
	var quit_button = instance_create_depth(500, 570, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var text = instance_create_depth(683, 150, depth - 11, obj_text_current_skill)
	text.skill_variable = skill_variable
	var starting_point = (global.current_ui_layer - 3) * 4
	var x_level = 490
	var y_level = 260
	var counter_limit = starting_point + 4
	var is_over_flow = false
	for (var i = starting_point; i < array_length(global.player_skills); i++)
	{
		if i >= counter_limit
		{
			is_over_flow = true
			break
		}
		var button = instance_create_depth(x_level, y_level, depth - 11, obj_button_inventory_equip_skill)
		button.skill_index = i
		button.where_to_equip = skill_variable
		if i % 2 == 0
		{
			x_level = 876
		}
		else
		{
			x_level = 490
		}
		if i % 4 < 1
		{
			y_level = 260
		}
		else
		{
			y_level = 400
		}
	}
	if is_over_flow
	{
		var button = instance_create_depth(866, 570, depth - 11, obj_button_inventory_skill)
		button.skill_variable = skill_variable
		button.button_text = "Next Page"
	}
}
event_inherited()