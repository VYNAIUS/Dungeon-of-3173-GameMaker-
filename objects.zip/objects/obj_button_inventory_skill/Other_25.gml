var skill_to_check = ""
if skill_variable == 0
{
	skill_to_check = global.player_current_skill_0
}
else if skill_variable == 1
{
	skill_to_check = global.player_current_skill_1
}
button_description = skill_to_check
switch skill_to_check
{
	case "idle":
		button_text = "Idle"
		break
	case "defend":
		button_text = "Defend"
		break
	case "magic_defend":
		button_text = "Magic\nDefend"
		break
	case "parry":
		button_text = "Parry"
		break
	case "cleanse":
		button_text = "Cleanse"
		break
	case "pickpocket":
		button_text = "Pickpocket"
		break
	case "split":
		button_text = "Split"
		break
	case "impenetrability":
		button_text = "Impenetrate"
		break
	case "reap":
		button_text = "Reap"
		break
	case "trick":
		button_text = "Trick"
		break
	case "crystalise":
		button_text = "Crystalise"
		break
}