event_inherited()

skill_variable = 69