if button_pressed
{
	global.gmimic_encounters += 1
	with obj_button_gmimic_open
	{
		event_user(0)
	}
	dialogue_place("Golden Mimic Intro")
	with obj_shop_gmimic
	{
		event_user(15)
	}
	global.npc_song_played = audio_play_sound(mus_friendly_mimic, 0, true, 1)
}
event_inherited()