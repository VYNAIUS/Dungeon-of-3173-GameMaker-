if button_pressed
{
	create_settings_box(683, 384, 5, 2.9)
	var quit_button = instance_create_depth(683, 660, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	instance_create_depth(96, 32, depth - 11, obj_stats_part_1)
	instance_create_depth(1270, 32, depth - 11, obj_stats_part_2)
}
event_inherited()