if stunned > 0
{
	stunned_for += 1
}
if stunned_for >= 7 and stunned > 0
{
	audio_play_sound(snd_stunfree_3173, 0, false)
	var funny_text = instance_create_layer(x, y - 40, "Instances_UI", obj_text_custom)
	funny_text.text = "-" + string(stunned) + " STN'D"
	funny_text.text_color = #F9F1A5
	stunned = 0
}
if hp < original_max_hp * 0.75 and global.game_original_difficulty > 55
{
	var dmg_amount = ceil(original_dmg * 0.01)
	dmg += dmg_amount
	var dmg_text = instance_create_layer(x, y, "Instances_UI", obj_text_dmgincrease)
	dmg_text.dmg_amount = dmg_amount
}
soul_reap_cooldown -= 1
parry_cooldown -= 1
if sympathy < 1
{
	if global.action_type == "idle" and (hp / original_max_hp) > 0.75 and (regeneration / original_regeneration) > 0.25
	{
		animation_type = "idle"
	}
	else
	{
		if not(special_attack_done) and hp / original_max_hp < 0.6 and not(global.heretic_reputation == 1)
		{
			if not(stunned > 0)
			{
				special_attack_done = true
				with obj_fight_3173
				{
					special_attack_done = true
				}
			}
			animation_type = "split"
		}
		else if random(1) < crit_chance * 0.5 and soul_reap_cooldown <= 0
		{
			if instance_exists(obj_fight_player) and not(obj_fight_player.death_played)
			{
				action_target = obj_fight_player.id
				animation_type = "soul_reap"
			}
			else
			{
				animation_type = "fight"
			}
			if not(stunned > 0)
			{
				soul_reap_cooldown = 6
			}
		}
		else
		{
			if parry_cooldown <= 0 and random(1) < (hp / original_max_hp) - 0.5
			{
				animation_type = "parry"
				if not(stunned > 0)
				{
					parry_cooldown = 3
				}
			}
			else
			{
				if instance_exists(obj_fight_player)
				{
					action_target = obj_fight_player.id
					animation_type = "fight_specific"
				}
				else
				{
					animation_type = "fight"
				}
			}
		}
	}
}
else
{
	if tricked_length >= 1 + (global.change_state != -1)
	{
		sympathy = 0
		sympathy_factor = 0
		if global.change_state != -1
		{
			dialogue_place("Cycle Final Fight: 3173 Trick")
		}
	}
	animation_type = "idle"
	tricked_length += 1
}