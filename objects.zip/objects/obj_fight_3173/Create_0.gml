event_inherited()
special_attack_done = false
tricked_length = 0
parry_cooldown = 0
soul_reap_cooldown = 0
shadow_clone_hue_shift_start = 0
stunned_for = 0

is_splitted = false