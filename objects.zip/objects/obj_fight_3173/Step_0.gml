event_inherited()

if sympathy >= 1
{
	sprite_index = spr_3173_trick
}
else
{
	sprite_index = spr_3173
}

if instance_exists(obj_fight_death_body_ally) and not(special_attack_done) and hp - total_dealt_damage < original_max_hp * 0.1
{
	death_played = false
	hp = round(original_max_hp * 0.1)
	total_dealt_damage = 0
}

shadow_clone_cooldown -= 1
shadow_clone_hue_shift_start += 0.001
if shadow_clone_cooldown <= 0
{
	if hp / original_max_hp > 0.6
	{
		vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone)
		vfx.follower = id
		vfx.speed = 1
		vfx.direction = random_range(0, 360)
		shadow_clone_cooldown = 1 + round((5 + instance_number(obj_fight_vf_shadowclone) / 200) * (hp / original_max_hp * 5))
	}
	else
	{
		var shadow_clone = instance_create_layer(x, y, "Instances_Coins", obj_fight_vf_shadowclone_god_0)
		shadow_clone.speed = 2
		shadow_clone.direction = random(360)
		shadow_clone.follower = id
		shadow_clone.hue_shift = shadow_clone_hue_shift_start
		shadow_clone_cooldown = 1 + round((10 + instance_number(obj_fight_vf_shadowclone) / 200) * (hp / original_max_hp * 5))
	}
}