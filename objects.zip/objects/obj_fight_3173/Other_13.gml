if not(is_undefined(global.battle_song_played))
{
	audio_sound_gain(global.battle_song_played, 0, 1000)
}
if not(instance_exists(obj_fight_cycle))
{
	if global.change_state == 0
	{
		if global.death_state > -2
		{
			dialogue_place("Cycle Final Fight: End Regular")
		}
		else
		{
			dialogue_place("Cycle Final Fight: End Caught Death")
		}
	}
	else if global.change_state == -2
	{
		if global.death_state > -2
		{
			dialogue_place("Cycle Final Fight: End Caught Change")
		}
		else
		{
			dialogue_place("Cycle Final Fight: End Caught Change Death")
		}
	}
	else if global.change_state == -1
	{
		dialogue_place("Cycle Final Fight: End Lost Change")
	}
}