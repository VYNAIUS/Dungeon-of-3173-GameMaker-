event_inherited()

if hp - total_dealt_damage < max_hp * 0.1
{
	hp = round(max_hp * 0.1)
	death_played = false
	total_dealt_damage = 0
}