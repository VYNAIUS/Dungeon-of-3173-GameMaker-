if global.fighting_turn == 1
{
	if is_inside_array(global.action_type, ["fight", "soul_reap", "crystalise", "split", "cleanse"])
	{
		dialogue_place("Heretic Brin Tutorial 0 Attacked")
	}
	else
	{
		dialogue_place("Heretic Brin Tutorial 0")
	}
	animation_type = "idle"
}
else if hp <= round(original_max_hp * 0.1)
{
	dialogue_place("Heretic Brin Tutorial End Little HP")
	animation_type = "none"
}
else if global.fighting_turn == 3
{
	dialogue_place("Heretic Brin Tutorial 1")
	animation_type = "idle"
}
else if global.fighting_turn > 10
{
	dialogue_place("Heretic Brin Tutorial End Too Long")
	animation_type = "none"
}
else
{
	action_target = obj_fight_player.id
	with obj_fight_entity
	{
		if not(is_enemy)
		{
			if id_name == "ally_heretic_brin"
			{
				other.action_target = id
			}
		}
	}
	animation_type = "fight_specific"
}