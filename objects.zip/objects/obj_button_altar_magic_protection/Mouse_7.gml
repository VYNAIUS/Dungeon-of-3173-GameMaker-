// Inherit the parent event
if button_pressed and global.is_turn == false
{
	global.altar_choice = "magic_protection"
	global.is_turn = true
	scr_grant_altar_upgrades()
}
event_inherited();