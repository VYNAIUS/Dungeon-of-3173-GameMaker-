event_inherited()

switch (global.area_id)
{
	case 0:
		sprite_index = spr_bg_garden_shop
		break
	case 1:
		sprite_index = spr_bg_forest_shop
		break
	case 2:
		sprite_index = spr_bg_cave_shop
		break
	case 3:
		sprite_index = spr_bg_tundra_shop
		break
	case 4:
		sprite_index = spr_bg_canyon_shop
		break
	case 5:
		sprite_index = spr_bg_desert_shop
		break
	case 6:
		sprite_index = spr_bg_rotten_shop
		break
}