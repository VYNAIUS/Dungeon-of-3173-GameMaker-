if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	instance_create_depth(xcoord - 192, ycoord - 192, depth - 11, obj_button_settings_visual)
	instance_create_depth(xcoord + 192, ycoord - 192, depth - 11, obj_button_settings_audio)
	instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_settings_controls)
	instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_settings_gameplay)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.save_settings = true
	quit_button.can_escape_key = true
}


event_inherited()