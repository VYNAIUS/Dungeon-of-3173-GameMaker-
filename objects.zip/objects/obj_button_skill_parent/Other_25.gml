switch skill_variable
{
	case "idle":
		button_text = "Idle"
		button_description = "skill_idle"
		break
	case "magic_defend":
		button_text = "Magic\nDefend"
		button_description = "skill_magicdefend"
		break
	case "defend":
		button_text = "Defend"
		button_description = "skill_defend"
		break
	case "parry":
		button_text = "Parry"
		button_description = "skill_parry"
		break
	case "cleanse":
		button_text = "Cleanse"
		button_description = "skill_cleanse"
		break
	case "pickpocket":
		button_text = "Pickpocket"
		button_description = "skill_pickpocket"
		break
	case "split":
		button_text = "Split"
		button_description = "skill_split"
		break
	case "impenetrability":
		button_text = "Impenetrate"
		button_description = "skill_impenetrability"
		break
	case "reap":
		button_text = "Reap"
		button_description = "skill_reap"
		break
	case "trick":
		button_text = "Trick"
		button_description = "skill_trick"
		break
	case "crystalise":
		button_text = "Crystalise"
		button_description = "skill_crystalise"
		break
}