event_inherited()

if cooldown > 0 and not(global.is_map_transitioning or global.is_dialogue or destroy_self)
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0.3
	pressable = false
}