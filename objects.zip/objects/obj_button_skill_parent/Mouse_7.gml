if button_pressed
{
	if instance_exists(obj_fight_player) and obj_fight_player.stunned <= 0
	and not(global.change_state == -2 and global.fighting_turn % 4 == 2)
	and not(global.death_state == -2 and global.fighting_turn % 5 == 2)
	and not(obj_fight_player.panic_cooldown - global.player_fear * 5 <= 0)
	{
		switch skill_variable
		{
			case "idle":
				global.action_type = "idle"
				global.action_done = true
				global.is_turn = true
				break
			case "defend":
				global.action_type = "defend"
				global.action_done = true
				global.is_turn = true
				break
			case "magic_defend":
				global.action_type = "magic_defend"
				global.action_done = true
				global.is_turn = true
				break
			case "parry":
				global.action_type = "parry"
				global.action_done = true
				global.is_turn = true
				cooldown = 4
				break
			case "cleanse":
				global.action_type = "cleanse"
				global.action_done = true
				global.is_turn = true
				cooldown = 4
				break
			case "pickpocket":
				if obj_fight_turn_manager.enemies_needed_to_be_done == 1
				{
					global.action_type = "pickpocket"
					global.action_done = true
					cooldown = 2
				}
				else
				{
					global.entity_choose_type = "pickpocket"
					cooldown = 2
				}
				global.is_turn = true
				break
			case "reap":
				if obj_fight_turn_manager.enemies_needed_to_be_done == 1
				{
					global.action_type = "soul_reap"
					global.action_done = true
				}
				else
				{
					global.entity_choose_type = "soul_reap"
				}
				global.is_turn = true
				cooldown = 6
				break
			case "impenetrability":
				global.action_type = "impenetrability_regen"
				global.action_done = true
				global.is_turn = true
				cooldown = 6
				break
			case "split":
				global.action_type = "split"
				global.action_done = true
				global.is_turn = true
				cooldown = 11
				break
			case "trick":
				global.action_type = "trick"
				global.action_done = true
				global.is_turn = true
				cooldown = 2
				break
			case "crystalise":
				if obj_fight_turn_manager.enemies_needed_to_be_done == 1
				{
					global.action_type = "crystalise"
					global.action_done = true
				}
				else
				{
					global.entity_choose_type = "crystalise"
				}
				global.is_turn = true
				cooldown = 7
				break
		}
	}
	else
	{
		global.action_type = "idle"
		global.action_done = true
		global.is_turn = true
	}
}

event_inherited()