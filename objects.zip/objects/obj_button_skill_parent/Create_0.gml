event_inherited()

cooldown = 0
skill_variable = ""

event_user(15)