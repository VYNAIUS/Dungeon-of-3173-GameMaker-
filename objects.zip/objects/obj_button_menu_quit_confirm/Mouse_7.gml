if button_pressed
{
	var possible_dialogue = []
	
	if global.end_condition == "lose"
	{
		array_push(possible_dialogue, "3174: Loss 0")
		if is_inside_array("3174: Loss 0", global.the_3174_told_dialog)
		{
			array_push(possible_dialogue, "3174: Loss 1")
			if is_inside_array("3174: Loss 1", global.the_3174_told_dialog)
			{
				array_push(possible_dialogue, "3174: Loss 2")
				if is_inside_array("3174: Loss 2", global.the_3174_told_dialog)
				{
					array_push(possible_dialogue, "3174: Loss 3")
				}
			}
		}
	}
	else if global.end_condition == "win"
	{
		if global.heretic_reputation == 1
		{
			if not(global.game_ending_PB or global.game_ending_CD) and not(is_inside_array("3174: Win Heresy No Change Assist", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Heresy No Change Assist")
			}
			else if not(global.game_ending_M) and not(is_inside_array("3174: Win Heresy No M", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Heresy No M")
			}
			
		}
		else if global.change_state == 2
		{
			if global.death_state == 2
			{
				if not(global.game_ending_CD)
				{
					if not(is_inside_array("3174: Win Partial Balance No CD", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Partial Balance No CD")
					}
				}
				else if not(global.game_ending_H)
				{
					if not(is_inside_array("3174: Win Partial Balance Yes CD No H", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Partial Balance Yes CD No H")
					}
				}
				else
				{
					if not(is_inside_array("3174: Win Partial Balance Yes CD Yes H", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Partial Balance Yes CD Yes H")
					}
				}
			}
			else
			{
				if not(global.game_ending_PB)
				{
					if not(is_inside_array("3174: Win Change Desperation No PB", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Change Desperation No PB")
					}
				}
				else if not(global.game_ending_H)
				{
					if not(is_inside_array("3174: Win Change Desperation Yes PB No H", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Change Desperation Yes PB No H")
					}
				}
				else if not(global.game_ending_FV or global.game_ending_GC)
				{
					if not(is_inside_array("3174: Win Change Desperation Yes PB Yes H No Change Consume", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Change Desperation Yes PB Yes H No Change Consume")
					}
				}
				else
				{
					if not(is_inside_array("3174: Win Change Desperation Yes PB Yes H Yes Change Consume", global.the_3174_told_dialog))
					{
						array_push(possible_dialogue, "3174: Win Change Desperation Yes PB Yes H Yes Change Consume")
					}
				}
			}
		}
		else if global.change_state == -1
		{
			if not(global.game_ending_FV) and not(global.game_ending_GC) and not(is_inside_array("3174: Win Stalemate No FV No GC", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Stalemate No FV No GC")
			}
			else if not(is_inside_array("3174: Win Stalemate Yes Change Consume", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Stalemate Yes Change Consume")
			}
		}
		else if global.change_state == -2
		{
			if global.death_state != -2
			{
				if not(global.game_ending_GC) and not(is_inside_array("3174: Win Fake Victory No GC", global.the_3174_told_dialog))
				{
					array_push(possible_dialogue,  "3174: Win Fake Victory No GC")
				}
			}
			else
			{
				if not(global.game_ending_PB) and not(global.game_ending_CD) and not(is_inside_array("3174: Win Great Cycle No CD No PB", global.the_3174_told_dialog))
				{
					array_push(possible_dialogue, "3174: Win Great Cycle No CD No PB")
				}
			}
		}
		else if global.midas_state == 1
		{
			if not(is_inside_array("3174: Win Midas No Change Assist", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Midas No Change Assist")
			}
			else if not(is_inside_array("3174: Win Midas", global.the_3174_told_dialog))
			{
				array_push(possible_dialogue, "3174: Win Midas")
			}
		}
		else
		{
			if not(global.game_ending_CD) and not(global.game_ending_PB) and not(global.game_ending_FV) and not(global.game_ending_SM) and not(global.game_ending_GC)
			{
				if not(is_inside_array("3174: Win Regular No Change Endings", global.the_3174_told_dialog))
				{
					array_push(possible_dialogue, "3174: Win Regular No Change Endings")
				}
			}
		}
		if array_length(possible_dialogue) == 0
		{
			array_push(possible_dialogue, "3174: Win 0")
			if is_inside_array("3174: Win 0", global.the_3174_told_dialog)
			{
				array_push(possible_dialogue, "3174: Win 1")
				if is_inside_array("3174: Win 1", global.the_3174_told_dialog)
				{
					array_push(possible_dialogue, "3174: Win 2")
				}
			}
		}
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.the_3174_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if array_length(confirmed_dialog) != 0 and ((random(1) < 0.1 and global.end_condition == "lose") or (global.end_condition == "win"))
	{
		trigger("mute_everything")
		trigger("delete_uistuff")
		array_push(global.the_3174_told_dialog, confirmed_dialog[random_index])
		window_set_caption("My Dungeon")
		scr_meta_save()
		dialogue_place(confirmed_dialog[random_index])
	}
	else
	{
		transition_to_main_menu()
	}
}
event_inherited()