event_inherited()

if global.player_current_skill_0 != "cleanse" and global.player_current_skill_1 != "cleanse"
{
	instance_destroy()
}