if button_pressed
{
	global.change_reputation = -1
	if global.npc_song_played != undefined
	{
		audio_sound_gain(global.npc_song_played, 0, 1000)
	}
	if global.player_consume <= 0
	{
		dialogue_place("Change Fight Cleanse")
	}
	else
	{
		dialogue_place("Change Fight Consume")
	}
}
event_inherited()