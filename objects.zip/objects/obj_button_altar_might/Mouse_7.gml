// Inherit the parent event
if button_pressed and global.is_turn == false
{
	global.altar_choice = "might"
	global.is_turn = true
	scr_grant_altar_upgrades()
}

event_inherited();
