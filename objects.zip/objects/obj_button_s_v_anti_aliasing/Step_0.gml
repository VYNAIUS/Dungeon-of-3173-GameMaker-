// Inherit the parent event
event_inherited();

button_text = "Anti-Aliasing: " + string(global.anti_aliasing)