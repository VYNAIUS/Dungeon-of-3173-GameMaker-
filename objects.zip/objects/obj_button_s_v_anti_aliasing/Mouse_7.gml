if button_pressed
{
	global.anti_aliasing += 2
	if global.anti_aliasing == 6
	{global.anti_aliasing = 8}
	else if global.anti_aliasing == 10
	{global.anti_aliasing = 0}
	with (obj_camera_audio_manager)
	{
		event_user(0)
	}
}
event_inherited();