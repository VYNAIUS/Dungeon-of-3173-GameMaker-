if button_pressed
{
	if global.heretic_reputation == 1
	{
		lower_ui_layer()
		dialogue_place("Shopkeeper Poor Brin")
	}
	else
	{
		shop_buy(shop_item_index)
		global.shopkeeper_debt += round(global.shopkeeper_items[shop_item_index].cost * 1.1)
		instance_destroy(global.shopkeeper_items[shop_item_index])
		global.shopkeeper_items[shop_item_index] = instance_create_layer(obj_shop_initator.x, obj_shop_initator.y, "Instances", obj_shop_item_nothing)
		global.shopkeeper_items[shop_item_index].self_index = shop_item_index
		if global.player_current_skill_0 != "pickpocket" and global.player_current_skill_1 != "pickpocket"
		{
			global.shopkeeper_suspicion += 0.25
			global.shopkeeper_stolen_items_at_once += 1
		}
		else
		{
			global.shopkeeper_suspicion += 0.1
			global.shopkeeper_stolen_items_at_once += 0.75
		}
		with (obj_button_item)
		{
			if shop_item_index == other.shop_item_index
			{
				button_text = global.shopkeeper_items[shop_item_index].name
				if string_length(button_text) > 6
				{
					text_scale = 3 / (string_length(button_text) + 5)
				}
			}
		}
		global.button_description = "none"
	
		lower_ui_layer()
	}
}

event_inherited()