if button_pressed
{
	pressable = false
	global.troll_nevz = true
	instance_create_layer(683, 384, "Instances", obj_troll_nevz)
	trigger("mute_everything")
	if global.menu_song_played != undefined and audio_is_playing(global.menu_song_played)
	{
		audio_sound_gain(global.menu_song_played, 0, 1000)
	}
	trigger("delete_uistuff")
	with obj_glyph_mover
	{
		instance_destroy()
	}
}
event_inherited()