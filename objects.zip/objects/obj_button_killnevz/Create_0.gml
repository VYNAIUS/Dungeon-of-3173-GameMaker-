event_inherited()

if global.troll_nevz or not(global.game_ending_SM) or random(1) < 0.975
{
	instance_destroy()
}