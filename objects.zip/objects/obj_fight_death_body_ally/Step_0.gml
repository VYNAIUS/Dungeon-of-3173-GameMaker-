event_inherited()
if is_splitted
{
	x = x_hover_position
	y = ystart
	is_immune = false
}
else
{
	is_immune = true
}