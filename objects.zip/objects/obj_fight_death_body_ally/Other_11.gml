if not(is_splitted)
{
	animation_type = "fight"
}
else
{
	animation_type = "idle"
}