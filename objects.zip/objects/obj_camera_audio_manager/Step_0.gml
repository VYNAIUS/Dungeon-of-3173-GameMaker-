if keyboard_check_pressed(vk_f11)
{
	global.is_fullscreen = not(global.is_fullscreen)
	event_user(0)
	scr_settings_save()
}
if global.is_fullscreen
{
	global.x_resolution = window_get_width()
	global.y_resolution = window_get_height()
	global.resolution_option = 0
}
audio_group_set_gain(audiogroup_sfx, global.volume_master * global.volume_sfx, 0)
audio_group_set_gain(audiogroup_music, global.volume_master * global.volume_music, 0)

if global.area_song_played != undefined 
{
	if audio_sound_get_gain(global.area_song_played) == 0
	{
		audio_pause_sound(global.area_song_played)
	}
	else if not(instance_exists(obj_transition))
	{
		audio_resume_sound(global.area_song_played)
	}
}