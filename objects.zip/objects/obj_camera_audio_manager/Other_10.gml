window_set_fullscreen(global.is_fullscreen)
display_reset(global.anti_aliasing, global.is_vsync)
alarm[0] = 1