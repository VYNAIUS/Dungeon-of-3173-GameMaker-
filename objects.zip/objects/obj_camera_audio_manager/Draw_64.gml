draw_set_valign(fa_top)
draw_set_halign(fa_left)
draw_set_alpha(1)
draw_set_color(#FFFFFF)
var corner_text = ""
var line_skip = false
if global.show_fps
{
	if line_skip
	{
		corner_text = corner_text + "\n"
	}
	corner_text = corner_text + string(fps) + "TPS"
	line_skip = true
}
if global.show_fpsreal
{
	if line_skip
	{
		corner_text = corner_text + "\n"
	}
	corner_text = corner_text + string(int64(fps_real)) + "FPS"
	line_skip = true
}
draw_text_transformed(0, 0, corner_text, 0.1875, 0.1875, 0)