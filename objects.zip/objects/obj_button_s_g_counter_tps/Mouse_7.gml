if button_pressed
{
	global.show_fps = not(global.show_fps)
	if global.show_fps
	{
		button_text = "TPS shown:\nON"
	}
	else
	{
		button_text = "TPS shown:\nOFF"
	}
}
event_inherited()