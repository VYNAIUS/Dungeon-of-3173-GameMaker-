event_inherited()

if global.show_fps
{
	button_text = "TPS shown:\nON"
}
else
{
	button_text = "TPS shown:\nOFF"
}