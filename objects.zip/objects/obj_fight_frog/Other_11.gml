if sympathy < 1 and global.heretic_reputation != 1
{
	animation_type = "fight"
}
else
{
	animation_type = "idle"
}