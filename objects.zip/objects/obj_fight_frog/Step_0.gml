event_inherited()

shadow_clone_cooldown -= 1
if shadow_clone_cooldown <= 0
{
	vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone)
	vfx.follower = id
	vfx.speed = 1
	vfx.direction = random_range(0, 360)
	shadow_clone_cooldown = round(1 + instance_number(obj_fight_vf_shadowclone) / 200)
}