if sympathy >= 1
{
	animation_type = "idle"
}
else if not(cleansed)
{
	animation_type = "magic_fight"
}
else
{
	animation_type = "fight"
}