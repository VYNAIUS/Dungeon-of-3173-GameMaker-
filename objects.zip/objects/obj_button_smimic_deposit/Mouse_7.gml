if button_pressed
{
	if global.player_money >= 10
	{
		global.player_money -= 10
		global.smimic_money += 10
	}
	else
	{
		global.smimic_money += global.player_money
		global.player_money = 0
	}
}
event_inherited()