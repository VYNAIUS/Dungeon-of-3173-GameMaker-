if sympathy >= 1
{
	animation_type = "idle"
}
if defense + original_defense < original_defense * 1.15 and random(1) < 0.5
{
	animation_type = "defend"
}
else
{
	animation_type = "fight"
}