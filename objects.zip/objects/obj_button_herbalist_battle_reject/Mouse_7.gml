global.player_saved_times += 1
lower_ui_layer()
dialogue_place("Herbalist Battling End Reject")

event_inherited()