event_inherited()
hidden_sprite = spr_crystal_enemy_hidden