event_inherited()

if global.smimic_locked
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0
	pressable = false
}