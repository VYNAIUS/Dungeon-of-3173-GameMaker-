if button_pressed
{
	var possible_dialogue = ["Steel Mimic Talk: Midas", "Steel Mimic Talk: Golden Mimic"]
		
	if global.area_id == 2
	{
		array_push(possible_dialogue, "Steel Mimic Talk: Cave")
	}
	else if global.area_id == 3
	{
		array_push(possible_dialogue, "Steel Mimic Talk: Tundra")
		if global.current_temperature < -3
		{
			array_push(possible_dialogue, "Steel Mimic Talk: Freezing")
		}
	}
	else if global.area_id == 4
	{
		array_push(possible_dialogue, "Steel Mimic Talk: Canyon")
	}
	else if global.area_id == 5
	{
		array_push(possible_dialogue, "Steel Mimic Talk: Desert")
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.smimic_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		confirmed_dialog = ["Steel Mimic Talk: No Dialog"]
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if not(is_inside_array(confirmed_dialog[random_index], ["Steel Mimic Talk: No Dialog"]))
	{
		array_push(global.smimic_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()