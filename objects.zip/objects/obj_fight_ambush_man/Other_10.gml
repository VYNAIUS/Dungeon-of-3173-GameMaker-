if not(has_revealed)
{
	audio_play_sound(snd_hit_leaf, 0, false, 1, 0, random_range(0.9, 1.1))
}
else
{
	audio_play_sound(snd_hit_sword, 0, false, 1, 0, random_range(0.95, 1.05))
}