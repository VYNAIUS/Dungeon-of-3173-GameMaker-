event_inherited()

if hp < original_max_hp * 0.75 and not(has_revealed)
{
	sprite_index = spr_ambusher
	original_sprite = sprite_index
	entity_name = "Ambush Man"
	entity_description = "A man hidden in a bush"
	ystart = 700 - sprite_get_height(sprite_index) / 2
	y = ystart
	audio_play_sound(snd_hit_leaf_big, 0, false, 1, 0, random_range(0.9, 1.1))
	has_revealed = true
}