event_inherited()
has_revealed = false