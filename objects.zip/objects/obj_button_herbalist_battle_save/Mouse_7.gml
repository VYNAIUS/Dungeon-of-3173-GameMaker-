global.player_saved_times += 1
scr_run_save(true)
lower_ui_layer()
dialogue_place("Herbalist Battling End Persist")

event_inherited()