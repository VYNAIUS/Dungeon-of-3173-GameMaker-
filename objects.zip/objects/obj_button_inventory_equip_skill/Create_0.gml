event_inherited()

skill_index = 0
skill_id = "idle"
where_to_equip = 69