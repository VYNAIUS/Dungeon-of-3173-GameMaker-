if button_pressed
{
	global.button_description = "none"
	if skill_index < array_length(global.player_skills)
	{
		if where_to_equip == 0
		{
			global.player_skills[skill_index] = global.player_current_skill_0
			global.player_current_skill_0 = skill_id
		}
		else if where_to_equip == 1
		{
			global.player_skills[skill_index] = global.player_current_skill_1
			global.player_current_skill_1 = skill_id
		}
	}
}
event_inherited()