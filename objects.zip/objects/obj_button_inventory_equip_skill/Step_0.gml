event_inherited()

if skill_index < array_length(global.player_skills)
{
	skill_id = global.player_skills[skill_index]
}
else
{
	skill_id = "idle"
}

button_description = skill_id

switch skill_id
{
	case "idle":
		button_text = "Idle"
		break
	case "defend":
		button_text = "Defend"
		break
	case "magic_defend":
		button_text = "Magic\nDefend"
		break
	case "parry":
		button_text = "Parry"
		break
	case "cleanse":
		button_text = "Cleanse"
		break
	case "pickpocket":
		button_text = "Pickpocket"
		break
	case "split":
		button_text = "Split"
		break
	case "impenetrability":
		button_text = "Impenetrate"
		break
	case "reap":
		button_text = "Reap"
		break
	case "trick":
		button_text = "Trick"
		break
	case "crystalise":
		button_text = "Crystalise"
		break
}