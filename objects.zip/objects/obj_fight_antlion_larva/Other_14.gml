scr_battle_spawn(obj_fight_antlion)
global.player_fear += 0.1
with obj_fight_antlion_larva
{
	can_cry = false
}