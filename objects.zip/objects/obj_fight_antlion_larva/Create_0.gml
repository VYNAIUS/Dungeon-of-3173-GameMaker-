event_inherited()
can_cry = true
hidden_sprite = spr_antlion_larva_hidden