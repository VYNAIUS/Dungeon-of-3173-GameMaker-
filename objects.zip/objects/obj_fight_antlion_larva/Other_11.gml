if sympathy >= 1
{
	animation_type = "idle"
}
else if original_max_hp * 0.75 > hp and can_cry
{
	animation_type = "summon"
}
else
{
	animation_type = "fight"
}