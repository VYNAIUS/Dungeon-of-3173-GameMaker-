event_inherited()
shadow_clone_cooldown -= 1
shadow_clone_hue_shift_start += 0.001
if shadow_clone_cooldown == 0
{
	var shadow_clone = instance_create_layer(x, y, "Instances_Coins", obj_fight_vf_shadowclone_god_0)
	shadow_clone.speed = 2
	shadow_clone.direction = random(360)
	shadow_clone.follower = id
	shadow_clone.hue_shift = shadow_clone_hue_shift_start
	shadow_clone_cooldown = 5
}