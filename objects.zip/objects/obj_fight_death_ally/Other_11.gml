if not(instance_exists(obj_fight_death_body_ally))
{
	if instance_exists(obj_fight_3173) and not(obj_fight_3173.death_played)
	{
		action_target = obj_fight_3173.id
		animation_type = "soul_reap"
	}
	else if instance_exists(obj_fight_cycle) and not(obj_fight_cycle.death_played)
	{
		action_target = obj_fight_cycle.id
		animation_type = "soul_reap"
	}
	else
	{
		animation_type = "idle"
	}
}
else
{
	if (obj_fight_death_body_ally.times_splitted < 2) and original_max_hp * 0.5 >= hp
	{
		obj_fight_death_body_ally.is_splitted = false
		obj_fight_death_body_ally.sprite_index = spr_boat_person_ally
		global.good_guy_done_count += 1
		instance_destroy()
		with obj_fight_turn_manager
		{
			event_user(0)
		}
	}
	else
	{
		if instance_exists(obj_fight_3173) and not(obj_fight_3173.death_played)
		{
			action_target = obj_fight_3173.id
			animation_type = "soul_reap"
		}
		else if instance_exists(obj_fight_cycle) and not(obj_fight_cycle.death_played)
		{
			action_target = obj_fight_cycle.id
			animation_type = "soul_reap"
		}
		else
		{
			animation_type = "idle"
		}
	}
}