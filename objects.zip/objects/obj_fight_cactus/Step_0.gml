event_inherited()

if not(has_revealed) and original_max_hp * 0.75 >= hp
{
	has_revealed = true
	global.player_fear += 0.1
	entity_description = "This cactus now attacks"
	if not(is_hidden)
	{
		sprite_index = spr_cactus_ew
		audio_play_sound(snd_reveal_cactus, 0, false, 1, 0, random_range(0.95, 1.05))
	}
	original_sprite = spr_cactus_ew
	dmg *= 5
	dmg += spikes
	spikes = round(spikes / 3)
	sympathy_factor = 0.1
}