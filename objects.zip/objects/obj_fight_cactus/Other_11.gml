if has_revealed == 0 or has_revealed == 1
{
	animation_type = "idle"
	if has_revealed
	{
		has_revealed = 2
	}
}
else
{
	if sympathy >= 1
	{
		animation_type = "idle"
	}
	else
	{
		animation_type = "fight"
	}
}