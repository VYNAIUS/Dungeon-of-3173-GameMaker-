event_inherited()

hidden_sprite = spr_cactus_hidden
has_revealed = false