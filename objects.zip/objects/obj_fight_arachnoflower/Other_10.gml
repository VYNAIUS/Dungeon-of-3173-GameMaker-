if random(1) <= 0.5
{
	audio_play_sound(snd_hit_hiss_arachnoflower_0, 0, false, 1, 0, random_range(0.9, 1.1))
}
else
{
	audio_play_sound(snd_hit_hiss_arachnoflower_1, 0, false, 1, 0, random_range(0.9, 1.1))
}