if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	instance_create_depth(xcoord, ycoord - 200, depth - 11, obj_slider_volume_master)
	instance_create_depth(xcoord, ycoord - 90, depth - 11, obj_slider_volume_sfx)
	instance_create_depth(xcoord, ycoord + 20, depth - 11, obj_slider_volume_music)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	instance_create_depth(xcoord, ycoord + 352, depth - 11, obj_text_settings_tip)
	quit_button.can_escape_key = true
}


event_inherited()