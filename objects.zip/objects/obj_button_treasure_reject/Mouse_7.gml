if button_pressed
{
	global.fight_type = "none"
	with obj_shop_item
	{
		event_user(0)
		global.player_money += round(cost * 0.4 * (1  + global.player_money_boost / 100))
	}
	with obj_button_parent
	{
		event_user(0)
	}
	global.player_experience += round(0.5 * xp_needed(global.player_level))
	if global.player_experience >= xp_needed(global.player_level)
	{
		global.player_experience -= xp_needed(global.player_level)
		global.player_level += 1
		level_up()
		instance_create_layer(random_range(200, 1166), random_range(100, 668), "Instances", obj_text_level_up)
		if is_inside_array(global.player_level, [3, 6])
		{
			audio_play_sound(snd_new_skill_magicdefend, 0, false)
		}
		else
		{
			audio_play_sound(snd_level_up, 0, false)
		}
	}
	global.upgrade_description = "treasure_reject"
	global.rejected_treasure_inarow += 1
	instance_create_layer(683, 608, "Instances", obj_button_altar_continue)
}
event_inherited()