event_inherited()

skill_variable = global.player_current_skill_1
event_user(15)