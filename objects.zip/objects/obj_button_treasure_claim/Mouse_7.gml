if button_pressed
{
	global.fight_type = "none"
	with obj_shop_item
	{
		grant_item_upgrade(id_name)
		event_user(0)
	}
	with obj_button_parent
	{
		event_user(0)
	}
	global.rejected_treasure_inarow = 0
	instance_create_layer(683, 608, "Instances", obj_button_altar_continue)
}
event_inherited()