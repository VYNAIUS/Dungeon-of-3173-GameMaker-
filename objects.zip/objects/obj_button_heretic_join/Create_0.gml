event_inherited()
if global.heretic_reputation == 1
{
	instance_destroy()
}