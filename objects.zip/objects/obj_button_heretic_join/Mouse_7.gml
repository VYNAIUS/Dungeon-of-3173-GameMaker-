if button_pressed
{
	if global.change_state > 0
	{
		// rejected cuz change ending
		switch global.heretic_joining_attempts
		{
			case 0:
				dialogue_place("Heretic Join Alliance 0")
				break
			case 1:
				dialogue_place("Heretic Join Alliance 1")
				break
			default:
				dialogue_place("Heretic Join Alliance 2")
				break
		}
	}
	else if global.player_consume <= 0
	{
		// rejected cuz no consume
		switch global.heretic_joining_attempts
		{
			case 0:
				dialogue_place("Heretic Join No Consume 0")
				break
			case 1:
				dialogue_place("Heretic Join No Consume 1")
				break
			default:
				dialogue_place("Heretic Join No Consume 2")
				break
		}
	}
	else
	{
		dialogue_place("Heretic Join Success")
		global.heretic_reputation = 1
		global.shopkeeper_encounters = 0
		global.herbalist_encounters = 0
		global.shopkeeper_suspicion = 0
		global.shopkeeper_debt = 0
		global.shopkeeper_knows = false
		if global.boatperson_encounters == 0
		{
			global.boatperson_encounters = -1
		}
		else
		{
			global.boatperson_encounters = 0
		}
		global.alchemist_encounters = 0
		with obj_button_parent
		{
			event_user(0)
		}
	}
}
global.heretic_joining_attempts += 1
event_inherited()