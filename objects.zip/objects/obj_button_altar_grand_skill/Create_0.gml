event_inherited()

skill_to_gain = "skill_idle"
glyph = instance_create_layer(x, 384, "Instances", obj_altar_glyph_universal)