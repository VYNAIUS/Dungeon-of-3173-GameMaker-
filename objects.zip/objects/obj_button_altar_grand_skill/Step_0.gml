event_inherited()


button_description = skill_to_gain
if instance_exists(glyph)
{
	switch skill_to_gain
	{
		case "skill_split":
			button_text = "Split"
			text_color = #00FF00
			glyph.sprite_index = spr_glyph_vitality
			break
		case "skill_parry":
			button_text = "Parry"
			text_color = #FF0000
			glyph.sprite_index = spr_glyph_strength
			break
		case "skill_impenetrability":
			button_text = "Impenetrate"
			text_color = #00C8FF
			glyph.sprite_index = spr_glyph_protection
			break
		case "skill_reap":
			button_text = "Reap"
			text_color = #FF8000
			glyph.sprite_index = spr_glyph_might
			break
		case "skill_trick":
			button_text = "Trick"
			text_color = #7F007F
			glyph.sprite_index = spr_glyph_innocence
			break
		case "skill_pickpocket":
			button_text = "Pickpocket"
			text_color = #FF007F
			glyph.sprite_index = spr_glyph_pleasure
			break
		case "skill_crystalise":
			button_text = "Crystalise"
			text_color = #FFFF00
			glyph.sprite_index = spr_glyph_mana
			break
	}
}