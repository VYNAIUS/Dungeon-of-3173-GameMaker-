if button_pressed and global.is_turn == false
{
	global.altar_grand_choice = skill_to_gain
	global.button_description = "none"
	global.is_turn = true
	scr_grant_altar_upgrades()
	with obj_altar_glyph_universal
	{
		size_change = -0.02
	}
	glyph.size_change = 0.02
}

event_inherited()
