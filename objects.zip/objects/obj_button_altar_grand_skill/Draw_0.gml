event_inherited()

if global.is_turn == true
{
	image_alpha -= 0.07
	if image_alpha <= 0
	{
		instance_destroy()
	}
}