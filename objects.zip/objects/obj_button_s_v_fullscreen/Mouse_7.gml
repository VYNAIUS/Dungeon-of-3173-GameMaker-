if button_pressed
{
	global.is_fullscreen = not(global.is_fullscreen)
	with (obj_camera_audio_manager)
	{
		event_user(0)
	}
}
event_inherited();