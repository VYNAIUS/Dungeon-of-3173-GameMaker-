if global.is_map_transitioning and image_alpha > 0
{
	image_alpha -= 0.01
	if image_alpha <= 0
	{
		image_alpha = 0
	}
}
else if image_alpha < 0.25 and (not(global.is_dialogue) or not(affected_by_dialogue))
{
	image_alpha += 0.025
}
draw_self()