if random(1) <= 0.5
{
	audio_play_sound(snd_hit_antlion_0, 0, false, 1, 0, random_range(0.65, 0.75))
}
else
{
	audio_play_sound(snd_hit_antlion_1, 0, false, 1, 0, random_range(0.65, 0.75))
}