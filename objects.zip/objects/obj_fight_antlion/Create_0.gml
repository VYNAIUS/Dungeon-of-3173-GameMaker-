event_inherited()
hidden_sprite = spr_antlion_hidden