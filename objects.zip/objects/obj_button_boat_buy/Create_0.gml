event_inherited()

coin_amount = round(power(1.5, global.area_visited) * 20)
if global.area_id == 6
{
	coin_amount = round(coin_amount / 2)
}

button_text = "Pay " + string(coin_amount) + " coins"
if string_length(button_text) > 6
{
	text_scale = 3 / (string_length(button_text) + 5)
}