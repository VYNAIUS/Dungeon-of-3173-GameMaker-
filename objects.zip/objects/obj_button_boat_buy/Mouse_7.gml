if button_pressed
{
	if global.boat_bought
	{
		audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
		dialogue_place("Boat Person Tip")
	}
	else if global.player_money >= coin_amount
	{
		global.player_money -= coin_amount
		global.player_boat_durability += 1
		if global.player_boat_durability > 1.4
		{
			global.player_boat_durability = 1.4
		}
		global.boat_bought = true
		dialogue_place("Boat Person Payment Surprise")
	}
	else
	{
		audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
		dialogue_place("Boat Person Poor")
	}
}
event_inherited()