if button_pressed
{
	create_settings_box(683, 384, 3, 2)
	var quit_button = instance_create_depth(683, 490, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var funny_text = instance_create_depth(683, 590, depth - 11, obj_text)
	funny_text.text = "These are current skills.\nClick on one of them to change"
	funny_text.scale = 0.1875
	var skill_button = instance_create_depth(468, 300, depth - 11, obj_button_inventory_skill)
	with skill_button
	{
		skill_variable = 0
	}
	skill_button = instance_create_depth(898, 300, depth - 11, obj_button_inventory_skill)
	with skill_button
	{
		skill_variable = 1
	}
	instance_create_depth(683, 730, depth - 11, obj_text_current_skill_description)
}
event_inherited()