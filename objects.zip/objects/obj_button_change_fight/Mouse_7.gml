if button_pressed
{
	global.change_reputation = -1
	var possible_dialogue = ["Change Fight Attempt 0"]
	
	if is_inside_array("Change Fight Attempt 0", global.change_told_dialog)
	{
		array_push(possible_dialogue, "Change Fight Attempt 1")
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.change_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		confirmed_dialog = ["Change Fight Attempt 2"]
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if confirmed_dialog[random_index] != "Change Fight Attempt 2"
	{
		array_push(global.change_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()