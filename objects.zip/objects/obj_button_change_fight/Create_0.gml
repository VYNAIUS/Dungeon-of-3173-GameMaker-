event_inherited()

if global.change_state > 0
{
	instance_destroy()
}