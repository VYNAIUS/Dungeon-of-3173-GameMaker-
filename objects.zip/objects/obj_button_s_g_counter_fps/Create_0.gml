event_inherited()

if global.show_fpsreal
{
	button_text = "FPS shown:\nON"
}
else
{
	button_text = "FPS shown:\nOFF"
}