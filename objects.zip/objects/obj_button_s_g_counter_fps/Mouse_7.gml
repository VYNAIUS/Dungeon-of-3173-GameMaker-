if button_pressed
{
	global.show_fpsreal = not(global.show_fpsreal)
	if global.show_fpsreal
	{
		button_text = "FPS shown:\nON"
	}
	else
	{
		button_text = "FPS shown:\nOFF"
	}
}
event_inherited()