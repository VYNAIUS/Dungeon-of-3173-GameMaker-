hspeed = random_range(-5, 5)
vspeed = random_range(-5, -3)
move_to_player = false
speed_percentage = random_range(0.05, 0.1)