draw_self()

if instance_exists(obj_fight_player)
{
	var distance = power(power((obj_fight_player.xstart - x), 2) + power((obj_fight_player.ystart - y), 2), 0.5)
	if distance < 100
	{
		image_alpha = distance / 100
	}
}
else
{
	image_alpha -= 0.05
}