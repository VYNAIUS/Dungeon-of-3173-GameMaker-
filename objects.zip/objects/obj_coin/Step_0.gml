if move_to_player == false
{
	if hspeed != 0
	{
		hspeed -= hspeed * 0.075
		if abs(hspeed) <= 0.1
		{
			hspeed = 0
		}
	}
	if vspeed != 0
	{
		vspeed -= vspeed * 0.075
		if abs(vspeed) <= 0.1
		{
			vspeed = 0
		}
	}
	if vspeed == 0 and hspeed == 0
	{
		move_to_player = true
	}
}
else
{
	if instance_exists(obj_fight_player)
	{
		hspeed = (obj_fight_player.x_hover_position - x) * speed_percentage
		vspeed = (obj_fight_player.ystart - y) * speed_percentage
		if abs(obj_fight_player.x_hover_position - x) < 10 and abs(obj_fight_player.ystart - y) < 10
		{	
			global.player_money += 1
			global.coins_earned += 1
			audio_play_sound(snd_coin_increase, 0, false, 1, 0, random_range(1.95, 2.05))
			instance_destroy()
		}
	}
}