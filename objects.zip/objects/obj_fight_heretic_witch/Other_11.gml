needs_turning = false
with obj_fight_entity
{
	if is_enemy
	{
		if not(is_inside_array(id_name, ["heretic", "spectral_frog", "heretic_summoner", "heretic_witch"]))
		{
			other.needs_turning = true
			break
		}
	}
}
if sympathy < 1
{
	if needs_turning
	{
		animation_type = "summon"
	}
	else
	{
		global.xp_to_be_gained -= xp
		coins = 0
		animation_type = "idle"
		hp = 0
	}
}
else
{
	animation_type = "idle"
}