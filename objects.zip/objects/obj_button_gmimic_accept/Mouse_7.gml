if button_pressed
{
	grant_item_upgrade(global.gmimic_current_item.id_name)
	global.gmimic_item_shown = false
	global.gmimic_items_sold += 1
	with obj_shop_item
	{
		event_user(0)
	}
	with obj_button_gmimic_reroll
	{
		button_text = "Pay for\nanother"
	}
	event_user(0)
}
event_inherited()