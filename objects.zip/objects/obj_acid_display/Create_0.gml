image_alpha = 0
target_alpha = 0
image_blend = global.area_water_map_colors[6]