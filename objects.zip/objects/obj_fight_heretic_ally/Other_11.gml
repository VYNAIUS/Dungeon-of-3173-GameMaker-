var should_attack_target = false
if global.action_type == "fight_specific"
{
	if instance_exists(global.specific_target)
	{
		if not(global.specific_target.death_played)
		{
			should_attack_target = true
		}
	}
}
if is_inside_array(global.action_type, ["fight", "soul_reap", "cleanse", "crystalise", "split"]) or (global.action_type == "fight_specific" and not(should_attack_target))
{
	animation_type = "fight"
}
else if global.action_type == "fight_specific"
{
	animation_type = "fight_specific"
	action_target = global.specific_target
}
else if is_inside_array(global.action_type, ["defend", "idle", "impenetrability_regen", "parry", "pickpocket"])
{
	animation_type = "defend"
}
else if global.action_type == "magic_defend"
{
	animation_type = "magic_defend"
}
else if global.action_type == "trick"
{
	animation_type = "idle"
}
else
{
	animation_type = "idle"
}