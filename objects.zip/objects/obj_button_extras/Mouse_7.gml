if button_pressed
{
	dialogue_place("3174: Extras")
}
event_inherited()