event_inherited()
if not(global.is_map_transitioning or global.is_dialogue or destroy_self) and not(global.game_story_finished)
{
	if pressable
	{
		event_user(2)
	}
	pressable = false
	target_alpha = 0.3
}