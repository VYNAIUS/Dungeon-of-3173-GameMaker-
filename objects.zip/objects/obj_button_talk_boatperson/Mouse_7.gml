if button_pressed
{
	var possible_dialogue = ["Boat Person Talk: Shopkeeper", "Boat Person Talk: Everwarrior"]
	
	if global.area_visited > array_length(global.area_names) and global.game_mode == "infinite"
	{
		array_push(possible_dialogue, "Boat Person Talk: Infinite Mode")
	}
	if global.area_id == 2
	{
		array_push(possible_dialogue, "Boat Person Talk: Cave")
	}
	if global.area_id == 3
	{
		array_push(possible_dialogue, "Boat Person Talk: Tundra")
	}
	if global.area_id == 4
	{
		array_push(possible_dialogue, "Boat Person Talk: Canyon")
	}
	if global.area_id == 6
	{
		array_push(possible_dialogue, "Boat Person Talk: Rotten Life")
		array_push(possible_dialogue, "Boat Person Talk: Life Giver")
	}
	if global.boatperson_encounters >= 3
	{
		array_push(possible_dialogue, "Boat Person Talk: Alchemist")
		if global.boatperson_encounters >= 4
		{
			array_push(possible_dialogue, "Boat Person Talk: Stare")
		}
	}
	if global.player_current_skill_0 == "reap" or global.player_current_skill_1 == "reap"
	{
		array_push(possible_dialogue, "Boat Person Talk: Reap")
	}
	if global.death_state == 1
	{
		array_push(possible_dialogue, "Boat Person Talk: Change Plan")
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.boatperson_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		confirmed_dialog = ["Boat Person Talk: No Dialog"]
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if confirmed_dialog[random_index] != "Boat Person Talk: No Dialog"
	{
		array_push(global.boatperson_told_dialog, confirmed_dialog[random_index])
	}
	if confirmed_dialog[random_index] == "Boat Person Talk: Stare"
	{
		obj_shop_player.sprite_index = spr_player_eyesdifferent
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()