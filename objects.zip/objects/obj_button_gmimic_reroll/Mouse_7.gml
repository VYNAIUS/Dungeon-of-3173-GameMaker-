if button_pressed
{
	if global.gmimic_items_sold <= 5
	{
		var cost = round(10 * power(1.5, global.area_visited + global.gmimic_items_sold - 1))
		if not(global.gmimic_item_shown)
		{
			cost *= 2
		}
	
		if global.player_money >= cost
		{
			if global.gmimic_item_shown == false
			{
				button_text = "Reroll"
			}
			golden_mimic_new_item()
			global.player_money -= cost
		}
		else
		{
			audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
			if round(random(1)) == 0
			{
				dialogue_place("Golden Mimic Poor 0")
			}
			else
			{
				dialogue_place("Golden Mimic Poor 1")
			}
		}
	}
	else
	{
		audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
		dialogue_place("Golden Mimic Tired")
	}
}
event_inherited()