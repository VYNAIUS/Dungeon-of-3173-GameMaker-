if instance_exists(obj_fight_player) and not(obj_fight_player.death_played)
{
	action_target = obj_fight_player.id
	animation_type = "soul_reap"
}
else
{
	animation_type = "idle"
}