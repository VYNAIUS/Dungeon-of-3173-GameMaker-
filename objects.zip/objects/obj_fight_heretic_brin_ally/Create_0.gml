event_inherited()
escaping = false
should_escape = false
entities_ignored = ["spirit_fear", "fear_spawn"]