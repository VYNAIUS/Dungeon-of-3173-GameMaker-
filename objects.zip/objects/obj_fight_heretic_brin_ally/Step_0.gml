event_inherited()

if global.fight_type != "3173"
{
	if hp - total_dealt_damage < max_hp * 0.1
	{
		hp = ceil(max_hp * 0.1)
		death_played = false
		total_dealt_damage = 0
		should_escape = true
	}
	if not(escaping) and not(global.is_turn) and should_escape
	{
		if not(global.is_dialogue)
		{
			global.heretic_deaths += 1
			switch global.heretic_deaths
			{
				case 0:
					dialogue_place("Brin Too Low HP 0")
					break
				case 1:
					dialogue_place("Brin Too Low HP 1")
					break
				default:
					dialogue_place("Brin Too Low HP 2")
					break
			}
		}
	}
}
if escaping
{
	hspeed = -10
	x_hover_position = -140
	if x < -140
	{
		instance_destroy()
		with obj_fight_turn_manager
		{
			event_user(0)
		}
		global.is_turn = false
	}
}