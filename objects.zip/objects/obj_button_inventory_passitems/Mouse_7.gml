if button_pressed
{
	with obj_fight_entity
	{
		cursor_hovering_over = false
	}
	create_settings_box(683, 384, 3, 3, true)
	var starting_point = 0
	if room == rom_gameover
	{
		starting_point = (global.current_ui_layer - 1) * 12
	}
	else if room == rom_map
	{
		starting_point = (global.current_ui_layer - 2) * 12
	}
	var x_level = 452
	var y_level = 75
	var counter_limit = starting_point + 11
	var is_over_flow = false
	for (var i = starting_point; i < array_length(global.player_passive_items); i++)
	{
		var button = instance_create_depth(x_level, y_level, depth - 11, obj_button_item_passive)
		global.player_current_fight_passive_items[i].depth = depth - 11
		button.fight_item_index = i
		with button
		{
			event_user(15)
		}
		if i % 3 == 2
		{
			x_level = 452
			y_level += 120
		}
		else if i % 3 == 0
		{
			x_level = 683
		}
		else
		{
			x_level = 914
		}
		if i >= counter_limit
		{
			if array_length(global.player_current_fight_passive_items) > counter_limit + 1
			{
				is_over_flow = true
			}
			break
		}
	}
	instance_create_depth(452, 672, depth - 11, obj_item_box_fight)
	instance_create_depth(780, 672, depth - 11, obj_text_fight_item_desc)
	instance_create_depth(780, 630, depth - 11, obj_text_fight_item_name)
	var return_button = instance_create_depth(580, 540, depth - 11, obj_button_settings_quit)
	return_button.image_xscale = 0.75
	return_button.image_yscale = 0.75
	return_button.text_scale = 0.1875
	return_button.can_escape_key = true
	if is_over_flow
	{
		return_button = instance_create_depth(786, 540, depth - 11, obj_button_inventory_passitems)
		return_button.image_xscale = 0.75
		return_button.image_yscale = 0.75
		return_button.text_scale = 0.1875
		return_button.button_text = "Next Page"
	}
}

event_inherited()