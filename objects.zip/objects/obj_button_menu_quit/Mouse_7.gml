if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord - 20, 3, 1)
	var no = instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_settings_quit)
	instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_menu_quit_confirm)
	var text = instance_create_depth(xcoord, ycoord - 108, depth - 11, obj_text)
	no.button_text = "No"
	no.text_scale = 0.5
	no.text_color = #00FF00
	no.can_escape_key = true
	text.text = "Do you really want to abandon this run?"
	text.scale = 0.1875
}

event_inherited()