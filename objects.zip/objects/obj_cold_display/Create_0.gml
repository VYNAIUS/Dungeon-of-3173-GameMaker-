image_alpha = 0
target_alpha = 0
image_blend = global.area_map_colors[3]