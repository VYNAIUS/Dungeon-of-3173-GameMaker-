if image_alpha < target_alpha
{
	image_alpha += 0.03
	if image_alpha > target_alpha
	{
		image_alpha = target_alpha
	}
}
else if image_alpha > target_alpha
{
	image_alpha -= 0.03
	if image_alpha < target_alpha
	{
		image_alpha = target_alpha
	}
}

if global.is_map_transitioning
{
	target_alpha = 0
}
else
{
	target_alpha = - (global.current_temperature + 3) / 10
	if target_alpha < 0
	{
		target_alpha = 0
	}
}