if button_pressed
{
	if global.npc_song_played != undefined
	{
		audio_sound_gain(global.npc_song_played, 0, 1000)
	}
	if not(global.final_area)
	{
		global.change_reputation = 1
		global.change_state = 1
		global.change_encounters = 0
		dialogue_place("Change Help")
	}
	else
	{
		global.change_state = 2
		dialogue_place("Change Help Garden 0")
	}
}
event_inherited()