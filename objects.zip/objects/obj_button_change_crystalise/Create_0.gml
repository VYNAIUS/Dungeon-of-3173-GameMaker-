event_inherited()

if global.player_current_skill_0 != "crystalise" and global.player_current_skill_1 != "crystalise"
{
	instance_destroy()
}