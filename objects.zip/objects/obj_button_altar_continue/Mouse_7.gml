if button_pressed
{
	global.fear_trick_refusal -= 1
	switch global.fight_type
	{
		case "none":
			global.fight_type = "none"
			transition_to_map()
			break
		case "elite":
			transition_to_treasure()
			break
		case "boss":
			global.fight_type = "none"
			transition_to_escape_main()
			break
		case "shopkeeper_fight":
			global.fight_type = "none"
			global.shopkeeper_deaths += 1
			transition_to_map()
			break
		case "herbalist_fight":
			global.fight_type = "none"
			transition_to_map()
			break
		case "alchemist_fight":
			global.fight_type = "none"
			global.alchemist_deaths += 1
			transition_to_alchemist_secondary()
			break
		case "change_fight":
			global.fight_type = "none"
			if global.player_consume <= 0
			{
				global.change_state = -1
			}
			else
			{
				global.change_state = -2
			}
			transition_to_map()
			break
		case "death_fight":
			global.fight_type = "none"
			if global.death_state == 1 and instance_exists(obj_fight_death_body)
			{
				global.death_state = 2
			}
			else if global.death_state == 0
			{
				if instance_exists(obj_fight_death)
				{
					global.death_state = -1
				}
				else
				{
					global.death_state = -2
				}
			}
			transition_to_map()
			break
		case "seeker_fight":
			global.fight_type = "none"
			global.seeker_defeated = true
			transition_to_map()
			break
		case "heretic_tutorial_fight":
			global.fight_type = "none"
			transition_to_map()
			break
		case "3173":
			global.fight_type = "none"
			global.end_condition = "win"
			if global.game_mode == "story"
			{
				global.game_story_finished = true
				if global.heretic_reputation == 1
				{
					global.game_ending_H = true
				}
				else if global.change_state == 2
				{
					if global.death_state == 2
					{
						global.game_ending_PB = true
					}
					else
					{
						global.game_ending_CD = true
					}
				}
				else if global.change_state == -1
				{
					global.game_ending_SM = true
				}
				else if global.change_state == -2
				{
					if global.death_state == -2
					{
						global.game_ending_GC = true
					}
					else
					{
						global.game_ending_FV = true
					}
				}
				else
				{
					global.game_ending_3174 = true
					if global.midas_state == 1
					{
						global.game_ending_M = true
					}
				}
			}
			transition_to_gameover()
			break
	}
}
event_inherited()