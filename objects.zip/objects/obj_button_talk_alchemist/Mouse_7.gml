if button_pressed
{
	if global.alchemist_anger < 0.4
	{
		var possible_dialogue = []
	
		if global.area_id == 2
		{
			array_push(possible_dialogue, "Alchemist Talk: Cave")
			if global.game_mode == "infinite"
			{
				array_push(possible_dialogue, "Alchemist Talk: Infinite Mode")
			}
		}
		if global.area_id == 3
		{
			array_push(possible_dialogue, "Alchemist Talk: Tundra")
		}
		else if global.area_id == 5
		{
			array_push(possible_dialogue, "Alchemist Talk: Desert")
		}
		if global.area_id > 3
		{
			array_push(possible_dialogue, "Alchemist Talk: Houses")
			array_push(possible_dialogue, "Alchemist Talk: Seeker")
			if global.area_id > 4 and global.alchemist_anger <= 0
			{
				if global.player_consume <= 0
				{
					array_push(possible_dialogue, "Alchemist Talk: Consume")
				}
			}
		}
		if is_inside_array(4, global.current_weathers)
		{
			array_push(possible_dialogue, "Alchemist Talk: Sandstorm")
		}
		
		if global.player_fear > 0 and global.midas_state == 0
		{
			array_push(possible_dialogue, "Alchemist Talk: Fear")
		}
		
		if global.heretic_reputation == 1
		{
			array_push(possible_dialogue, "Alchemist Talk: Heretic")
		}
	
		var confirmed_dialog = []
		for (var i = 0; i < array_length(possible_dialogue); i++)
		{
			var place_it = true
			var dialogue_line = possible_dialogue[i]
			if is_inside_array(dialogue_line, global.alchemist_told_dialog)
			{
				place_it = false
			}
			if place_it
			{
				array_push(confirmed_dialog, dialogue_line)
			}
		}
	
		if array_length(confirmed_dialog) == 0
		{
			confirmed_dialog = ["Alchemist Talk: No Dialog 0", "Alchemist Talk: No Dialog 1"]
			if global.area_id != 2 and global.change_state == 0
			{
				if is_inside_array("Golden Mimic Talk: Pickpocket", global.gmimic_told_dialog) and not(is_inside_array("Alchemist Talk: Midas Quest 0", global.alchemist_told_dialog))
				{
					confirmed_dialog = ["Alchemist Talk: Midas Quest 0"]
				}
				if global.player_money_boost >= 20
				{
					if is_inside_array("Alchemist Talk: Midas Quest 0", global.alchemist_told_dialog) and not(is_inside_array("Alchemist Talk: Midas Quest 1", global.alchemist_told_dialog))
					{
						confirmed_dialog = ["Alchemist Talk: Midas Quest 1"]
					}
					if global.seeker_defeated
					{
						if is_inside_array("Alchemist Talk: Midas Quest 1", global.alchemist_told_dialog) and not(is_inside_array("Alchemist Talk: Midas Quest 2", global.alchemist_told_dialog))
						{
							confirmed_dialog = ["Alchemist Talk: Midas Quest 2"]
						}
					}
				}
			}
		}
		var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
		if not(is_inside_array(confirmed_dialog[random_index], ["Alchemist Talk: No Dialog 0", "Alchemist Talk: No Dialog 1"]))
		{
			array_push(global.alchemist_told_dialog, confirmed_dialog[random_index])
		}
		dialogue_place(confirmed_dialog[random_index])
	}
	else
	{
		var possible_dialogue = ["Alchemist Talk: Angry 0", "Alchemist Talk: Angry 1"]
		var random_index = round(random_range(0, array_length(possible_dialogue) - 1))
		dialogue_place(possible_dialogue[random_index])
	}
}
event_inherited()