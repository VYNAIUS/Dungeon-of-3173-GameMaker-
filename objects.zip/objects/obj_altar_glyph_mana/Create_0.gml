event_inherited()

global.altar_choice = "none"
global.corrupted_altar_encounters = 1