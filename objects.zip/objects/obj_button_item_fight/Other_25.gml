button_text = global.player_current_fight_items[fight_item_index].name
var max_length = 0
var current_length = 0
for (var i = 1; i <= string_length(button_text); i++)
{
	if string_char_at(button_text, i) == "\n"
	{
		current_length = 0
	}
	else
	{
		current_length += 1
	}
	if max_length < current_length
	{
		max_length = current_length
	}
}
text_scale = 3 / (max_length + 5)
text_scale /= 1.25
button_description = global.player_current_fight_items[fight_item_index].id_name + string(fight_item_index)