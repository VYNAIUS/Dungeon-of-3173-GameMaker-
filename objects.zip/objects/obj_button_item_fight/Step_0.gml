event_inherited()

var hovering_over_enemy = false
with obj_fight_entity
	{
		if cursor_hovering_over
		{
			hovering_over_enemy = true
			break
		}
	}
	
if hovering_over_enemy and not destroy_self
{
	target_alpha = 0.3
}