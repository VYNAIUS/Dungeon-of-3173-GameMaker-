event_inherited()

image_xscale = 0.75
image_yscale = 0.75
button_text = global.player_current_fight_items[fight_item_index].name
event_user(15)