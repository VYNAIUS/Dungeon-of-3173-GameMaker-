if button_pressed
{
	var item_to_use = global.player_current_fight_items[fight_item_index].id_name
	
	global.button_description = "none"
	if scr_use_consumable(item_to_use)
	{
		array_delete(global.player_current_fight_items, fight_item_index, 1)
		array_delete(global.player_consumable_items, fight_item_index, 1)
	
		for (var i = 0; i < array_length(global.player_current_fight_items); i++)
		{
			global.player_current_fight_items[i].self_index = i
		}
		
		if room == rom_fight
		{
			lower_ui_layer(0)
		}
		else
		{
			lower_ui_layer(1)
		}
	
		global.is_selecting_item = false
	}
}
event_inherited()