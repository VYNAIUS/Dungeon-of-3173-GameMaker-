if button_pressed
{
	main_reset()
	if file_exists("run_save_checkpoint")
	{
		scr_load_saved_data("run_save_checkpoint")
	}
	else
	{
		global.run_version = global.game_version
	}
	transition_to_area_popup()
}
event_inherited()