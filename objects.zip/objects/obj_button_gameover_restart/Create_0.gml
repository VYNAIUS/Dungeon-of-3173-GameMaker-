event_inherited()

if global.end_condition == "lose"
{
	if file_exists("run_save_checkpoint")
	{
		button_text = "Persist"
	}
}
else
{
	instance_destroy()
}