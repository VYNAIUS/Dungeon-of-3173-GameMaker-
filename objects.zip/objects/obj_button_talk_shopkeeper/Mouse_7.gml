if button_pressed
{
	var possible_dialogue = []
	if global.heretic_reputation == 1
	{
		possible_dialogue = ["Shopkeeper Talk: Boat Person Brin", "Shopkeeper Talk: Prophet Brin",
		"Shopkeeper Talk: Life Brin"]
		if global.area_visited > array_length(global.area_names) and global.game_mode == "infinite"
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Infinite Mode Brin")
		}
	}
	else
	{
		possible_dialogue = ["Shopkeeper Talk: Introduction", "Shopkeeper Talk: Alchemist"]
		if instance_exists(obj_shop_item_poison_flask)
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Poison Flask Ad")
		}
		if instance_number(obj_shop_item_nothing) == 3
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Empty Shop")
		}
		if global.boatperson_encounters >= 1
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Boat Person")
		}
		if global.area_visited > array_length(global.area_names) and global.game_mode == "infinite"
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Infinite Mode")
		}
		if is_inside_array(1, global.current_weathers)
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Rain")
		}
		if is_inside_array(2, global.current_weathers)
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Fog")
		}
		if is_inside_array(3, global.current_weathers)
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Blizzard")
		}
		if is_inside_array(4, global.current_weathers)
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Sandstorm")
		}
		if global.area_id == 4
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Canyon")
		}
		if global.area_id > 4 and global.shopkeeper_deaths == 0 and global.shopkeeper_suspicion == 0
		{
			array_push(possible_dialogue, "Shopkeeper Talk: Orphan")
		}
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.shopkeeper_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		if global.heretic_reputation == 1
		{
			confirmed_dialog = ["Shopkeeper Talk: No Dialog Brin 0"]
		}
		else
		{
			confirmed_dialog = ["Shopkeeper Talk: No Dialog 0", "Shopkeeper Talk: No Dialog 1"]
		}
	}
	
	if global.game_time < 6
	{
		confirmed_dialog = ["Shopkeeper Talk: Sleep"]
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if not(is_inside_array(confirmed_dialog[random_index], ["Shopkeeper Talk: No Dialog 0", "Shopkeeper Talk: No Dialog 1", "Shopkeeper Talk: Sleep", "Shopkeeper Talk: No Dialog Brin 0"]))
	{
		array_push(global.shopkeeper_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()