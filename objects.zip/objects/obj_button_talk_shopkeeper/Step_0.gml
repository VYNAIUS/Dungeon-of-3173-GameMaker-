// Inherit the parent event
event_inherited();

if global.shopkeeper_dead_rn and global.is_map_transitioning == false and ui_layer == global.current_ui_layer
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0.3
	pressable = false
}