if button_pressed
{
	if global.current_exit_type == "shortcut"
	{
		enter_new_area(3)
	}
	else
	{
		enter_new_area()
	}
}

event_inherited()