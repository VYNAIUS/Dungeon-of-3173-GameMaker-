// Inherit the parent event
event_inherited();

shop_item_index = 0