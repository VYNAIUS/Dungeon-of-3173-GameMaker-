if button_pressed
{
	shop_buy(shop_item_index)
	if global.heretic_reputation == 1
	{
		global.player_money -= round(global.shopkeeper_items[shop_item_index].cost * 0.5)
	}
	else
	{
		global.player_money -= global.shopkeeper_items[shop_item_index].cost
	}
	instance_destroy(global.shopkeeper_items[shop_item_index])
	global.shopkeeper_items[shop_item_index] = instance_create_layer(obj_shop_initator.x, obj_shop_initator.y, "Instances", obj_shop_item_nothing)
	global.shopkeeper_items[shop_item_index].self_index = shop_item_index
	with (obj_button_item)
	{
		if shop_item_index == other.shop_item_index
		{
			button_text = global.shopkeeper_items[shop_item_index].name
			if string_length(button_text) > 6
			{
				text_scale = 3 / (string_length(button_text) + 5)
			}
		}
	}
	global.button_description = "none"
	
	lower_ui_layer()
}

event_inherited()