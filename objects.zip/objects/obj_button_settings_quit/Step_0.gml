event_inherited()

if fade_away_when_enemies and not destroy_self
{
	var hovering_over_enemy = false
	with obj_fight_entity
	{
		if cursor_hovering_over
		{
			hovering_over_enemy = true
			break
		}
	}
	if hovering_over_enemy
	{
		target_alpha = 0.3
	}
}
if keyboard_check_pressed(vk_escape) and pressable and can_escape_key
{
	global.pause_delay = true
	if save_settings
	{
		scr_settings_save()
	}
	if fade_away_when_enemies and ((global.current_ui_layer == 1 and room == rom_fight) or (global.current_ui_layer == 2 and room == rom_map))
	{
		global.is_selecting_item = false
	}
	global.button_description = "none"
	lower_ui_layer()
}