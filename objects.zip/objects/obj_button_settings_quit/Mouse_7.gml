if button_pressed
{
	if save_settings
	{
		scr_settings_save()
	}
	if fade_away_when_enemies and ((global.current_ui_layer == 1 and room == rom_fight) or (global.current_ui_layer == 2 and room == rom_map))
	{
		global.is_selecting_item = false
	}
	global.button_description = "none"
	lower_ui_layer()
}
event_inherited()