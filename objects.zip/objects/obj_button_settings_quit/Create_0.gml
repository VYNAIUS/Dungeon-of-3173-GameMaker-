// Inherit the parent event
event_inherited();

fade_away_when_enemies = false