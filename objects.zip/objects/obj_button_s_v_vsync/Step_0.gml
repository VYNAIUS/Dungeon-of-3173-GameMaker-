// Inherit the parent event
event_inherited();

if global.is_vsync
{
	button_text = "Vsync: ON"
}
else
{
	button_text = "Vsync: OFF"
}