if button_pressed
{
	global.is_vsync = not(global.is_vsync)
	with (obj_camera_audio_manager)
	{
		event_user(0)
	}
}
event_inherited();