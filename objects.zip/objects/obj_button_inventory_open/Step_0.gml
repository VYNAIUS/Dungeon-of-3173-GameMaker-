event_inherited()

y = obj_map_ui.y + 32