if button_pressed
{
	create_settings_box(683, 384, 2.75, 2)
	instance_create_depth(503, 230, depth - 11, obj_button_inventory_stats)
	instance_create_depth(863, 230, depth - 11, obj_button_inventory_skill_choose)
	instance_create_depth(503, 380, depth - 11, obj_button_items_open)
	instance_create_depth(863, 380, depth - 11, obj_button_inventory_passitems)
	var quit_button = instance_create_depth(683, 550, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	if global.skill_tutorial == 1
	{
		global.skill_tutorial = 2
	}
}
event_inherited()