if button_pressed
{
	if not(global.smimic_locked) and obj_shop_smimic.are_you_suore and global.smimic_money > 0
	{
		if global.smimic_encounters == 1
		{
			dialogue_place("Steel Mimic Stop Tutorial")
			instance_create_layer(683, 140, "Instances_UI", obj_button_smimic_lock)
			global.smimic_encounters += 1
		}
		else
		{
			dialogue_place("Steel Mimic Stop")
			obj_shop_smimic.are_you_suore = false
		}
	}
	else
	{
		transition_to_map()
	}
}
event_inherited()