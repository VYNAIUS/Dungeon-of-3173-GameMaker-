if button_pressed and global.fighting_choice == "hit"
{
	global.action_type = "fight"
	global.action_done = true
	global.is_turn = true
	global.fighting_choice = "none"
}
event_inherited()