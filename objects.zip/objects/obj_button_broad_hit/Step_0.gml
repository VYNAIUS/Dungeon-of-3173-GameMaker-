event_inherited()

if global.is_turn or obj_fight_turn_manager.enemies_needed_to_be_done < 2
{
	event_user(0)
}