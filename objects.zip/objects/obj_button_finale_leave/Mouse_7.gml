if button_pressed
{
	transition_to_map()
}
event_inherited()