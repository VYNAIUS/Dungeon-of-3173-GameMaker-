shader_set(shd_saturation)
shader_set_uniform_f(shader_get_uniform(shd_saturation, "u_saturation"), regeneration / original_regeneration * 0.9 + 0.1)
event_inherited()