if item_type == "heal"
{
	var actual_heal_amount = max_hp - hp
	total_heal_amount += actual_heal_amount
	var fake_heal_numb = "69"
	while real(fake_heal_numb) < actual_heal_amount
	{
		fake_heal_numb = fake_heal_numb + "69"
	}
	var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_hploss)
	funny_text.dmg_amount = - fake_heal_numb
	funny_text.text_color = #00FF00
}
else if item_type == "imper"
{
	max_impenetrability += 2
	impenetrability = max_impenetrability + 1
	if imper_thing == undefined or not(instance_exists(imper_thing))
	{
		imper_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_impenetrability)
		imper_thing.follower = id
	}
	var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
	funny_text.text = "Now Impenetrable!"
	funny_text.text_color = #00FFFF
}
else if item_type == "stun"
{
	if obj_fight_turn_manager.good_guys_needed_to_be_done > 0
	{
		with obj_fight_entity
		{
			if not(is_enemy)
			{
				stunned += 3
				stunned_type = "none"
				var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				funny_text.text = "Stunned"
				funny_text.text_color = #FFFF64
			}
		}
	}
}
else if item_type == "berserk"
{
	var dmg_increase = round(original_dmg * 0.3)
	dmg += dmg_increase
	var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_dmgincrease)
	funny_text.dmg_amount = dmg_increase
	var crt_increase = round(crit_chance * 150) / 100 - crit_chance
	crit_chance += crt_increase
	funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_crtincrease)
	funny_text.crt_amount = crt_increase
}
item_type = "none"