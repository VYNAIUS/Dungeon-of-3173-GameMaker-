if item_type == "heal" or item_type == "imper" or item_type == "berserk"
{
	item_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_item)
	if item_type == "heal"
	{
		item_thing.sprite_index = spr_item_potion_heal
	}
	else if item_type == "imper"
	{
		item_thing.sprite_index = spr_item_potion_impenetrability
	}
	else if item_type == "berserk"
	{
		item_thing.sprite_index = spr_item_potion_berserk
	}
}
else if item_type == "stun"
{
	with obj_fight_player
	{
		item_thing = instance_create_layer(x, y - 100, "Instances_FX", obj_fight_vf_item)
		item_thing.sprite_index = spr_item_potion_stun
	}
}