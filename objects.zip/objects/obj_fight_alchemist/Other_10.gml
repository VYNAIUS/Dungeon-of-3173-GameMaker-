audio_play_sound(snd_hit_heavy, 0, false, 1, 0, random_range(0.95, 1.05))
var random_sound = round(random(3))
switch random_sound
{
	case 0:
		audio_play_sound(snd_hit_alchemist_0, 0, false)
		break
	case 1:
		audio_play_sound(snd_hit_alchemist_1, 0, false)
		break
	case 2:
		audio_play_sound(snd_hit_alchemist_2, 0, false)
		break
	case 3:
		audio_play_sound(snd_hit_alchemist_3, 0, false)
		break
}