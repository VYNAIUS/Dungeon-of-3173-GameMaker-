event_inherited()

hidden_sprite = spr_alchemist_hidden
item_type = "none"
heal_potions = 3
stun_potions = 2
imper_potions = 2
berserk_potions = 2
just_healed = false

if global.alchemist_deaths > 0
{
	sympathy_factor = 0.05
}