if just_healed and imper_potions > 0
{
	item_type = "imper"
	animation_type = "item_use"
	imper_potions -= 1
	just_healed = false
}
else if stun_potions > 0
{
	item_type = "stun"
	animation_type = "item_use"
	stun_potions -= 1
}
else if berserk_potions >= heal_potions and berserk_potions > 0
{
	item_type = "berserk"
	animation_type = "item_use"
	berserk_potions -= 1
}
else if max_hp * 0.6 >= hp and heal_potions > 0
{
	item_type = "heal"
	animation_type = "item_use"
	heal_potions -= 1
	just_healed = true
}
else if imper_potions + heal_potions + stun_potions == 0 and original_max_hp * 0.5 >= hp or sympathy >= 1
{
	animation_type = "none"
	dialogue_place("Alchemist Fight End")
}
else
{
	if stunned <= 0
	{
		animation_type = "fight"
	}
	else
	{
		animation_type = "idle"
	}
}