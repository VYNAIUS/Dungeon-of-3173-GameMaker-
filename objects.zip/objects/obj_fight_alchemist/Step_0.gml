event_inherited()

if hp - total_dealt_damage <= max_hp * 0.1
{
	total_dealt_damage = 0
	hp = floor(max_hp * 0.1)
	death_played = false
}
if instance_number(obj_fight_alchemist) >= 2 and not(is_inside_array("Alchemist Cloned", global.alchemist_told_dialog)) and not(global.is_dialogue)
{
	dialogue_place("Alchemist Cloned")
	array_push(global.alchemist_told_dialog, "Alchemist Cloned")
}