event_inherited()
hidden_sprite = sprite_index