if sympathy < 1
{
	animation_type = "fight_specific"
	if instance_exists(obj_fight_player)
	{
		action_target = obj_fight_player.id
	}
	else
	{
		animation_type = "fight"
	}
}
else
{
	animation_type = "idle"
}