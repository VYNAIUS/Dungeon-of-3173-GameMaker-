if button_pressed
{
	var current_cost = obj_shop_text_cost_herbalist.cost
	var should_save = false
	if global.herbalist_encounters < 2
	{
		if global.herbalist_fool_tried == 0
		{
			dialogue_place("Herbalist Save Too Early 0")
		}
		else
		{
			dialogue_place("Herbalist Save Too Early 1")
		}
		global.herbalist_fool_tried += 1
	}
	else if global.player_money >= current_cost
	{
		should_save = true
		switch global.player_saved_times
		{
			case 0:
				dialogue_place("Herbalist Save 0")
				break
			case 1:
				dialogue_place("Herbalist Save 1")
				break
			case 2:
				dialogue_place("Herbalist Save 2")
				break
			default:
				dialogue_place("Herbalist Save 3")
				break
		}
		global.player_money -= current_cost
	}
	else if global.player_money >= current_cost * 0.9
	{
		should_save = true
		switch global.player_saved_times
		{
			case 0:
				dialogue_place("Herbalist Save 0 Broke")
				break
			case 1:
				dialogue_place("Herbalist Save 1 Broke")
				break
			case 2:
				dialogue_place("Herbalist Save 2 Broke")
				break
			default:
				dialogue_place("Herbalist Save 3 Broke")
				break
		}
		global.player_money = 0
	}
	else
	{
		audio_play_sound(snd_click_1, 0, false, 1, 0, 0.5)
		dialogue_place("Herbalist Poor")
	}
	if should_save
	{
		global.player_saved_times += 1
		with obj_shop_text_cost_herbalist
		{
			event_user(0)
		}
		scr_run_save(true)
	}
}

event_inherited()