event_inherited()
if global.herbalist_encounters < 2
{
	target_alpha = 0
}