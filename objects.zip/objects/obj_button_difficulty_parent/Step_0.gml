event_inherited()

button_description = difficulty