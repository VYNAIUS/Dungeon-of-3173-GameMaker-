if button_pressed
{
	switch difficulty
	{
		case "easy":
			global.game_original_difficulty = 40
			break
		case "medium":
			global.game_original_difficulty = 55
			break
		case "hard":
			global.game_original_difficulty = 70
			break
		case "absurd":
			global.game_original_difficulty = 100
			break
	}
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	instance_create_depth(xcoord, ycoord - 128, depth - 11, obj_button_play)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var text = instance_create_depth(xcoord, ycoord - 256, depth - 11, obj_text)
	text.text = "Difficulty: " + button_text + "\nGame Mode: "
	switch global.game_original_mode
	{
		case "infinite":
			text.text = text.text + "Infinite"
			break
		case "story":
			text.text = text.text + "Story"
			break
	}
	global.button_description = "none"
}
event_inherited();