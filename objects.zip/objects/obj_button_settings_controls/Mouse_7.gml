if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 4, 2.5)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	instance_create_depth(xcoord - 384, ycoord - 192, depth - 11, obj_keybind_up)
	var text = instance_create_depth(xcoord - 248, ycoord - 192, depth - 11, obj_text)
	text.text = "Up"
	instance_create_depth(xcoord - 384, ycoord - 64, depth - 11, obj_keybind_left)
	text = instance_create_depth(xcoord - 248, ycoord - 64, depth - 11, obj_text)
	text.text = "Left"
	instance_create_depth(xcoord - 384, ycoord + 64, depth - 11, obj_keybind_down)
	text = instance_create_depth(xcoord - 248, ycoord + 64, depth - 11, obj_text)
	text.text = "Down"
	instance_create_depth(xcoord - 64, ycoord - 192, depth - 11, obj_keybind_right)
	text = instance_create_depth(xcoord + 72, ycoord - 192, depth - 11, obj_text)
	text.text = "Right"
	instance_create_depth(xcoord - 64, ycoord - 64, depth - 11, obj_keybind_continue)
	text = instance_create_depth(xcoord + 72, ycoord - 64, depth - 11, obj_text)
	text.text = "Continue"
	instance_create_depth(xcoord - 64, ycoord + 64, depth - 11, obj_keybind_stand)
	text = instance_create_depth(xcoord + 72, ycoord + 64, depth - 11, obj_text)
	text.text = "Map Skill"
	instance_create_depth(xcoord + 256, ycoord - 192, depth - 11, obj_keybind_boat)
	text = instance_create_depth(xcoord + 392, ycoord - 192, depth - 11, obj_text)
	text.text = "Boat"
	instance_create_depth(xcoord, ycoord + 352, depth - 11, obj_text_settings_tip)
}


event_inherited()