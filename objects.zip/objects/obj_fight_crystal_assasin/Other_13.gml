// Inherit the parent event
event_inherited();

scr_battle_spawn(obj_fight_crystal_enemy)