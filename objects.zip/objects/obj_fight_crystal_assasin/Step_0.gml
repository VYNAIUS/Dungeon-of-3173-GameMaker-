event_inherited()

if sympathy >= 1
{
	if dialogue_progress == 0 and not(global.is_dialogue)
	{
		dialogue_progress += 1
		if random(1) > 0.5
		{
			dialogue_place("Crystal Assasin Concerned 0")
		}
		else
		{
			dialogue_place("Crystal Assasin Concerned 1")
		}
	}
}