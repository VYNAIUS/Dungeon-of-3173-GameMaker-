event_inherited()

dialogue_progress = 0