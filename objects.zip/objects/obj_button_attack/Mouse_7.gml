if button_pressed
{
	if obj_fight_turn_manager.enemies_needed_to_be_done < 2 or (instance_exists(obj_fight_player) and obj_fight_player.stunned > 0)
	{
		global.action_type = "fight"
		global.action_done = true
		global.is_turn = true
	}
	else if obj_fight_turn_manager.enemies_needed_to_be_done >= 2
	{
		global.fighting_choice = "hit"
	}
}

event_inherited()