if button_pressed
{
	global.is_selecting_item = true
	with obj_fight_entity
	{
		cursor_hovering_over = false
	}
	create_settings_box(683, 384, 2, 3, true)
	var starting_point = 0
	if room == rom_fight
	{
		starting_point = (global.current_ui_layer - 1) * 8
	}
	else if room == rom_map
	{
		starting_point = (global.current_ui_layer - 2) * 8
	}
	var x_level = 580
	var y_level = 75
	var counter_limit = starting_point + 7
	var is_over_flow = false
	for (var i = starting_point; i < array_length(global.player_consumable_items); i++)
	{
		var button = instance_create_depth(x_level, y_level, depth - 11, obj_button_item_fight)
		global.player_current_fight_items[i].depth = depth - 11
		button.fight_item_index = i
		with button
		{
			event_user(15)
		}
		if i % 2 != 0
		{
			x_level = 580
			y_level += 120
		}
		else
		{
			x_level = 786
		}
		if i >= counter_limit
		{
			if array_length(global.player_current_fight_items) > counter_limit + 1
			{
				is_over_flow = true
			}
			break
		}
	}
	instance_create_depth(535, 672, depth - 11, obj_item_box_fight)
	instance_create_depth(780, 672, depth - 11, obj_text_fight_item_desc)
	instance_create_depth(780, 630, depth - 11, obj_text_fight_item_name)
	var return_button = instance_create_depth(580, 550, depth - 11, obj_button_settings_quit)
	return_button.image_xscale = 0.75
	return_button.image_yscale = 0.75
	return_button.text_scale = 0.1875
	return_button.fade_away_when_enemies = true
	return_button.can_escape_key = true
	if is_over_flow
	{
		return_button = instance_create_depth(786, 550, depth - 11, obj_button_items_open)
		return_button.image_xscale = 0.75
		return_button.image_yscale = 0.75
		return_button.text_scale = 0.1875
		return_button.button_text = "Next Page"
		return_button.fade_away_when_enemies = true
	}
}

event_inherited()