event_inherited()

if array_length(global.player_consumable_items) == 0 and not (global.is_map_transitioning or global.is_dialogue or destroy_self)
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0.3
	pressable = false
}

if fade_away_when_enemies and not destroy_self
{
	var hovering_over_enemy = false
	with obj_fight_entity
	{
		if cursor_hovering_over
		{
			hovering_over_enemy = true
			break
		}
	}
	if hovering_over_enemy
	{
		target_alpha = 0.3
	}
}