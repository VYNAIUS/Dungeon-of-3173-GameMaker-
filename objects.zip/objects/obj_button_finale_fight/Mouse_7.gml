if button_pressed
{
	audio_sound_gain(global.npc_song_played, 0, 1000)
	if global.change_state != -1
	{
		dialogue_place("Cycle Final Fight: Start Regular")
	}
	else
	{
		trigger("boss_battle")
	}
}
event_inherited()