if button_pressed
{
	var possible_dialogue = []
	if global.heretic_reputation != 1
	{
		possible_dialogue = ["Herbalist Talk: Introduction", "Herbalist Talk: Shopkeeper"]
	}
	
	switch global.area_id
	{
		case 1:
			array_push(possible_dialogue, "Herbalist Talk: Deep Forest")
			break
		case 2:
			array_push(possible_dialogue, "Herbalist Talk: Cave")
			break
		case 3:
			array_push(possible_dialogue, "Herbalist Talk: Tundra")
			break
		case 4:
			array_push(possible_dialogue, "Herbalist Talk: Canyon")
			break
		case 5:
			array_push(possible_dialogue, "Herbalist Talk: Desert")
			break
		case 6:
			array_push(possible_dialogue, "Herbalist Talk: Rotten Forest")
			break
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.herbalist_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		confirmed_dialog = ["Herbalist Talk: No Dialog"]
	}
	if obj_shop_herbalist.sprite_index == spr_herbalist_4 or obj_shop_herbalist.sprite_index == spr_herbalist_5
	{
		confirmed_dialog = ["Herbalist Talk: No Dialog Sick"]
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if not(is_inside_array(confirmed_dialog[random_index], ["Herbalist Talk: No Dialog", "Herbalist Talk: No Dialog Sick"]))
	{
		array_push(global.herbalist_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()