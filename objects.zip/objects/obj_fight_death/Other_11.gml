if not(instance_exists(obj_fight_death_body))
{
	dialogue_place("Death Battle: End No Consume")
	animation_type = "none"
}
else
{
	if (obj_fight_death_body.times_splitted < 2 or global.player_consume <= 0) and original_max_hp * 0.5 >= hp
	{
		obj_fight_death_body.is_splitted = false
		if obj_fight_death_body.times_splitted == 1
		{
			dialogue_place("Death Battle: Back 0")
		}
		else if obj_fight_death_body.times_splitted == 2
		{
			dialogue_place("Death Battle: Back 1")
		}
		obj_fight_death_body.sprite_index = spr_boat_person
		global.enemy_done_count += 1
		instance_destroy()
		with obj_fight_turn_manager
		{
			event_user(0)
		}
	}
	else
	{
		if instance_exists(obj_fight_player) and not(obj_fight_player.death_played)
		{
			action_target = obj_fight_player.id
			animation_type = "soul_reap"
		}
		else
		{
			animation_type = "idle"
		}
	}
}