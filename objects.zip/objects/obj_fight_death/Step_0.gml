event_inherited()
shadow_clone_cooldown -= 1
shadow_clone_hue_shift_start += 0.001
if shadow_clone_cooldown == 0
{
	var shadow_clone = instance_create_layer(x, y, "Instances_Coins", obj_fight_vf_shadowclone_god_0)
	shadow_clone.speed = 2
	shadow_clone.direction = random(360)
	shadow_clone.follower = id
	shadow_clone.hue_shift = shadow_clone_hue_shift_start
	shadow_clone_cooldown = 5
}
if global.player_consume == 0 and hp - total_dealt_damage < max_hp * 0.1
{
	hp = round(max_hp * 0.1)
	total_dealt_damage = 0
}