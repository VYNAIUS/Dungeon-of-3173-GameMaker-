if global.change_state != -2
{
	dialogue_place("Death Battle: End Consume")
}
else
{
	dialogue_place("Death Battle: End Consume & Change")
}