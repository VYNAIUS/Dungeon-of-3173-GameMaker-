event_inherited()
shadow_clone_cooldown = 5
shadow_clone_hue_shift_start = 0