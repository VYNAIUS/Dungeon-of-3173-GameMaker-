hspeed = random_range(-0.5, 0.5)	
vspeed = random_range(-0.5, 0.5)
angle_acceleration = random_range(-0.25, 0.25)
size_change = 0
shadow_clone_cooldown = 10