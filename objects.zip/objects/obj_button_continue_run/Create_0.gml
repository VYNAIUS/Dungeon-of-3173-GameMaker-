event_inherited()
run_exists = true
if not(global.is_map_transitioning or global.is_dialogue or destroy_self) and not(file_exists("run_save")) and not(file_exists("run_save_checkpoint"))
{
	run_exists = false
}