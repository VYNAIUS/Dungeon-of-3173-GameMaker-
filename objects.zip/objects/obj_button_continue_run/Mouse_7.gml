if button_pressed
{
	if file_exists("run_save") or file_exists("run_save_checkpoint")
	{
		if global.menu_song_played != undefined
		{
			audio_sound_gain(global.menu_song_played, 0, 1000)
		}
		if file_exists("run_save")
		{
			scr_load_saved_data("run_save")
			file_delete("run_save")
		}
		else
		{
			scr_load_saved_data("run_save_checkpoint")
		}
	
		if global.run_version != global.game_version
		{
			show_message("WARNING! The game is launching a run from a different version! (current : " + global.game_version + "; the run's : " + global.run_version +")\nThere might be unintended behavior, bugs and even crashes caused by this!\nProceed with caution or start a new run.")
		}
	
		lower_ui_layer(0)
		global.is_paused = false
	
		transition_to_area_popup()
	}
	else
	{
		show_message("ERROR! The file for the run no longer exists!\nMost likely it was deleted after 'Play' button was pressed.")
		run_exists = false
	}
}
event_inherited()