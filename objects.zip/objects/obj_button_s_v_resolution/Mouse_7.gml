if button_pressed
{
	switch global.resolution_option
	{
		case 0:
			global.x_resolution = 1280
			global.y_resolution = 720
			break
		case 1:
			global.x_resolution = 1600
			global.y_resolution = 900
			break
		case 2:
			global.x_resolution = 1920
			global.y_resolution = 1080
			break
		case 3:
			global.x_resolution = 1366
			global.y_resolution = 768
			break
	}
	global.resolution_option += 1
	if global.resolution_option > 3
	{global.resolution_option -= 4}
	with (obj_camera_audio_manager)
	{
		event_user(0)
	}
}
event_inherited();