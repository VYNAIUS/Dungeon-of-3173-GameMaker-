// Inherit the parent event
event_inherited();

button_text = string(global.x_resolution) + "x" + string(global.y_resolution)
if global.is_fullscreen and not destroy_self
{
	if pressable
	{
		event_user(2)
	}
	pressable = false
	target_alpha = 0.3
}