// Inherit the parent event
event_inherited();

if global.player_money < global.shopkeeper_debt
{
	ui_layer = -1
}