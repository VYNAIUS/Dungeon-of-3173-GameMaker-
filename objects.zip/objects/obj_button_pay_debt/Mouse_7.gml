if button_pressed
{
	global.player_money -= global.shopkeeper_debt
	lower_ui_layer()
	dialogue_place("Shopkeeper Glad")
	audio_sound_gain(global.npc_song_played, 0.6, 5000)
}



event_inherited();