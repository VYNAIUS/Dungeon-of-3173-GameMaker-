// Inherit the parent event
if button_pressed
{
	save_tiles()
	scr_run_save()
	transition_to_main_menu()
}

event_inherited();