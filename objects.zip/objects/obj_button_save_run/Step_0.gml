// Inherit the parent event
event_inherited();

if not (global.is_map_transitioning or global.is_dialogue or destroy_self) and room != rom_map
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0.3
	pressable = false
}