if button_pressed
{
	var new_shopkeeper_items_array = []
	for (var i = 0; i < array_length(global.alchemist_items); i++)
	{
		var shop_item = global.alchemist_items[i]
		array_push(new_shopkeeper_items_array, shop_item.id_name)
	}
	global.alchemist_items = new_shopkeeper_items_array
	transition_to_map()
}
event_inherited()