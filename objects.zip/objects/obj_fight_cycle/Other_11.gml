if sympathy >= 1
{
	sympathy = 0
	sympathy_factor = 0
	dialogue_place("Cycle Final Fight: 3173 Trick")
	with obj_fight_3173
	{
		sympathy = 0
		sympathy_factor = 0
	}
	animation_type = "idle"
}
else
{
	if instance_exists(obj_fight_3173) and not(obj_fight_3173.death_played)
	{
		if instance_exists(obj_fight_player)
		{
			action_target = obj_fight_player.id
		}
		with obj_fight_entity
		{
			if not(is_enemy) and id_name != "player" and random(1) < 0.5
			{
				other.action_target = id
			}
		}
		if instance_exists(obj_fight_change_ally) and not(obj_fight_change_ally.death_played)
		{
			cleanse_cooldown -= 1
			if cleanse_cooldown <= 0
			{
				animation_type = "cleanse"
				cleanse_cooldown = 3
			}
			else if obj_fight_change_ally.mana_factor <= 1.5
			{
				action_target = obj_fight_change_ally.id
				animation_type = "fight_specific"
			}
			else
			{
				action_target = obj_fight_player.id
				animation_type = "fight_specific"
			}
		}
		else
		{
			animation_type = "fight_specific"
		}
		if global.heretic_reputation == 1
		{
			dialogue_cooldown -= 1
			if dialogue_cooldown <= 0
			{
				dialogue_cooldown = 8
				if dialogue_progress == 0
				{
					if instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played)
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 0")
					}
					else
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 0 No Brin")
					}
					dialogue_progress = 1
				}
				else if dialogue_progress == 1
				{
					if instance_exists(obj_fight_shopkeeper_ally) and not(obj_fight_shopkeeper_ally.death_played)
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 1")
					}
					else if instance_exists(obj_fight_heretic_ally) and not(obj_fight_heretic_ally.death_played)
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 1 No Shopkeeper")
					}
					else if instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played)
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 1 No Shopkeeper & No Jalt")
					}
					else
					{
						dialogue_place("Cycle Final Fight Heretic: Generic 1 No One")
					}
					dialogue_progress = 2
				}
			}
		}
		else if global.change_state == 2
		{
			if not(instance_exists(obj_fight_death_ally))
			{
				dialogue_cooldown -= 1
				if dialogue_cooldown <= 0
				{
					dialogue_cooldown = 6
					if dialogue_progress == 0 and not(global.is_dialogue)
					{
						dialogue_progress = 1
						if global.death_state == 2
						{
							dialogue_place("Cycle Final Fight Change & Death: Generic 0")
						}
						else
						{
							dialogue_place("Cycle Final Fight Change: Generic 0")
						}
					}
					else if dialogue_progress == 1 and not(global.is_dialogue)
					{
						dialogue_progress = 2
						if global.death_state == 2
						{
							dialogue_place("Cycle Final Fight Change & Death: Generic 1")
						}
						else
						{
							dialogue_place("Cycle Final Fight Change: Generic 1")
						}
					}
				}
			}
		}
	}
	else
	{
		if global.heretic_reputation == 1
		{
			if dialogue_progress < 20
			{
				dialogue_progress = 20
				if instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played)
				{
					dialogue_place("Cycle Final Fight Heretic: 3173 Lost")
				}
				else if instance_exists(obj_fight_shopkeeper_ally) and not(obj_fight_shopkeeper_ally.death_played)
				{
					dialogue_place("Cycle Final Fight Heretic: 3173 Lost No Brin")
				}
				else if instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played)
				{
					dialogue_place("Cycle Final Fight Heretic: 3173 Lost No Brin & No Shopkeeper")
				}
				else
				{
					dialogue_place("Cycle Final Fight Heretic: 3173 Lost No One")
				}
			}
		}
		else if global.change_state == 2
		{
			if dialogue_progress < 20
			{
				dialogue_progress = 20
				dialogue_cooldown = 3
				if global.death_state != 2
				{
					dialogue_place("Cycle Final Fight Change: 3173 Lost")
				}
				else
				{
					dialogue_place("Cycle Final Fight Change & Death: 3173 Lost")
				}
			}
		}
		animation_type = "idle"
		is_immune = false
		if global.heretic_reputation == 1
		{
			if not(global.is_dialogue) and dialogue_progress < 23
			{
				if is_inside_array(global.action_type, ["idle", "trick", "defend", "magic_defend", "impenetrability_regen"])
				{
					if instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played) and dialogue_progress < 21
					{
						dialogue_place("Cycle Final Fight Heretic: Concern")
						dialogue_progress = 21
					}
					else if not((instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played))
					or (instance_exists(obj_fight_shopkeeper_ally) and not(obj_fight_shopkeeper_ally.death_played))
					or (instance_exists(obj_fight_heretic_brin_ally) and not(obj_fight_heretic_brin_ally.death_played)))
					{
						if dialogue_progress < 22
						{
							dialogue_place("Cycle Final Fight Heretic: Concern No One")
							dialogue_progress = 22
						}
						else if dialogue_progress < 23
						{
							dialogue_place("Cycle Final Fight Heretic: Concern No One Pissed")
							dialogue_progress = 23
						}
					}
				}
			}
		}
		else if global.change_state == 2
		{
			dialogue_cooldown -= 1
			if global.death_state != 2
			{
				if dialogue_cooldown <= 0 and dialogue_progress < 21
				{
					dialogue_progress = 21
					dialogue_place("Cycle Final Fight Change: Concern")
				}
			}
		}
	}
}