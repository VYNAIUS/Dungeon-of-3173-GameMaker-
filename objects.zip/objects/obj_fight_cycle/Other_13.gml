if global.change_state == 2
{
	if global.death_state == 2
	{
		dialogue_place("Cycle Final Fight: End Helped Change Death")
	}
	else
	{
		dialogue_place("Cycle Final Fight: End Helped Change")
	}
}
else
{
	trigger("transition_balance")
}