event_inherited()
shadow_clone_cooldown -= 1
if not(global.is_map_transitioning) and shadow_clone_cooldown <= 0
{
	vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone_god_1)
	vfx.follower = id
	vfx.speed = 2
	vfx.direction = random_range(0, 360)
	shadow_clone_cooldown = 10 + dialogue_progress
}