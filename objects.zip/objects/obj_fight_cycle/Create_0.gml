event_inherited()
is_immune = true
dialogue_cooldown = 10
dialogue_progress = 0
cleanse_cooldown = 0