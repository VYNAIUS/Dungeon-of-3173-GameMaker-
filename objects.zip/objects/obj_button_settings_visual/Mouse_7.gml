if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	instance_create_depth(xcoord - 192, ycoord - 192, depth - 11, obj_button_s_v_fullscreen)
	instance_create_depth(xcoord + 192, ycoord - 192, depth - 11, obj_button_s_v_resolution)
	instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_s_v_vsync)
	instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_s_v_anti_aliasing)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	instance_create_depth(xcoord, ycoord + 352, depth - 11, obj_text_settings_tip)
}


event_inherited()