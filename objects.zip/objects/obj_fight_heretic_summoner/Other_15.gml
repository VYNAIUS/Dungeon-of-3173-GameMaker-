audio_play_sound(snd_altar_magic_protection, 0, false, 1, 0, random_range(0.97, 1.03))
instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_magic_protection)