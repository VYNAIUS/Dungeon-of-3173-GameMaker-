current_power_lvl = 0
with obj_fight_entity
{
	if is_enemy
	{
		other.current_power_lvl += power_level
	}
}
if sympathy < 1
{
	if global.player_power_level + 0.2 > current_power_lvl
	{
		animation_type = "summon"
	}
	else
	{
		animation_type = "fight"
	}
}
else
{
	animation_type = "idle"
}