if round(random(1)) == 0
{
	audio_play_sound(snd_hit_crystal_1, 0, false, 1, 0, random_range(0.95, 1.05))
}
else
{
	audio_play_sound(snd_hit_crystal_2, 0, false, 1, 0, random_range(0.95, 1.05))
}