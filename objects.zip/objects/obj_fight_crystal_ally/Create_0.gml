event_inherited()

entities_ignored = ["spirit_fear", "fear_spawn"]