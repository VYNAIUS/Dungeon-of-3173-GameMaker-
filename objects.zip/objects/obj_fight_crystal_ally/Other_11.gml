if instance_exists(obj_fight_change) and not(is_enemy)
{
	animation_type = "idle"
	is_enemy = true
	original_sprite = spr_crystal_enemy
	hidden_sprite = spr_crystal_enemy
	sprite_index = original_sprite
	with obj_fight_turn_manager
	{
		event_user(0)
	}
}
else if sympathy < 1
{
	animation_type = "fight"
}
else
{
	animation_type = "idle"
}