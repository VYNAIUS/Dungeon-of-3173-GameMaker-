if button_pressed == true
{
	if global.menu_song_played != undefined
	{
		audio_sound_gain(global.menu_song_played, 0, 1000)
	}
	if file_exists("run_save")
	{
		file_delete("run_save")
	}
	if file_exists("run_save_checkpoint")
	{
		file_delete("run_save_checkpoint")
	}
	global.run_version = global.game_version
	lower_ui_layer(0)
	main_reset()
	transition_to_area_popup()
}
event_inherited()