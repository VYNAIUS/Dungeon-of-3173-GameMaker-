if button_pressed
{
	global.player_boat_durability = 1
	global.player_boat_tutorial = true
	dialogue_place("Boat Person Accept")
}
event_inherited()