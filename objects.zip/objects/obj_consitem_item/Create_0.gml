image_alpha = 0
hover_x_position = 0
hover_y_position = 0
angle_acceleration = random_range(-0.35, 0.35)
show_self = false

angle_acc_limit = 0.35
hspeed_limit = 2
vspeed_limit = 2

self_index = 0