if global.button_description == id_name + string(self_index)
{
	if alarm[0] <= 0 and show_self == false
	{
		alarm[0] = 1
	}
}
else if global.button_description != id_name + string(self_index)
{
	if alarm[1] <= 0
	{
		alarm[1] = 10
	}
}
else
{
	show_self = false
}


if show_self and global.is_map_transitioning == false
{
	if image_alpha < 1
	{
		image_alpha += 0.07
		if image_alpha > 1
		{
			image_alpha = 1
		}
	}
	image_angle += angle_acceleration
	if image_angle < 0 and angle_acceleration < angle_acc_limit
	{
		angle_acceleration += random_range(0.01, 0.015)
	}
	else if angle_acceleration > - angle_acc_limit
	{
		angle_acceleration -= random_range(0.01, 0.015)
	}
	if hover_x_position > x and hspeed < hspeed_limit
	{
		hspeed += random_range(0.05, 0.1)
	}
	else if hspeed > - hspeed_limit
	{
		hspeed -= random_range(0.05, 0.1)
	}
	if hover_y_position > y and vspeed < vspeed_limit
	{
		vspeed += random_range(0.05, 0.1)
	}
	else
	{
		vspeed -= random_range(0.05, 0.1)
	}
}
else
{
	if image_alpha > 0
	{
		image_alpha -= 0.07
		if image_alpha < 0
		{
			image_alpha = 0
		}
	}
}