if button_pressed
{
	var xcoord = 683
	var ycoord = 384
	create_settings_box(xcoord, ycoord, 3, 2.5)
	instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_new_run)
	instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_continue_run)
	var quit_button = instance_create_depth(xcoord, ycoord + 224, depth - 11, obj_button_settings_quit)
	quit_button.can_escape_key = true
	var text = instance_create_depth(xcoord, ycoord - 192, depth - 11, obj_text)
	instance_create_depth(xcoord, ycoord + 352, depth - 11, obj_text_settings_tip)
	text.text = "Do you want to continue your run\nor start a new one?"
}
event_inherited();