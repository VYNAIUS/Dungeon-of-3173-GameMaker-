switch animation_type
{
	case "fight":
	case "fight_specific":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_strength)
		event_user(0) // HIT SOUND!
		break
	case "defend":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_protection)
		audio_play_sound(snd_defend_holy, 0, false, 1, 0, random_range(0.97, 1.03))
		break
	case "magic_fight":
	case "stun":
	case "mana_regen":
	case "crystalise":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_mana)
		event_user(2)
		break
	case "impenetrability_regen":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_protection)
		audio_play_sound(snd_defend_holy, 0, false, 1, 0, random_range(0.97, 1.03))
		break
	case "magic_defend":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_magic_protection)
		audio_play_sound(snd_altar_magic_protection, 0, false, 1, 0, random_range(0.97, 1.03))
		break
	case "cleanse":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_magic_protection)
		audio_play_sound(snd_cleanse_cycle, 0, false, 1, 0, random_range(0.97, 1.03))
		break
	case "summon":
		event_user(5)
		break
	case "item_use":
		event_user(7)
		break
	case "soul_reap":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_might)
		event_user(2)
		break
	case "split":
		instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_vitality)
		audio_play_sound(snd_vitality_mana, 0, false, 1, 0, random_range(0.97, 1.03))
		break
}