if does_exist == 0
{
	does_exist = 1
}
else if does_exist == 1
{
	does_exist = 2
	scr_use_passive(id, "fight_start", noone)
}

if is_enemy
{
	if total_dealt_damage > 0
	{
		damage_dealt = round(total_dealt_damage * 0.1)
		if damage_dealt <= 0
		{damage_dealt = 1}
		if barrier > 0
		{
			barrier -= damage_dealt
			if barrier < 0
			{
				hp += barrier
				barrier = 0
			}
		}
		else
		{
			hp -= damage_dealt
		}
		var knockback = damage_dealt * 1.5
		if max_hp >= 500 or is_hidden
		{
			knockback /= 3
		}
		y -= knockback
		x += knockback
		if not(is_hidden)
		{
			audio_play_sound(snd_hp_decrease, 0, false, 1, 0, random_range(1.95, 2))
		}
		total_dealt_damage -= damage_dealt
	}
	if total_heal_amount > 0
	{
		heal_amount = round(total_heal_amount * 0.1)
		if heal_amount <= 0
		{heal_amount = 1}
		hp += heal_amount
		if not(is_hidden)
		{
			audio_play_sound(snd_hp_decrease, 0, false, 1, 0, random_range(1, 1.05))
		}
		total_heal_amount -= heal_amount
	}
	if obj_fight_turn_manager.enemies_needed_to_be_done == 1 and global.current_ui_layer == 0
	{
		cursor_hovering_over = true
	}
}
else
{
	if total_dealt_damage > 0
	{
		damage_dealt = round(total_dealt_damage * 0.1)
		if damage_dealt <= 0
		{damage_dealt = 1}
		if barrier > 0
		{
			barrier -= damage_dealt
			if barrier < 0
			{
				hp += barrier
				barrier = 0
			}
		}
		else
		{
			hp -= damage_dealt
		}
		var knockback = damage_dealt * 1.5
		if max_hp >= 500
		{
			knockback /= 3
		}
		y -= knockback
		x -= knockback
		audio_play_sound(snd_hp_decrease, 0, false, 1, 0, random_range(1, 1.05))
		total_dealt_damage -= damage_dealt
	}
	if total_heal_amount > 0
	{
		heal_amount = round(total_heal_amount * 0.1)
		if heal_amount <= 0
		{heal_amount = 1}
		hp += heal_amount
		audio_play_sound(snd_hp_decrease, 0, false, 1, 0, random_range(1.95, 2))
		total_heal_amount -= heal_amount
	}
	if obj_fight_turn_manager.good_guys_needed_to_be_done == 1 and global.current_ui_layer == 0
	{
		cursor_hovering_over = true
	}
}

if animation_has_action
{
	if is_spawning
	{
		animation_type = "idle"
	}
	else
	{
		event_user(1)
	}
	animation_reset = false
}

if hp <= 0
{
	dealt_damage = 0
	hp = 0
	if death_played == false
	{
		audio_play_sound(snd_death_generic, 0, false, 1, 0, random_range(0.95, 1.05))
		event_user(3)
		death_played = true
		if xp + original_coins > 0 and global.player_consume > 0
		{
			global.player_max_hp += ceil(consume_hp * global.player_consume)
			global.player_dmg += ceil(consume_dmg * global.player_consume)
			global.player_crit_chance += ceil(consume_crit_chance * 100 * global.player_consume) / 100
			global.player_base_defense += ceil(consume_defense * global.player_consume)
			global.player_base_magic_defense += ceil(consume_magic_defense * global.player_consume)
		}
		with obj_fight_entity
		{
			if is_enemy != other.is_enemy
			{
				scr_use_passive(id, "opponent_death", other.id)
			}
			else
			{
				scr_use_passive(id, "ally_death", other.id)
			}
		}
	}
}
else if hp > max_hp
{
	hp = max_hp
}
else if global.is_map_transitioning
{
	image_alpha -= 0.1
}
else
{
	image_blend = merge_color(c_white, c_lime, poisoned_blend)
	if poisoned_blend > 0 and not(is_hidden)
	{
		poisoned_blend -= 0.02
		if poisoned_blend < poisoned / 20
		{
			poisoned_blend = poisoned / 20
			if poisoned_blend > 1
			{
				poisoned_blend = 1
			}
		}
	}
	else
	{
		poisoned_blend = 0
	}
}
if animation_reset
{
	if death_played
	{
		image_angle += 0.75 * global.turn_speed
		image_alpha -= 0.03 * global.turn_speed
		if image_alpha <= 0
		{
			while coins > 0
			{
				instance_create_layer(x, y, "Instances_Coins", obj_coin)
				coins -= 1
			}
			instance_destroy()
			with obj_fight_turn_manager
			{
				event_user(0)
			}
		}
	}
	else
	{
		image_angle += angle_acceleration
		if (not(is_hidden) and (hidden_sprite != sprite_index)) or (hidden_sprite == sprite_index and is_hidden) or hidden_sprite == original_sprite
		{
			if image_alpha < 1
			{
				image_alpha += 0.05
			}
		}
		else
		{
			if image_alpha > 0
			{
				image_alpha -= 0.05
			}
			if image_alpha <= 0
			{
				if is_hidden
				{
					sprite_index = hidden_sprite
				}
				else
				{
					sprite_index = original_sprite
				}
				image_alpha = 0
			}
		}
	}
	if not(death_played)
	{
		if is_enemy
		{
			x_hover_position = 440 / (obj_fight_turn_manager.enemies_needed_to_be_done + 1) * (enemy_number + 1) + 860
		}
		else
		{
			x_hover_position = 440 / (obj_fight_turn_manager.good_guys_needed_to_be_done + 1) * (enemy_number + 1) + 130
		}
	}
	if random(1) < lifesteal * 0.25 and instance_number(obj_fight_vf_lifesteal) < 300 and not(global.is_map_transitioning) and not(is_hidden)
	{
		lifesteal_particle = instance_create_layer(x + random_range(-300, 300), y + random_range(-300, 300), "Instances_Coins", obj_fight_vf_lifesteal)
		lifesteal_particle.follower = id
	}
	x += x_acceleration
	y += y_acceleration
	if stunned > 0 and not(is_hidden)
	{
		x = x_hover_position
		y = ystart
	}
	if image_xscale < target_scale
	{
		image_xscale += 0.04
		if image_xscale > target_scale
		{
			image_xscale = target_scale
		}
	}
	else if image_xscale > target_scale
	{
		image_xscale -= 0.04
		if image_xscale < target_scale
		{
			image_xscale = target_scale
		}
	}
	image_yscale = image_xscale
	if not(flying)
	{
		ystart = 700 - sprite_get_height(sprite_index) * image_yscale / 2
	}
	
	if image_angle < 0 and angle_acceleration < 0.35
	{
		angle_acceleration += random_range(0.01, 0.015)
	}
	else if angle_acceleration > -0.35
	{
		angle_acceleration -= random_range(0.01, 0.015)
	}
	if x_hover_position > x and x_acceleration < 2
	{
		x_acceleration += random_range(0.05, 0.1)
	}
	else if x_acceleration > -2
	{
		x_acceleration -= random_range(0.05, 0.1)
	}
	if ystart > y and y_acceleration < 3
	{
		y_acceleration += random_range(0.05, 0.1)
	}
	else if ystart < y and y_acceleration > -3
	{
		y_acceleration -= random_range(0.05, 0.1)
	}
	if abs(ystart - y) < 0.5
	{
		y_acceleration /= 2
		if abs(y_acceleration) < 0.05
		y_acceleration = 0
	}
}
else
{
	if animation_has_action
	{
		is_parrying = false
		scr_use_passive(id, "turn_start", noone)
		if not(is_immune) and poisoned > 0
		{
			total_dealt_damage += poisoned
			if not(is_hidden)
			{
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = poisoned
				dmg_text.text_color = #00BF00
			}
		}
		if max_hp != hp and regeneration > 0
		{
			var how_much_heal = round(max_hp * regeneration / 100)
			total_heal_amount += how_much_heal
			if not(is_hidden)
			{
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = - how_much_heal
				dmg_text.text_color = #00FF00
			}
			if how_much_heal + hp > max_hp
			{
				regeneration -= 1
				if not(is_hidden)
				{
					instance_create_layer(x, y, "Instances_UI", obj_text_regen_penalty)
				}
			}
		}
		if (stunned <= 0 and not(is_spawning)) or can_use_items
		{
			if stunned > 0 and not(has_done_action)
			{
				stunned -= 1
			}
			animation_has_action = false
			if poisoned > 0 and not(is_hidden)
			{
				poisoned_blend += poisoned / 10
				if poisoned_blend > 1
				{
					poisoned_blend = 1
				}
			}
			if sympathy >= 1
			{
				if sympathy > 1.5
				{
					sympathy = 1.5
				}
				if is_enemy
				{
					var defense_decrease = round((original_defense + 1) * (sympathy - 0.9))
					defense -= defense_decrease
					var dmg_decrease = round((dmg) * (sympathy - 1))
					dmg -= dmg_decrease
					if not(is_hidden)
					{
						var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_defincrease)
						def_text.def_amount = - defense_decrease
						var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_dmgincrease)
						dmg_text.dmg_amount = - dmg_decrease
					}
					if dmg < 0
					{
						dmg = 0
					}
				}
			}
			animation_progress = 0
			jump_increase = 5
			switch animation_type
			{
				case "fight":
				case "fight_specific":
					alarm[0] = 67 / global.turn_speed
					alarm[1] = 30 / global.turn_speed
					alarm[6] = 1
					break
				case "idle":
					alarm[0] = 1
					break
				case "defend":
				case "magic_fight":
				case "impenetrability_regen":
				case "magic_defend":
				case "mana_regen":
				case "summon":
				case "soul_reap":
					alarm[0] = 42 / global.turn_speed
					alarm[1] = 20 / global.turn_speed
					alarm[6] = 1
					image_angle = 1
					break
				case "stun":
				case "cleanse":
				case "split":
				case "crystalise":
					alarm[0] = 32 / global.turn_speed
					alarm[1] = 15 / global.turn_speed
					alarm[6] = 1
					image_angle = 1
					break
				case "parry":
				case "pickpocket":
				case "trick":
					alarm[0] = 1
					alarm[1] = 1
					alarm[6] = 1
					break
				case "none":
					alarm[0] = 1
					break
				case "item_use":
					alarm[0] = 60 / global.turn_speed
					alarm[1] = 10 / global.turn_speed
					alarm[6] = 1
					break
			}
			if is_hidden
			{
				alarm[0] = 1
				if animation_type != "none"
				{
					alarm[1] = 1
					alarm[6] = -1
				}
			}
		}
		else
		{
			animation_has_action = false
			stunned -= 1
			if stunned == 0
			{
				stunned_type = "none"
			}
			animation_type = "idle"
			alarm[0] = 1
		}
		has_done_action = true
	}
	if not(is_hidden)
	{
		switch animation_type
		{
			case "fight":
			case "fight_specific":
				if animation_progress == 0
				{
					if is_enemy == true
					{
						x -= 4 * global.turn_speed
					}
					else
					{
						x += 4 * global.turn_speed
					}
					y -= jump_increase * global.turn_speed
					jump_increase -= 0.4 * global.turn_speed
					if y > ystart + 3
					{
						y = ystart + 3
						if is_enemy == true
						{
							x += 4 * global.turn_speed
						}
						else
						{
							x -= 4 * global.turn_speed
						}
					}
				}
				else if animation_progress == 1
				{
					if is_enemy == true
					{
						x += 3.8 * global.turn_speed
					}
					else
					{
						x -= 3.8 * global.turn_speed
					}
					y += jump_increase * global.turn_speed
					jump_increase += 0.4 * global.turn_speed
					if y > ystart + 3
					{
						y = ystart + 3
						if is_enemy == true
						{
							x += 3.8 * global.turn_speed
						}
						else
						{
							x -= 3.8 * global.turn_speed
						}
					}
				}
				break
			case "defend":
			case "magic_fight":
			case "stun":
			case "impenetrability_regen":
			case "magic_defend":
			case "cleanse":
			case "mana_regen":
			case "summon":
			case "soul_reap":
			case "split":
			case "crystalise":
				if animation_progress == 0
				{
					y -= jump_increase * global.turn_speed
					jump_increase -= 0.25 * global.turn_speed
				}
				else if animation_progress == 1
				{
					y += jump_increase * global.turn_speed
					jump_increase += 0.25 * global.turn_speed
				}
				break
			case "parry":
			case "pickpocket":
			case "trick":
			case "idle":
			case "none":
				break
			case "item_use":
				animation_reset = true
		}
	}
}

if is_hidden
{
	shadow_clone_cooldown -= 1
	if shadow_clone_cooldown <= 0
	{
		vfx = instance_create_depth(x, y, depth + 1, obj_fight_vf_shadowclone)
		vfx.follower = id
		vfx.speed = 2
		vfx.direction = random_range(0, 360)
		shadow_clone_cooldown = round(1 + instance_number(obj_fight_vf_shadowclone) / 200)
	}
}