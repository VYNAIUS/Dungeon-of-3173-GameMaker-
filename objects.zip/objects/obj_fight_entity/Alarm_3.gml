if animation_type != "item_use"
{
	global.enemy_done_count += 1
}
else
{
	animation_has_action = true
}