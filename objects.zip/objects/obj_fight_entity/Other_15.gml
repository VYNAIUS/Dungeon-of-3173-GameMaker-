audio_play_sound(snd_vitality_mana, 0, false, 1, 0, random_range(0.97, 1.03))
instance_create_layer(x, y - 10, "Instances_Glyphs", obj_particle_glyph_vitality)