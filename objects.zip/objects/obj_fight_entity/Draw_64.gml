draw_set_font(Cascadia_Code_1)

draw_set_halign(fa_center)
draw_set_valign(fa_middle)

if (cursor_hovering_over) and global.is_map_transitioning == false
{
	fake_alpha += 0.1
	if fake_alpha > 1
	{
		fake_alpha = 1
	}
}
else
{
	fake_alpha -= 0.05
	if fake_alpha < 0
	{
		fake_alpha = 0
	}
}

function entity_text_formatting(text, amount_of_stats)
{
	text = text + ";"
	if amount_of_stats / 3 == floor(amount_of_stats / 3)
	{
		text = text + "\n"
	}
	else
	{
		text = text + " "
	}
	return text
}

draw_set_color(text_color)
draw_set_alpha(fake_alpha)
var stat_amount_counter = 1
var text = ""
if not(is_hidden)
{
	text = text + string(entity_name)
}
else
{
	text = text + "???"
}
text = text + "\n" 
if not(is_hidden)
{
	if not(is_immune)
	{
		text = text + string(hp) + "/" + string(max_hp) + " HP; "
	}
	else
	{
		text = text + "IMMUNE; "
	}
	text = text + string(dmg) + " DMG; " + string(original_defense)
	+ "+" + string(defense) + " DEF\n" + string(round(crit_chance * 100)) + "% CRT"

	if original_magic_defense + magic_defense > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(original_magic_defense) + "+" + string(magic_defense) + " MGCDEF"
		stat_amount_counter += 1
	}
	if barrier > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(barrier) + " BAR"
		stat_amount_counter += 1
	}
	if spikes > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(spikes) + " SPK"
		stat_amount_counter += 1
	}
	if poison > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(poison) + " PSN"
		stat_amount_counter += 1
	}
	if regeneration > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(regeneration) + "% REG"
		stat_amount_counter += 1
	}
	if lifesteal > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(round(lifesteal * 100)) + "% LFST"
		stat_amount_counter += 1
	}
	if impenetrability > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(impenetrability) + "(" + string(round(impenetrability / max_impenetrability * 100)) + "%)IMP"
		stat_amount_counter += 1
	}
	if poisoned > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(poisoned) + " PSN'D"
		stat_amount_counter += 1
	}
	if stunned > 0
	{
		text = entity_text_formatting(text, stat_amount_counter) + string(stunned) + " STN'D"
		stat_amount_counter += 1
	}
}
else
{
	text = text + "? HP; ? DMG; ?+? DEF\n?% CRT"
}

text_scale = 0.25 - max(ceil((stat_amount_counter / 3) - 1), 0) * 0.0625
if text_scale < 0.125
{
	text_scale = 0.125
}

if global.is_paused == false
{
	draw_text_transformed(x, y - y_difference, text, text_scale, text_scale, 0)
}

draw_set_halign(fa_left)
draw_set_valign(fa_top)
draw_set_alpha(1)

draw_set_color(#FFFFFF)