consume_hp = max_hp
consume_dmg = dmg
consume_defense = original_defense
consume_magic_defense = original_magic_defense
consume_crit_chance = crit_chance
if global.fight_type == "elite"
{
	xp = floor(xp / 2.75)
	coins = floor(coins / 2.75)
}

items = []
entities_ignored = []

max_hp = round(max_hp * scr_health_multi(id_name))
dmg = round(dmg * scr_damage_multi(id_name))
original_defense = round((original_defense + scr_defense_addition(id_name)) * scr_defense_multi(id_name))
if id_name != "player"
{
	original_magic_defense = round(original_magic_defense * global.enemy_stat_multiplier)
}
crit_chance = round(crit_chance * scr_crt_multi(id_name) * 100) / 100
barrier = round(barrier * scr_health_multi(id_name))
poison = round(poison * scr_psn_multi(id_name))
spikes = round(spikes * scr_spk_multi(id_name))
regeneration = round(regeneration * scr_reg_multi(id_name))
lifesteal = round(lifesteal * scr_lfst_multi(id_name) * 100) / 100
max_impenetrability = round(max_impenetrability * scr_imp_multi(id_name))
	

target_scale = 1
original_sprite = sprite_index
hidden_sprite = spr_glyph_innocence
shadow_clone_cooldown = 1

is_spawning = false

can_be_inspected = true

has_done_action = false
enemy_number = 0
x_hover_position = xstart
does_exist = false

animation_progress = 0
animation_type = "idle"
animation_reset = true

jump_increase = 5
x_acceleration = random_range(-1, 1)
y_acceleration = 0
angle_acceleration = 0.25

y_difference = y_difference + random_range(0, 50)
fake_alpha = 0
text_scale = 0.25
if not(flying)
{
	ystart = 700 - sprite_get_height(sprite_index) / 2
}
else
{
	ystart = 384
}
y = ystart
image_alpha = 0
cursor_hovering_over = false
defense = 0
magic_defense = 0
poisoned = 0
poisoned_blend = 0
stunned = 0
stunned_type = "none"
is_hidden = false
if is_enemy
{
	if is_inside_array(4, global.current_weathers)
	{
		is_hidden = true
		var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
		funny_text.text = "Hidden"
		funny_text.text_color = #7F007F
	}
}
cleansed = false
sympathy = 0

original_max_hp = max_hp
original_mana_factor = mana_factor
original_dmg = dmg
original_crit_chance = crit_chance
original_regeneration = regeneration

is_immune = false
hp = max_hp
impenetrability = max_impenetrability
is_parrying = false
coins = ceil(coins * (1 + (global.player_money_boost / 100)))
original_coins = coins

imper_thing = undefined
if impenetrability > 0
{
	imper_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_impenetrability)
	imper_thing.follower = id
}
item_thing = undefined

damage_dealt = 0
animation_has_action = false
dealt_damage = 0
total_dealt_damage = 0
heal_amount = 0
total_heal_amount = 0
death_played = false
explosion_played = false
is_critical_strike = 0
action_target = 0