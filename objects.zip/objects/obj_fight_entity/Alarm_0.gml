animation_reset = true
if is_enemy == false
{
	switch animation_type
	{
		case "fight":
		case "fight_specific":
		case "cleanse":
		case "stun":
		case "magic_fight":
		case "mana_regen":
		case "summon":
		case "soul_reap":
		case "split":
		case "crystalise":
			alarm[2] = 30 / global.turn_speed
			break
		case "defend":
		case "magic_defend":
		case "impenetrability_regen":
		case "item_use":
			alarm[2] = 60 / global.turn_speed
			break
		case "idle":
		case "parry":
		case "pickpocket":
		case "trick":
			alarm[2] = 1
			break
		case "none":
			break
	}
}
else
{
	switch animation_type
	{
		case "fight":
		case "fight_specific":
		case "cleanse":
		case "stun":
		case "mana_regen":
		case "summon":
		case "magic_fight":
		case "soul_reap":
		case "split":
		case "crystalise":
			alarm[3] = 30 / global.turn_speed
			break
		case "defend":
		case "magic_defend":
		case "impenetrability_regen":
		case "item_use":
			alarm[3] = 60 / global.turn_speed
			break
		case "idle":
		case "parry":
		case "pickpocket":
		case "trick":
			alarm[3] = 1
			break
		case "none":
			break
	}
}
with obj_fight_entity
{
	if is_inside_array(other.animation_type, ["fight", "fight_specific", "magic_fight"])
	{
		if id == other.id
		{
			scr_use_passive(id, "follower_attack", id)
		}
		else if is_enemy != other.is_enemy
		{
			scr_use_passive(id, "opponent_attack", other.id)
		}
	}
	if is_inside_array(other.animation_type, ["fight", "fight_specific", "magic_fight",
	"stun", "parry", "cleanse", "summon", "soul_reap", "crystalise"])
	{
		if id == other.id
		{
			scr_use_passive(id, "follower_offense", id)
		}
		else if is_enemy != other.is_enemy
		{
			scr_use_passive(id, "opponent_offense", other.id)
		}
	}
	if is_inside_array(other.animation_type, ["defend", "magic_defend", "parry",
	"impenetrability_regen", "mana_regen"])
	{
		if id == other.id
		{
			scr_use_passive(id, "follower_defense", id)
		}
		else if is_enemy != other.is_enemy
		{
			scr_use_passive(id, "opponent_defense", other.id)
		}
	}
	if is_inside_array(other.animation_type, ["parry", "impenetrability_regen", "mana_regen",
	"stun", "cleanse", "summon", "soul_reap", "crystalise", "split", "pickpocket", "trick"])
	{
		if id == other.id
		{
			scr_use_passive(id, "follower_skill", id)
		}
		else if is_enemy != other.is_enemy
		{
			scr_use_passive(id, "opponent_skill", other.id)
		}
	}
}