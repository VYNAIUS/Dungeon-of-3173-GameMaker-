animation_progress = 1
if animation_type == "defend"
{
	var def_increase = round(original_defense * 0.1) + 1
	defense += def_increase
	if not(is_hidden)
	{
		var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_defincrease)
		def_text.def_amount = def_increase
	}
}
else if (animation_type == "fight" or animation_type == "fight_specific") and obj_fight_turn_manager.good_guys_needed_to_be_done > 0
{
	is_critical_strike = 0
	var damage_deal = dmg
	var current_crit_chance = crit_chance
	while current_crit_chance > 0
	{
		if random(1) < current_crit_chance
		{
			damage_deal *= 2
			is_critical_strike += 1
		}
		current_crit_chance -= 1
	}
	if is_critical_strike > 0 and not(is_hidden)
	{
		audio_play_sound(snd_crit_chance, 0, false, 1, 0, random_range(is_critical_strike * 0.25 + 0.7, is_critical_strike * 0.25 + 0.8))
		instance_create_layer(x, y, "Instances_Glyphs", obj_particle_glyph_might)
		var crit_text = instance_create_layer(x, y, "Instances_UI", obj_text_crit)
		crit_text.crit_amount = is_critical_strike
	}
	
	var player_damage_dealt = damage_deal
	var players_hit_parried = false
	if not(is_enemy)
	{
		with obj_fight_entity
		{
			if sympathy > 0
			{
				sympathy_factor = 0
			}
			sympathy = 0
		}
	}
	if animation_type == "fight"
	{
		var spread_amount = 0
		with obj_fight_entity
		{
			if is_enemy != other.is_enemy and not(death_played) and not(is_inside_array(id_name, other.entities_ignored))
			{
				spread_amount += 1
			}
		}
		var should_parry = false
		with obj_fight_entity
		{
			if is_parrying and is_enemy != other.is_enemy and not(is_inside_array(id_name, other.entities_ignored))
			{
				spread_amount = 0
				players_hit_parried = true
			}
		}
		if spread_amount == 0
		{
			spread_amount = 1
		}
		if not(should_parry)
		{
			player_damage_dealt /= spread_amount
		}
	}
	else
	{
		if action_target.is_parrying
		{
			players_hit_parried = true
		}
	}
	player_damage_dealt = ceil(player_damage_dealt)
		
	var enemy_index = 0
		
	while (enemy_index < instance_number(obj_fight_entity))
	{
		var target = instance_find(obj_fight_entity, enemy_index)
		if (target.is_enemy != is_enemy) and (animation_type == "fight" or (animation_type == "fight_specific" and target == action_target)) and not(target.death_played) and not(is_inside_array(target.id_name, entities_ignored))
		{
			if not(players_hit_parried)
			{
				damage = player_damage_dealt - target.defense - target.original_defense
				if damage <= 1
				{
					damage = 1
				}
				if target.impenetrability > 0
				{
					target.imper_thing.total_dealt_damage += round(damage * (target.impenetrability / target.max_impenetrability))
					damage = round(damage * (1 - target.impenetrability / target.max_impenetrability))
				}
				if not(animation_type == "fight" and ((not(is_enemy) and obj_fight_turn_manager.enemies_needed_to_be_done > 1) or (is_enemy and obj_fight_turn_manager.good_guys_needed_to_be_done > 1)))
				{
					if poison > 0
					{
						if target.impenetrability > 0
						{
							var poison_amount = round(poison * (1 - target.impenetrability / target.max_impenetrability))
							target.poisoned += poison_amount
							if not(target.is_hidden) and not(is_hidden)
							{
								var dmg_text = instance_create_layer(target.x + random_range(-10, 10), target.y + random_range(-10, 10), "Instances_UI", obj_text_psnincrease)
								dmg_text.psn_amount = poison_amount
							}
						}
						else
						{
							target.poisoned += poison
							if not(target.is_hidden) and not(is_hidden)
							{
								var dmg_text = instance_create_layer(target.x + random_range(-10, 10), target.y + random_range(-10, 10), "Instances_UI", obj_text_psnincrease)
								dmg_text.psn_amount = poison
							}
						}
					}
				}
				if target.is_immune
				{
					damage = 0
				}
			    target.total_dealt_damage += damage
				if not(target.is_hidden) and not(is_hidden)
				{
					var dmg_text = instance_create_layer(target.x + random_range(-10, 10), target.y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
					dmg_text.dmg_amount = damage
					dmg_text.text_color = #FF0000
				}
				if target.spikes > 0
				{
					var spike_dmg = target.spikes
					if impenetrability > 0
					{
						imper_thing.total_dealt_damage += round(target.spikes * (impenetrability / max_impenetrability))
						spike_dmg = round(target.spikes * (1 - impenetrability / max_impenetrability))
					}
					total_dealt_damage += spike_dmg
					if not(target.is_hidden) and not(is_hidden)
					{
						var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
						dmg_text.dmg_amount = spike_dmg
						dmg_text.text_color = #7F7F3F
					}
				}
				if hp < max_hp and lifesteal > 0
				{
					var epic_heal_amount = round(damage * lifesteal)
					total_heal_amount += epic_heal_amount
					if not(target.is_hidden) and not(is_hidden)
					{
						var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
						dmg_text.dmg_amount = - epic_heal_amount
						dmg_text.text_color = #FF0032
					}
				}
			}
			else if target.is_parrying
			{
				damage = player_damage_dealt - defense - original_defense
				if poison + target.poison > 0
					{
					if impenetrability > 0
					{
						var poison_amount = round((target.poison + poison) * (1 - impenetrability / max_impenetrability))
						poisoned += poison_amount
						if not(target.is_hidden) and not(is_hidden)
						{
							var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_psnincrease)
							dmg_text.psn_amount = poison_amount
						}
					}
					else
					{
						poisoned += target.poison + poison
						if not(target.is_hidden) and not(is_hidden)
						{
							var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_psnincrease)
							dmg_text.psn_amount = poison + target.poison
						}
					}
				}
				if damage <= 1
				{
					damage = 1
				}
				if impenetrability > 0
				{
					imper_thing.total_dealt_damage += round(damage * (impenetrability / max_impenetrability))
					damage = round(damage * (1 - impenetrability / max_impenetrability))
				}
				animation_reset = true
				alarm[0] = 1
				total_dealt_damage += damage
				if not(target.is_hidden) and not(is_hidden)
				{
					var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
					dmg_text.dmg_amount = damage
					dmg_text.text_color = #FF0000
				}
				audio_play_sound(snd_hit_sword, 0, false, 1, 0, random_range(1.95, 2.05))
			}
		}
		enemy_index += 1
	}
}
else if animation_type == "magic_fight" and obj_fight_turn_manager.good_guys_needed_to_be_done > 0
{
	is_critical_strike = 0
	var damage_deal = dmg
	var current_crit_chance = crit_chance
	while current_crit_chance > 0
	{
		if random(1) < current_crit_chance
		{
			damage_deal *= 2
			is_critical_strike += 1
		}
		current_crit_chance -= 1
	}
	if is_critical_strike > 0 and not(is_hidden)
	{
		audio_play_sound(snd_crit_chance, 0, false, 1, 0, random_range(is_critical_strike * 0.25 + 0.7, is_critical_strike * 0.25 + 0.8))
		instance_create_layer(x, y, "Instances_Glyphs", obj_particle_glyph_might)
		var crit_text = instance_create_layer(x, y, "Instances_UI", obj_text_crit)
		crit_text.crit_amount = is_critical_strike
	}
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy and not(is_inside_array(id_name, other.entities_ignored))
		{
			var magic_deal_damage = damage_deal
			magic_deal_damage -= magic_defense + original_magic_defense
			if magic_deal_damage <= 1
			{
				magic_deal_damage = 1
			}
			if impenetrability > 0
			{
				imper_thing.total_dealt_damage += round(magic_deal_damage * (impenetrability / max_impenetrability))
				magic_deal_damage = round(magic_deal_damage * (1 - impenetrability / max_impenetrability))
			}
			if is_immune
			{
				magic_deal_damage = 0
			}
			total_dealt_damage += magic_deal_damage
			if not(other.is_hidden) and not(is_hidden)
			{
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = magic_deal_damage
				dmg_text.text_color = #FFFF00
			}
		}
	}
}
else if animation_type == "stun" and obj_fight_turn_manager.good_guys_needed_to_be_done > 0
{
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy and not(is_inside_array(id_name, other.entities_ignored))
		{
			if impenetrability > 0
			{
				imper_thing.total_dealt_damage += round(stunned * 50 * (impenetrability / max_impenetrability))
				stunned += round(other.stun_amount * (1 - impenetrability / max_impenetrability))
			}
			else
			{
				stunned += other.stun_amount
			}
		}
	}
}
else if animation_type == "impenetrability_regen"
{
	if max_impenetrability < 2
	{
		max_impenetrability = 2
	}
	if is_enemy
	{
		impenetrability = max_impenetrability + 1
	}
	else
	{
		impenetrability = max_impenetrability
	}
	if imper_thing == undefined or not(instance_exists(imper_thing)) and not(is_hidden)
	{
		imper_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_impenetrability)
		imper_thing.follower = id
	}
	var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
	funny_text.text = "Impenetrable"
	funny_text.text_color = #00FFFF
}
else if animation_type == "magic_defend"
{
	var def_increase = round(original_magic_defense * 0.15) + 1
	magic_defense += def_increase
	if not(is_hidden)
	{
		var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_mgcdefincrease)
		def_text.mgcdef_amount = def_increase
	}
}
else if animation_type == "parry"
{
	is_parrying = true
	if not(is_hidden)
	{
		var parry_thing = instance_create_layer(x, y, "Instances_VFX", obj_fight_vf_parry)
		parry_thing.follower = id
		var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
		funny_text.text = "Parrying"
		funny_text.text_color = #FF0000
	}
}
else if animation_type == "cleanse"
{
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy
		{
			var def_increase = ceil((original_defense + 1) * mana_factor * 0.3)
			defense -= def_increase
			if not(is_hidden)
			{
				var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_defincrease)
				def_text.def_amount = - def_increase
			}
			def_increase = round((dmg + 1) * mana_factor * 0.25)
			dmg -= def_increase
			if not(is_hidden)
			{
				var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_dmgincrease)
				def_text.dmg_amount = - def_increase
			}
			def_increase = round(abs(original_magic_defense * 0.25) * mana_factor + 1)
			magic_defense += def_increase
			if not(is_hidden)
			{
				var def_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_mgcdefincrease)
				def_text.mgcdef_amount = def_increase
			}
			mana_factor /= 1.5
			cleansed = true
			if not(is_hidden)
			{
				var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				funny_text.text = "Cleansed"
				funny_text.text_color = #00FFFF
			}
		}
	}
}
else if animation_type == "pickpocket"
{
	if not(is_enemy)
	{
		if obj_fight_turn_manager.enemies_needed_to_be_done == 1
		{
			with obj_fight_entity
			{
				if is_enemy
				{
					other.action_target = id
				}
			}
		}
		
		with obj_fight_entity
		{
			if id == other.action_target
			{
				var amount_to_spawn = ceil(original_coins * 0.15)
				if coins < amount_to_spawn
				{
					amount_to_spawn = coins
				}
				if amount_to_spawn > 0
				{
					if not(is_hidden)
					{
						var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
						funny_text.text = "Pickpocketted"
						funny_text.text_color = #FF007F
					}
				}
				else
				{
					if not(is_hidden)
					{
						var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
						funny_text.text = "Broke"
						funny_text.text_color = #FF007F
					}
				}
				coins -= amount_to_spawn
				amount_to_spawn *= 2
				while amount_to_spawn > 0
				{
					instance_create_layer(x, y, "Instances_Coins", obj_coin)
					amount_to_spawn -= 1
				}
			}
		}
	}
}
else if animation_type == "mana_regen"
{
	if mana_factor < original_mana_factor
	{
		mana_factor *= 1.5
	}
	if hp < max_hp
	{
		total_heal_amount += round(max_hp * 0.1 * mana_factor)
	}
	if defense < 0
	{
		defense += ceil((original_defense + 1) * mana_factor * 0.2)
	}
	if dmg < original_dmg
	{
		dmg += round((original_dmg) * mana_factor * 0.25)
		if dmg > original_dmg
		{
			dmg = original_dmg
		}
	}
	magic_defense -= round(abs(original_magic_defense * 0.25) * mana_factor + 1)
	if original_mana_factor * 0.75 <= mana_factor
	{
		cleansed = false
	}
	var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
	funny_text.text = "Mana Regeneration"
	funny_text.text_color = #FFFF00
}
else if animation_type == "summon"
{
	event_user(4)
}
else if animation_type == "item_use"
{
	event_user(6)
}
else if animation_type == "soul_reap" and obj_fight_turn_manager.good_guys_needed_to_be_done > 0
{
	if id_name == "player" and obj_fight_turn_manager.enemies_needed_to_be_done == 1
	{
		with obj_fight_entity
		{
			if is_enemy
			{
				other.action_target = id
			}
		}
	}
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy and id == other.action_target
		{
			var reap_damage = ceil(max_hp * other.crit_chance)
			if is_immune or is_inside_array(id_name, ["change", "cycle", "death"])
			{
				reap_damage = 0
				if id_name == "change"
				{
					dialogue_place("Change Battling: Reap")
				}
				else if id_name == "cycle"
				{
					if global.change_state == 2
					{
						dialogue_place("Cycle Final Fight Change: Reap Cycle")
					}
					else
					{
						dialogue_place("Cycle Final Fight Heretic: Reap Cycle")
					}
				}
			}
			if id_name == "3173"
			{
				reap_damage = ceil(reap_damage / 4)
			}
			total_dealt_damage += reap_damage
			if not(is_hidden)
			{
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = reap_damage
				dmg_text.text_color = #FF8000
				var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				funny_text.text = "Reaped"
				funny_text.text_color = #FF8000
			}
			if other.hp < other.max_hp and other.lifesteal > 0
			{
				var epic_heal_amount = round(reap_damage * other.lifesteal)
				other.total_heal_amount += epic_heal_amount
				if not(is_hidden)
				{
					var dmg_text = instance_create_layer(other.x + random_range(-10, 10), other.y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
					dmg_text.dmg_amount = - epic_heal_amount
					dmg_text.text_color = #FF0032
				}
			}
		}
	}
}
else if animation_type == "split"
{
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy and not(is_spawning) and not(is_inside_array(id_name, other.entities_ignored))
		{
			if not(is_inside_array(id_name, ["death_body", "death", "soul_catcher", "necromancer", "change",
			"change_ally", "cycle", "death_body_ally", "death_ally"])) and not(id_name == "3173" and is_splitted)
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				max_hp = round(max_hp / 2)
				hp = round(hp / 2)
				dmg = round(dmg / 2)
				defense = round(defense / 2)
				original_defense = round(original_defense / 2)
				crit_chance = round(crit_chance / 2 * 100) / 100
				magic_defense = round(magic_defense / 2)
				original_magic_defense = round(original_magic_defense / 2)
				poison = round(poison / 2)
				spikes = round(spikes / 2)
				regeneration = round(regeneration / 2)
				lifesteal = round(lifesteal / 2 * 100) / 100
				max_impenetrability = round(max_impenetrability / 2)
				impenetrability = round(impenetrability / 2)
				stun_amount = round(stun_amount / 2)
				mana_factor = mana_factor / 2
				original_mana_factor = round(original_mana_factor / 2)
				power_level = round(power_level / 2)
				stunned = round(stunned / 2)
				poisoned = round(poisoned / 2)
				y_difference = y_difference * 0.75
				target_scale = target_scale * 0.75
				has_done_action = false
				new_enemy = scr_battle_spawn(object_index)
				new_enemy.max_hp = max_hp
				new_enemy.hp = hp
				new_enemy.dmg = dmg
				new_enemy.original_dmg = original_dmg
				new_enemy.defense = defense
				new_enemy.original_defense = original_defense
				new_enemy.crit_chance = crit_chance
				new_enemy.original_crit_chance = original_crit_chance
				new_enemy.magic_defense = magic_defense
				new_enemy.original_magic_defense = original_magic_defense
				new_enemy.poison = poison
				new_enemy.spikes = spikes
				new_enemy.regeneration = regeneration
				new_enemy.lifesteal = lifesteal
				new_enemy.max_impenetrability = max_impenetrability
				new_enemy.impenetrability = impenetrability
				new_enemy.stun_amount = stun_amount
				new_enemy.mana_factor = mana_factor
				new_enemy.original_mana_factor = original_mana_factor
				new_enemy.power_level = power_level
				new_enemy.stunned = stunned
				new_enemy.poisoned = poisoned
				new_enemy.y_difference = y_difference
				new_enemy.target_scale = target_scale
				new_enemy.is_hidden = is_hidden
				new_enemy.has_done_action = false
				if id_name == "alchemist"
				{
					new_enemy.stun_potions = 0
				}
				if id_name == "3173"
				{
					new_enemy.special_attack_done = special_attack_done
				}
			}
			else if id_name == "soul_catcher"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				soul = scr_battle_spawn(obj_fight_soul)
				soul.sympathy = sympathy
				if sympathy_factor == 0
				{
					soul.sympathy_factor = 0
				}
				summon_progress += 1
			}
			else if id_name == "necromancer"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				self_summon -= 1
				if self_summon < 0
				{
					self_summon = 0
				}
			}
			else if id_name == "death_body" or id_name == "death_body_ally"
			{
				if not(is_splitted)
				{
					if not(is_hidden)
					{
						var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
						funny_text.text = "Splitted"
						funny_text.text_color = #00FF00
					}
					if id_name == "death_body"
					{
						scr_battle_spawn(obj_fight_death)
						if times_splitted == 0
						{
							dialogue_place("Death Battle: Split 0")
						}
						else if times_splitted == 1
						{
							dialogue_place("Death Battle: Split 1")
						}
					}
					else
					{
						scr_battle_spawn(obj_fight_death_ally)
						if not(global.is_dialogue)
						{
							dialogue_place("Cycle Final Fight Change & Death: Split Death")
						}
					}
					sprite_index = spr_boat_person_dead
					max_hp = round(max_hp * 0.75)
					lifesteal = 0
					is_splitted = true
					if id_name == "death_body"
					{
						if global.player_current_skill_0 == "split"
						{
							obj_button_skill_0.cooldown -= 5
						}
						if global.player_current_skill_1 == "split"
						{
							obj_button_skill_1.cooldown -= 5
						}
					}
					times_splitted += 1
				}
			}
			else if id_name == "death" or id_name == "death_ally"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				var funny_damage = round(hp * 0.25)
				hp -= funny_damage
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = funny_damage
				dmg_text.text_color = #00FF00
				if id_name == "death"
				{
					if global.player_current_skill_0 == "split"
					{
						obj_button_skill_0.cooldown -= 5
					}
					if global.player_current_skill_1 == "split"
					{
						obj_button_skill_1.cooldown -= 5
					}
				}
				else
				{
					
				}
			}
			else if id_name == "3173"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				var funny_damage = round(hp * 0.125)
				hp -= funny_damage
				var dmg_text = instance_create_layer(x + random_range(-10, 10), y + random_range(-10, 10), "Instances_UI", obj_text_hploss)
				dmg_text.dmg_amount = funny_damage
				dmg_text.text_color = #00FF00
			}
			else if id_name == "change"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				if not(global.is_dialogue)
				{
					dialogue_place("Change Battling: Split")
				}
			}
			else if id_name == "change_ally"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				if not(global.is_dialogue)
				{
					dialogue_place("Cycle Final Fight Change: Split Change")
				}
			}
			else if id_name == "cycle"
			{
				if not(is_hidden)
				{
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Splitted"
					funny_text.text_color = #00FF00
				}
				if not(instance_exists(obj_fight_death_body_ally) or instance_exists(obj_fight_death_ally)) and instance_exists(obj_fight_change_ally)
				{
					dialogue_place("Cycle Final Fight Change: Split Cycle")
				}
				else if global.heretic_reputation == 1
				{
					dialogue_place("Cycle Final Fight Heretic: Split Cycle")
				}
			}
		}
	}
}
else if animation_type == "trick"
{
	var sympathy_added = 0
	total_dealt_damage += 1
	var dmg_text = instance_create_layer(x, y, "Instances_UI", obj_text_hploss)
	dmg_text.dmg_amount = 1
	dmg_text.text_color = #7F007F
	if not(is_enemy)
	{
		with obj_fight_entity
		{
			sympathy += sympathy_factor
			if is_enemy
			{
				sympathy_added += sympathy_factor
			}
			if sympathy_factor > 0
			{
				var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				funny_text.text = "Sympathising"
				funny_text.text_color = #7F007F
			}
		}
	}
	if sympathy_added <= 0 and global.fear_trick_refusal <= 0
	{
		dialogue_place("Fear Talk: No Trick")
		global.fear_trick_refusal = 7
	}
}
else if animation_type == "crystalise"
{
	if id_name == "player" and obj_fight_turn_manager.enemies_needed_to_be_done == 1
	{
		with obj_fight_entity
		{
			if is_enemy
			{
				other.action_target = id
			}
		}
	}
	with obj_fight_entity
	{
		if is_enemy != other.is_enemy and other.action_target == id
		{
			if id_name == "change" or id_name == "change_ally"
			{
				total_heal_amount += 15
				if not(global.is_dialogue)
				{
					dialogue_place("Change Battling: Crystalise")
				}
			}
			else if power_level < 1 and id_name != "crystal_enemy"
			{
				hp = 0
				scr_battle_spawn(obj_fight_crystal_enemy)
			}
			else
			{
				stunned += 3
				if not(is_hidden) and not(other.is_hidden)
				{
					var stun_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_stun_crystalise)
					stun_thing.follower = id
				}
			}
			if not(is_hidden) and not(other.is_hidden)
			{
				var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
				funny_text.text = "Crystallised"
				funny_text.text_color = #FFFF00
			}
		}
	}
}