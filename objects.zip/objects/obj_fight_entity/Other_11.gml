if sympathy < 1
{
	animation_type = "fight"
}
else
{
	animation_type = "idle"
}