y -= 5
if is_enemy and is_inside_array(global.entity_choose_type, ["fight_specific", "pickpocket", "crystalise", "soul_reap"])
{
	global.specific_target = id
	if global.entity_choose_type == "fight_specific"
	{
		global.action_type = "fight_specific"
	}
	else if global.entity_choose_type == "pickpocket"
	{
		global.action_type = "pickpocket"
	}
	else if global.entity_choose_type == "crystalise"
	{
		global.action_type = "crystalise"
	}
	else if global.entity_choose_type == "soul_reap"
	{
		global.action_type = "soul_reap"
	}
	global.entity_choose_type = "none"
	global.action_done = true
}

if global.entity_choose_type == "poison_flask"
{
	if is_enemy
	{
		global.entity_choose_type = "none"
		with obj_fight_entity
		{
			if is_enemy
			{
				poisoned += 10
				if not(is_hidden)
				{
					var dmg_text = instance_create_layer(x, y, "Instances_UI", obj_text_psnincrease)
					dmg_text.psn_amount = 10
				}
			}
		}
	}
	else if id_name == "player"
	{
		global.entity_choose_type = "none"
		global.player_poison += 1
		poison += 1
	}
}

if global.entity_choose_type == "inspect" and can_be_inspected
{
	if id_name != "player"
	{
		global.button_description = "enemy_inspect"
		with obj_text_tip
		{
			if global.player_fear > 0.5
			{
				text = "I don't know! Stop asking me, please! I just need some time to calm down"
			}
			else if not(other.is_hidden)
			{
				text = other.entity_description
			}
			else
			{
				text = "Cannot figure out who that is"
			}
		}
	}
	else
	{
		global.button_description = "self_inspect"
	}
	global.entity_choose_type = "none"
}