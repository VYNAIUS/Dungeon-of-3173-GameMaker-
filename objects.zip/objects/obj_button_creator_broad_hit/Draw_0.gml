if instance_exists(obj_button_broad_hit) == false and global.is_turn == false and global.fighting_choice != "none" and obj_fight_turn_manager.enemies_needed_to_be_done > 1
{
	instance_create_layer(x, y, "Instances_UI", obj_button_broad_hit)
}