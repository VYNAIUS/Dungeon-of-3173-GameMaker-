if button_pressed
{
	global.entity_choose_type = "inspect"
	global.action_done = false
}

event_inherited()