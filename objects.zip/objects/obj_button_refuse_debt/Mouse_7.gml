if button_pressed
{
	lower_ui_layer()
	if global.player_money < global.shopkeeper_debt
	{
		dialogue_place("Shopkeeper Begin Fight Poor")
	}
	else
	{
		dialogue_place("Shopkeeper Begin Fight Greed")
	}
}



event_inherited();