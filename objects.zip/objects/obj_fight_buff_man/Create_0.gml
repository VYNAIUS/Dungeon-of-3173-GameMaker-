event_inherited()

voice_pitch = random_range(0.95, 1.05)
dialogue_progress = 0