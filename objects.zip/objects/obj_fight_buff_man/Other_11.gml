if sympathy >= 1
{
	animation_type = "idle"
	if dialogue_progress == 0 and not global.is_dialogue
	{
		if random(1) >= 0.5
		{
			dialogue_place("Bandit Concerned 0")
		}
		else
		{
			dialogue_place("Bandit Concerned 1")
		}
		dialogue_progress += 1
	}
}
else
{
	animation_type = "fight"
}