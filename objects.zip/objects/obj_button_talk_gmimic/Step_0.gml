// Inherit the parent event
event_inherited();

if global.gmimic_encounters == 0
{
	if pressable
	{
		event_user(2)
	}
	target_alpha = 0
	pressable = false
}