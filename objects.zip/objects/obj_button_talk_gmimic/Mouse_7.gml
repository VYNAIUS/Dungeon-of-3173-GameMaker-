if button_pressed
{
	if not(global.gmimic_item_shown)
	{
		var possible_dialogue = ["Golden Mimic Talk: Shopkeeper", "Golden Mimic Talk: Midas"]
		
		for (var i = 0; i < array_length(global.saved_tiles); i++)
		{
			var epic_tile = global.saved_tiles[i]
			if epic_tile[4] == "mimic_golden"
			{
				if epic_tile[2] <= global.current_water_level
				{
					array_push(possible_dialogue, "Golden Mimic Talk: Too Much Water")
				}
				break
			}
		}
		
		if global.area_id == 1
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Cave Heading")
		}
		else if global.area_id == 3
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Tundra")
		}
		else if global.area_id == 4
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Canyon")
		}
		else if global.area_id == 5
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Desert")
		}
		if global.heretic_reputation == 1
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Heretic")
		}
		if is_inside_array("Golden Mimic Talk: Midas", global.gmimic_told_dialog) and (global.player_current_skill_0 == "pickpocket" or global.player_current_skill_1 == "pickpocket")
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Pickpocket")
		}
		
		if global.game_mode == "infinite"
		{
			array_push(possible_dialogue, "Golden Mimic Talk: Infinite Mode")
		}
	
		var confirmed_dialog = []
		for (var i = 0; i < array_length(possible_dialogue); i++)
		{
			var place_it = true
			var dialogue_line = possible_dialogue[i]
			if is_inside_array(dialogue_line, global.gmimic_told_dialog)
			{
				place_it = false
			}
			if place_it
			{
				array_push(confirmed_dialog, dialogue_line)
			}
		}
	
		if array_length(confirmed_dialog) == 0
		{
			confirmed_dialog = ["Golden Mimic Talk: No Dialog 0", "Golden Mimic Talk: No Dialog 1"]
		}
		var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
		if not(is_inside_array(confirmed_dialog[random_index], ["Golden Mimic Talk: No Dialog 0", "Golden Mimic Talk: No Dialog 1"]))
		{
			array_push(global.gmimic_told_dialog, confirmed_dialog[random_index])
		}
		dialogue_place(confirmed_dialog[random_index])
	}
	else
	{
		if round(random(1)) == 0
		{
			dialogue_place("Golden Mimic Can't Talk 0")
		}
		else
		{
			dialogue_place("Golden Mimic Can't Talk 1")
		}
	}
}
event_inherited()