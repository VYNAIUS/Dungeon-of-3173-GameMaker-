if hp - total_dealt_damage <= 0 and dialogue_progress != 99
{
	total_dealt_damage = 0
	hp = 1
	if dialogue_progress != 98
	{
		dialogue_place("Herbalist Battling End")
	}
	dialogue_progress = 98
}

event_inherited()