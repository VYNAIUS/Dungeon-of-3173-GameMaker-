event_inherited()

dialogue_progress = 0
dialogue_cooldown = 4