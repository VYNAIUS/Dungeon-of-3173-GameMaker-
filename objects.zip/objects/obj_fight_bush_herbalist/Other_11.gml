if dialogue_progress == 98
{
	animation_type = "none"
	global.stop_failsave = true
}
else if sympathy < 1
{
	animation_type = "fight"
	dialogue_cooldown -= 1
	if dialogue_progress < 98 and dialogue_cooldown <= 0
	{
		dialogue_cooldown = 5
		if dialogue_progress == 0
		{
			dialogue_place("Herbalist Battling Generic 0")
			dialogue_progress = 1
		}
		else if dialogue_progress == 1
		{
			dialogue_place("Herbalist Battling Generic 1")
			dialogue_progress = 2
		}
	}
}
else
{
	animation_type = "idle"
}