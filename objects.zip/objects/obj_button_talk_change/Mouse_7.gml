if button_pressed
{
	var possible_dialogue = []
	if global.change_reputation == -1
	{
		array_push(possible_dialogue, "Change Talk: Distrust")
	}
	else
	{
		if global.area_id == 0
		{
			array_push(possible_dialogue, "Change Talk: Garden")
		}
		else if global.area_id == 2
		{
			array_push(possible_dialogue, "Change Talk: Crystal")
		}
		if global.player_fear > 0.25
		{
			array_push(possible_dialogue, "Change Talk: Spirits")
		}
		if global.player_current_skill_0 == "split" or global.player_current_skill_1 == "split"
		{
			array_push(possible_dialogue, "Change Talk: Skill Split")
		}
		if global.player_current_skill_0 == "parry" or global.player_current_skill_1 == "parry"
		{
			array_push(possible_dialogue, "Change Talk: Skill Parry")
		}
		if global.player_current_skill_0 == "impenetrability" or global.player_current_skill_1 == "impenetrability"
		{
			array_push(possible_dialogue, "Change Talk: Skill Impenetrability")
		}
		if global.change_state == 0
		{
			array_push(possible_dialogue, "Change Talk: Sorrow")
			if global.player_current_skill_0 == "crystalise" or global.player_current_skill_1 == "crystalise"
			{
				array_push(possible_dialogue, "Change Talk: Skill Crystalise")
			}
		}
		if global.player_current_skill_0 == "trick" or global.player_current_skill_1 == "trick"
		{
			array_push(possible_dialogue, "Change Talk: Skill Trick")
		}
		if global.player_current_skill_0 == "pickpocket" or global.player_current_skill_1 == "pickpocket"
		{
			array_push(possible_dialogue, "Change Talk: Skill Pickpocket")
		}
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.change_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) == 0
	{
		if global.change_reputation == -1
		{
			confirmed_dialog = ["Change Talk: No Dialog"]
		}
		else
		{
			confirmed_dialog = ["Change Talk: No Dialog Polite"]
		}
	}
	var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
	if not(is_inside_array(confirmed_dialog[random_index], ["Change Talk: No Dialog", "Change Talk: No Dialog Polite"]))
	{
		array_push(global.change_told_dialog, confirmed_dialog[random_index])
	}
	dialogue_place(confirmed_dialog[random_index])
}
event_inherited()