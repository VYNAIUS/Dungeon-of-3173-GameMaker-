// Inherit the parent eventif button_pressed
if button_pressed and global.is_turn == false
{
	global.altar_choice = "strength"
	global.is_turn = true
	scr_grant_altar_upgrades()
}
event_inherited();