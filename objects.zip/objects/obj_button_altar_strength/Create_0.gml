// Inherit the parent event
event_inherited();

instance_create_layer(x, y + 192, "Instances", obj_altar_glyph_strength)