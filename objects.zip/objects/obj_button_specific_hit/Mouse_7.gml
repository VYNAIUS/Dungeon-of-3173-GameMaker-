if button_pressed and global.fighting_choice == "hit"
{
	global.is_turn = true
	global.fighting_choice = "none"
	global.entity_choose_type = "fight_specific"
}
event_inherited()