event_inherited()

if global.fight_type == "alchemist_fight"
{
	sprite_index = spr_bg_alchemist
}
else if global.fight_type == "heretic_tutorial_fight"
{
	sprite_index = spr_bg_altar_heretic
}
else
{
	switch (global.area_id)
	{
		case 0:
			sprite_index = spr_bg_garden
			break
		case 1:
			sprite_index = spr_bg_forest
			break
		case 2:
			sprite_index = spr_bg_cave
			break
		case 3:
			sprite_index = spr_bg_tundra
			break
		case 4:
			sprite_index = spr_bg_canyon
			break
		case 5:
			sprite_index = spr_bg_desert
			break
		case 6:
			sprite_index = spr_bg_rotten
			break
	}
}