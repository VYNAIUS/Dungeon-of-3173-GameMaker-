if button_pressed
{
	global.smimic_locked = true
	global.smimic_canbe_unlocked = false
	with obj_shop_smimic
	{
		event_user(0)
	}
	event_user(0)
	obj_button_smimic_deposit.destroy_self = true
	obj_button_smimic_undeposit.destroy_self = true
}
event_inherited()