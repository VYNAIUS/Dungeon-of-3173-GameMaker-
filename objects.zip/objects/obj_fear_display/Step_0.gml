if global.player_fear > 1
{
	global.player_fear = 1
}

if image_alpha < target_alpha
{
	image_alpha += 0.03
	if image_alpha > target_alpha
	{
		image_alpha = target_alpha
	}
	if global.panic_ambiance_played != undefined and audio_is_playing(global.panic_ambiance_played)
	{
		audio_sound_gain(global.panic_ambiance_played, image_alpha, 0)
	}
	else
	{
		global.panic_ambiance_played = audio_play_sound(amb_panic, 1, true, image_alpha)
	}
}
else if image_alpha > target_alpha
{
	image_alpha -= 0.03
	if image_alpha < target_alpha
	{
		image_alpha = target_alpha
	}
	if global.panic_ambiance_played != undefined and audio_is_playing(global.panic_ambiance_played)
	{
		audio_sound_gain(global.panic_ambiance_played, image_alpha, 0)
	}
	else
	{
		global.panic_ambiance_played = audio_play_sound(amb_panic, 1, true, image_alpha)
	}
}
if image_alpha == 0
{
	if global.panic_ambiance_played != undefined and audio_is_playing(global.panic_ambiance_played)
	{
		audio_sound_gain(global.panic_ambiance_played, 0, 0)
	}
	else
	{
		global.panic_ambiance_played = audio_play_sound(amb_panic, 1, true, 0)
	}
}

if global.is_map_transitioning
{
	target_alpha = 0
}
else
{
	target_alpha = global.player_fear
	if target_alpha < 0
	{
		target_alpha = 0
	}
}

image_xscale += size_increase
if image_xscale < 1
{
	image_xscale = 1
}
image_yscale = image_xscale
if image_xscale > 1.2
{
	size_increase -= random(0.0002)
	if size_increase < -0.005
	{
		size_increase = -0.005
	}
}
else if image_xscale < 1.1
{
	size_increase += random(0.0002)
	if size_increase > 0.005
	{
		size_increase = 0.005
	}
}