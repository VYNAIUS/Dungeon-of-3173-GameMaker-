image_alpha = 0
target_alpha = 0
size_increase = 0