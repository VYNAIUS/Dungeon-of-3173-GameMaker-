button_text = "Main menu"
text_scale = 0.25
text_color = #FFFFFF