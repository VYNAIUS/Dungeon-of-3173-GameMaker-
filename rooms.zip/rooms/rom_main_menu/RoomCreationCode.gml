main_reset()

global.menu_song_played = audio_play_sound(mus_cycles_creation, 0, false)