function scr_settings_save()
{
	var file = file_text_open_write("settings")
	
	for (var i = 0; i < array_length(global.settings_save_variables); i++)
	{
		var key = global.settings_save_variables[i]
		
		if variable_global_exists(key)
		{
			var val = variable_global_get(key)
			val = save_conversion(val)
			file_text_write_string(file, key + ": " + string(val) + "\n")
		}
	}
	
	file_text_close(file)
}

function scr_run_save(is_checkpoint = false)
{
	var file = 0
	if is_checkpoint
	{
		global.is_checkpoint = true
		file = file_text_open_write("run_save_checkpoint")
	}
	else
	{
		file = file_text_open_write("run_save")
	}
	
	for (var i = 0; i < array_length(global.run_save_variables); i++)
	{
		var key = global.run_save_variables[i]
		
		if variable_global_exists(key)
		{
			var val = variable_global_get(key)
			val = save_conversion(val)
			file_text_write_string(file, key + ": " + string(val) + "\n")
		}
	}
	global.is_checkpoint = false
	
	file_text_close(file)
}

function scr_meta_save()
{
	var file = file_text_open_write("meta_save")
	
	for (var i = 0; i < array_length(global.meta_save_variables); i++)
	{
		var key = global.meta_save_variables[i]
		
		if variable_global_exists(key)
		{
			var val = variable_global_get(key)
			val = save_conversion(val)
			file_text_write_string(file, key + ": " + string(val) + "\n")
		}
	}
	
	file_text_close(file)
}

function save_conversion(val)
{
	var new_val = val
	if is_array(val)
	{
		new_val = []
		for (var i = 0; i < array_length(val); i++)
		{
			array_push(new_val, save_conversion(val[i]))
		}
	}
	return new_val
}



function scr_load_saved_data(file_name)
{
	var file = file_text_open_read(file_name)
	var data = {}
	
	while file_text_eof(file) == false
	{
	    var line = file_text_read_string(file)
	    file_text_readln(file)
		
		var key = undefined
		var value = undefined
		
		var parts = string_split(string_trim(line), ": ", false, 1)
		if array_length(parts) == 2
		{
			key = parts[0]
			value = parts[1]
		}
		value = load_conversion(value)
		
		if variable_global_exists(key)
		{
			variable_global_set(key, value)
		}
	}

	file_text_close(file)
}

function load_conversion(val)
{
	var new_array = []
	if is_digit(val) and string_count(".", val) < 2
	{
		val = real(val)
	}
	else if string_char_at(val, 0) == "["
	{
		var current_value = ""
		var value_type = ""
		//show_debug_message("started the process!")
		for (var i = 2; i <= string_length(val); i++)
		{
			//show_debug_message(string_char_at(val, i))
			if string_trim(current_value) == "" and string_char_at(val, i) == "\"" and value_type == ""
			{
				current_value = ""
				value_type = "string"
				//show_debug_message("this is a string!")
			}
			else if string_char_at(val, i) == "\"" and value_type == "string"
			{
				value_type = ""
				//show_debug_message("this is no longer a string!")
			}
			else if string_trim(current_value) == "" and string_char_at(val, i) == "[" and value_type == ""
			{
				value_type = "array"
				current_value = string_char_at(val, i)
				//show_debug_message("this is an array!")
			}
			else if string_char_at(val, i) == "]" and value_type == "array"
			{
				value_type = ""
				current_value = current_value + string_char_at(val, i)
				//show_debug_message("this is no longer an array!")
			}
			else if (string_char_at(val, i) == "]" or string_char_at(val, i) == ",") and value_type == ""
			{
				//show_debug_message("end of the value! " + current_value)
				if string_trim(current_value) != ""
				{
					array_push(new_array, load_conversion(string_trim(current_value)))
				}
				//show_debug_message("the array is looking like this! " + string(new_array))
				current_value = ""
			}
			else
			{
				current_value = current_value + string_char_at(val, i)
				//show_debug_message("added to current_value! " + current_value)
			}
		}
		val = new_array
	}
	return val
}

function is_digit(str)
{
    var len = string_length(str)
	if len == 0
	{
		return false
	}
    for (var i = 1; i <= len; i++)
	{
        var ch = string_char_at(str, i)
        if (ord(ch) < 48 or ord(ch) > 57) and not(ch == "." or ch == "-")
		{
            return false
        }
    }
    return true
}