function scr_map_creation(random_seed = round(random_range(0, 10000)))
{
	random_set_seed(random_seed)
	global.saved_tiles = [[0, 0, 5, 0, "player"], [0, 0, 5, 0, "none"]]
	global.saved_corruption = []
	if global.area_id > 0
	{
		global.map_generation_turns = [[0, 0, 5, 0, "none"]]
	}
	else
	{
		global.map_generation_turns = [[0, 0, 5, 0, "altar"]]
	}
	
	var global_attempts = 0
	var global_style = ""
	var global_layer = 0
	var style_max_percentage = 0
	var unique_tile_amount = 0
	
	var good_tiles = []
	var bad_tiles = []
	var neutral_tiles = []
	var directions = []
	var current_direction = ""
	var turn = []
	var turn_index = 0
	var random_index = 0
	var direction_index = 0
	var can_generate = true
	var can_place = true
	var current_x = 0
	var current_y = 0
	var current_height = 0
	var current_layer = 0
	var max_distance = 0
	var furthest_turn = 0
	var x_increase = 0
	var y_increase = 0
	var min_x = 0
	var max_x = 0
	var min_y = 0
	var max_y = 0
	var current_type = "none"
	var tile_to_place = "none"
	var path_length = 0
	
	var start = global.area_start_position[global.area_id][round(random(array_length(global.area_start_position[global.area_id]) - 1))]
	var ultra_min_x = 0
	var ultra_max_x = 0
	var ultra_min_y = 0
	var ultra_max_y = 0
	switch string_char_at(start, 1)
	{
		case "d":
			ultra_min_y = - global.area_size_limit_y[global.area_id]
			break
		case "u":
			ultra_max_y = global.area_size_limit_y[global.area_id]
			break
		case "m":
			ultra_min_y = - round(global.area_size_limit_y[global.area_id] / 2)
			ultra_max_y = round(global.area_size_limit_y[global.area_id] / 2)
			break
	}
	switch string_char_at(start, 2)
	{
		case "r":
			ultra_min_x = - global.area_size_limit_x[global.area_id]
			break
		case "l":
			ultra_max_x = global.area_size_limit_x[global.area_id]
			break
		case "m":
			ultra_min_x = - round(global.area_size_limit_x[global.area_id] / 2)
			ultra_max_x = round(global.area_size_limit_x[global.area_id] / 2)
			break
	}
	
	var placed_boss = false
	var is_placing_elite = false
	var is_placing_change = false
	
	for (var i = 0; i < global.area_altar_amounts[global.area_id]; i++)
	{
		array_push(good_tiles, "altar")
	}
	
	for (var i = 0; i < global.area_treasure_amounts[global.area_id]; i++)
	{
		array_push(good_tiles, "treasure")
	}
	
	for (var i = 0; i < global.area_fight_amounts[global.area_id]; i++)
	{
		array_push(bad_tiles, "fight")
	}
	
	if global.final_area
	{
		array_push(good_tiles, "change")
	}
	
	for (var i = 0; i < array_length(global.area_specific_tiles[global.area_id]); i++)
	{
		var placed = false
		var tile = global.area_specific_tiles[global.area_id][i]
		if is_inside_array(tile, global.tile_types_good)
		{
			array_push(good_tiles, tile)
			placed = true
		}
		if placed 
		{continue}
		if is_inside_array(tile, global.tile_types_bad)
		{
			array_push(bad_tiles, tile)
			placed = true
		}
		if placed 
		{continue}
		if is_inside_array(tile, global.tile_types_neutral)
		{
			array_push(neutral_tiles, tile)
			placed = true
		}
		if placed 
		{continue}
	}
	
	unique_tile_amount = array_length(good_tiles) + array_length(bad_tiles) + array_length(neutral_tiles)
	var generation_pattern = []
	array_copy(generation_pattern, 0, global.area_generation_patterns[global.area_id][0], 0, array_length(global.area_generation_patterns[global.area_id][0]))
	
	for (var style_index = 0; style_index < array_length(generation_pattern); style_index++)
	{
		var generation_style = ""
		generation_style = generation_pattern[style_index]
		global_layer = global.area_generation_patterns[global.area_id][2][style_index]
		switch generation_style
		{
			case "boss":
				array_push(bad_tiles, "boss")
				is_placing_change = false
				is_placing_elite = false
				placed_boss = true
				generation_pattern[style_index] = "basic"
				style_index--
				break
			case "elite_battles":
				for (var i = 0; i < global.area_elite_fight_amounts[global.area_id]; i++)
				{
					array_push(bad_tiles, "fight_elite")
				}
				is_placing_elite = true
				generation_pattern[style_index] = "basic"
				style_index--
				break
			case "change":
				array_push(good_tiles, "change")
				is_placing_elite = false
				is_placing_change = true
				generation_pattern[style_index] = "basic"
				style_index--
				break
			case "basic":
				while array_length(good_tiles) + array_length(bad_tiles) + array_length(neutral_tiles) > 0 and (array_length(good_tiles) + array_length(bad_tiles) + array_length(neutral_tiles)) / unique_tile_amount > global.area_generation_patterns[global.area_id][1][style_index] and array_length(global.map_generation_turns) > 0
				{
					var funny_layer = global_layer + 1
					while funny_layer != global_layer
					{
						global_attempts += 1
						if global_attempts >= 10000
						{
							break
						}
					
					
						random_index = irandom(array_length(global.map_generation_turns) - 1)
						turn_index = random_index
						if placed_boss or is_placing_elite
						{
							furthest_turn = 0
							max_distance = 0
							var far_enough_turns = []
							for (var i = 0; i < array_length(global.map_generation_turns); i++) 
							{
								turn = global.map_generation_turns[i]
								var current_distance = power(power(turn[0], 2) + power(turn[1], 2), 0.5)
								if current_distance > max_distance and turn[3] == global_layer
								{
									max_distance = current_distance
									furthest_turn = i
								}
								if current_distance > global.area_path_lengths[global.area_id][1]
								{
									array_push(far_enough_turns, i)
								}
							}
							if placed_boss
							{
								turn_index = furthest_turn
							}
							else if is_placing_elite
							{
								if array_length(far_enough_turns) > 0
								{
									turn_index = far_enough_turns[round(random(array_length(far_enough_turns) - 1))]
								}
								else
								{
									turn_index = furthest_turn
								}
							}
						}
						funny_layer = global.map_generation_turns[turn_index][3]
					}
					if global_attempts >= 10000
					{
						break
					}
					turn = global.map_generation_turns[turn_index]
					current_x = turn[0]
					current_y = turn[1]
					current_height = turn[2]
					current_layer = turn[3]
					current_type = turn[4]
					for (var j = 0; j < array_length(global.tile_types_good); j++)
					{
						if current_type == global.tile_types_good[j]
						{
							current_type = "good"
						}
					}
					for (var j = 0; j < array_length(global.tile_types_bad); j++)
					{
						if current_type == global.tile_types_bad[j]
						{
							current_type = "bad"
						}
					}
					for (var j = 0; j < array_length(global.tile_types_neutral); j++)
					{
						if current_type == global.tile_types_neutral[j]
						{
							current_type = "neutral"
						}
					}
		
					if not placed_boss
					{
						directions = ["right", "down", "left", "up"]
					}
					else
					{
						directions = []
						if abs(current_x) > abs(current_y)
						{
							if current_x > 0
							{
								directions = ["right"]
							}
							else
							{
								directions = ["left"]
							}
						}
						else if abs(current_x) < abs(current_y)
						{
							if current_y > 0
							{
								directions = ["down"]
							}
							else
							{
								directions = ["up"]
							}
						}
						if current_x >= 0
						{
							if not(is_inside_array("right", directions))
							{
								array_push(directions, "right")
							}
						}
						if current_x <= 0
						{
							if not(is_inside_array("left", directions))
							{
								array_push(directions, "left")
							}
						}
						if current_y >= 0
						{
							if not(is_inside_array("down", directions))
							{
								array_push(directions, "down")
							}
						}
						if current_y <= 0
						{
							if not(is_inside_array("up", directions))
							{
								array_push(directions, "up")
							}
						}
					}
					while array_length(directions) > 0
					{
						random_index = irandom(array_length(directions) - 1)
						direction_index = random_index
						if placed_boss
						{
							direction_index = 0	
						}
						if not(placed_boss) and not(is_placing_change)
						{
							path_length = round(random_range(global.area_path_lengths[global.area_id][0], global.area_path_lengths[global.area_id][1]))
						}
						else
						{
							path_length = global.area_path_lengths[global.area_id][1]
							if is_placing_change
							{
								path_length = path_length * 4
							}
						}
						current_direction = directions[direction_index]
						switch current_direction
						{
							case "right":
								x_increase = 1
								y_increase = 0
								break
							case "down":
								x_increase = 0
								y_increase = 1
								break
							case "left":
								x_increase = -1
								y_increase = 0
								break
							case "up":
								x_increase = 0
								y_increase = -1
								break
						}
						can_generate = true
						var currenter_x = current_x
						var currenter_y = current_y
						var current_x_increase = x_increase
						var current_y_increase = y_increase
						var turning_path = []
						for (var k = 1; k < path_length + 1; k++)
						{
							currenter_x += current_x_increase
							currenter_y += current_y_increase
							if (currenter_x > ultra_max_x) or (currenter_y > ultra_max_y) or (currenter_x < ultra_min_x) or (currenter_y < ultra_min_y)
							{
								if not(placed_boss) and not(is_placing_change) and not(is_placing_elite)
								{
									can_generate = false
									break
								}
							}
							if is_placing_change and (k == path_length * 0.25 or k == path_length * 0.5 or k == path_length * 0.75)
							{
								var epic = current_x_increase
								current_x_increase = current_y_increase
								current_y_increase = epic
								if random(1) > 0.5
								{
									current_x_increase = - current_x_increase
									current_y_increase = - current_y_increase
								}
								array_push(turning_path, [current_x_increase, current_y_increase])
							}
							var secondary_x_increase = abs(y_increase)
							var secondary_y_increase = abs(x_increase)
							for (var n = - global.area_space_thickness[global.area_id]; n <= global.area_space_thickness[global.area_id]; n++)
							{
								for (var j = 0; j < array_length(global.saved_tiles); j++)
								{
									var weird_value1 = currenter_x + n * secondary_x_increase
									var weird_value2 = currenter_y + n * secondary_y_increase
									if weird_value1 == global.saved_tiles[j][0] and weird_value2 == global.saved_tiles[j][1] and current_layer == global.saved_tiles[j][3]
									{
										can_generate = false
										break
									}
								}
								if can_generate == false
								{break}
							}
							if can_generate == false
							{break}
						}
						if can_generate
						{
							can_place = true
							if is_placing_change
							{
								array_push(global.saved_corruption, [current_x, current_y, current_layer, 1])
							}
							var epic = 0
							for (var k = 0; k < path_length; k++)
							{
								current_x += x_increase
								current_y += y_increase
								if is_placing_change and (k == path_length * 0.25 or k == path_length * 0.5 or k == path_length * 0.75)
								{
									x_increase = turning_path[epic][0]
									y_increase = turning_path[epic][1]
									epic += 1
								}
								var height_increase = round(random_range(global.area_height_ranges[global.area_id][0], global.area_height_ranges[global.area_id][1]))
								current_height += height_increase
								if current_height > 5
								{current_height = 5}
								else if current_height < 0
								{current_height = 0}
								tile_to_place = "none"
								if is_placing_change
								{
									tile_to_place = "mana_hidden"
								}
								array_push(global.saved_tiles, [current_x, current_y, current_height, current_layer, tile_to_place])
								if current_x > max_x
								{
									max_x = current_x
								}
								else if current_x < min_x
								{
									min_x = current_x
								}
								if current_y > max_y
								{
									max_y = current_y
								}
								else if current_y < min_y
								{
									min_y = current_y
								}
							}
							for (var j = 0; j < array_length(global.saved_tiles); j++)
							{
								if x_increase + current_x == global.saved_tiles[j][0] and y_increase + current_y == global.saved_tiles[j][1] and current_layer == global.saved_tiles[j][3]
								{
									can_place = false
									break
								}
							}
							if can_place
							{
								tile_to_place = "none"
								switch current_type
								{
									case "bad":
										if array_length(good_tiles) > 0
										{
											random_index = irandom(array_length(good_tiles) - 1)
											tile_to_place = good_tiles[random_index]
											array_delete(good_tiles, random_index, 1)
										}
										else if array_length(bad_tiles) > 0
										{
											random_index = irandom(array_length(bad_tiles) - 1)
											tile_to_place = bad_tiles[random_index]
											array_delete(bad_tiles, random_index, 1)
										}
										else if array_length(neutral_tiles) > 0
										{
											random_index = irandom(array_length(neutral_tiles) - 1)
											tile_to_place = neutral_tiles[random_index]
											array_delete(neutral_tiles, random_index, 1)
										}
										break
									case "good":
										if array_length(bad_tiles) > 0
										{
											random_index = irandom(array_length(bad_tiles) - 1)
											tile_to_place = bad_tiles[random_index]
											array_delete(bad_tiles, random_index, 1)
										}
										else if array_length(good_tiles) > 0
										{
											random_index = irandom(array_length(good_tiles) - 1)
											tile_to_place = good_tiles[random_index]
											array_delete(good_tiles, random_index, 1)
										}
										else if array_length(neutral_tiles) > 0
										{
											random_index = irandom(array_length(neutral_tiles) - 1)
											tile_to_place = neutral_tiles[random_index]
											array_delete(neutral_tiles, random_index, 1)
										}
										break
									case "neutral":
										if random(1) > 0.5
										{
											if array_length(bad_tiles) > 0
											{
												random_index = irandom(array_length(bad_tiles) - 1)
												tile_to_place = bad_tiles[random_index]
												array_delete(bad_tiles, random_index, 1)
											}
											else if array_length(good_tiles) > 0
											{
												random_index = irandom(array_length(good_tiles) - 1)
												tile_to_place = good_tiles[random_index]
												array_delete(good_tiles, random_index, 1)
											}
											else if array_length(neutral_tiles) > 0
											{
												random_index = irandom(array_length(neutral_tiles) - 1)
												tile_to_place = neutral_tiles[random_index]
												array_delete(neutral_tiles, random_index, 1)
											}
										}
										else
										{
											if array_length(good_tiles) > 0
											{
												random_index = irandom(array_length(good_tiles) - 1)
												tile_to_place = good_tiles[random_index]
												array_delete(good_tiles, random_index, 1)
											}
											else if array_length(bad_tiles) > 0
											{
												random_index = irandom(array_length(bad_tiles) - 1)
												tile_to_place = bad_tiles[random_index]
												array_delete(bad_tiles, random_index, 1)
											}
											else if array_length(neutral_tiles) > 0
											{
												random_index = irandom(array_length(neutral_tiles) - 1)
												tile_to_place = neutral_tiles[random_index]
												array_delete(neutral_tiles, random_index, 1)
											}
										}
										break
								}
								array_push(global.saved_tiles, [x_increase + current_x, y_increase + current_y, current_height, current_layer, tile_to_place])
								if not(is_placing_change) and not(is_placing_elite) and not(placed_boss)
								{
									array_push(global.map_generation_turns, [x_increase + current_x, y_increase + current_y, current_height, current_layer, tile_to_place])
								}
								if current_x + x_increase > max_x
								{
									max_x = current_x + x_increase
								}
								else if current_x + x_increase < min_x
								{
									min_x = current_x + x_increase
								}
								if current_y + y_increase > max_y
								{
									max_y = current_y + y_increase
								}
								else if current_y + y_increase < min_y
								{
									min_y = current_y + y_increase
								}
							}
						}
						else if placed_boss
						{
							array_delete(global.map_generation_turns, turn_index, 1)
						}
			
						array_delete(directions, direction_index, 1)
						if can_generate
						{
							break
						}
					}
					var map_text = ""
					//for (var y_var = min_y; y_var < max_y + 1; y_var++)
					if 0 == 1
					{
						for (var x_var = min_x; x_var < max_x + 1; x_var++)
						{
							var placed_or_not = false
							for (var i = 0; i < array_length(global.saved_tiles); i++)
							{
								if global.saved_tiles[i][0] == x_var and global.saved_tiles[i][1] == y_var and global.saved_tiles[i][3] == global_layer
								{
									placed_or_not = true
									switch global.saved_tiles[i][4]
									{
										case "none":
											map_text = map_text + "o"
											break
										case "mana_hidden":
											map_text = map_text + "?"
											break
										case "altar":
										case "alchemist":
											map_text = map_text + "A"
											break
										case "fight":
											map_text = map_text + "F"
											break
										case "shop":
											map_text = map_text + "$"
											break
										case "mimic_steel":
										case "mimic_golden":
											map_text = map_text + "M"
											break
										case "boat_person":
											map_text = map_text + "b"
											break
										case "boss":
											map_text = map_text + "B"
											break
										case "change":
											map_text = map_text + "C"
											break
										case "hole_up":
											map_text = map_text + "U"
											break
										case "hole_down":
											map_text = map_text + "D"
											break
										case "treasure":
											map_text = map_text + "T"
											break
										case "player":
											break
									}
								}
							}
							if not(placed_or_not)
							{
								map_text = map_text + " "
							}
						}
						map_text = map_text + "\n"
					}
					//show_debug_message(map_text)
					
				}
				break
			case "water":
				var exit_amount_left = global.area_escape_river[global.area_id]
				var river_amount = global.area_river_amount[global.area_id]
				var river_direction = "none"
				var turn_amount = 0
				var turn_cooldown = 0
				while river_amount > 0
				{
					if river_amount >= random(1)
					{
						turn_amount = 0
						river_direction = ["right", "left", "down", "up"][round(random(3))]
						x_increase = 0
						y_increase = 0
						current_x = max_x
						current_y = max_y
						switch river_direction
						{
							case "right":
								current_x = min_x
								current_y = round(random_range(max_y - 3, min_y + 3))
								break
							case "left":
								current_y = round(random_range(max_y - 3, min_y + 3))
								break
							case "up":
								current_x = round(random_range(max_x - 3, min_x + 3))
								break
							case "down":
								current_y = min_y
								current_x = round(random_range(max_x - 3, min_x + 3))
								break
						}
						var has_hit_path = false
						while current_x <= max_x and current_y <= max_y and current_x >= min_x and current_y >= min_y
						{
							switch river_direction
							{
								case "right":
									x_increase = 1
									y_increase = 0
									break
								case "left":
									x_increase = -1
									y_increase = 0
									break
								case "up":
									x_increase = 0
									y_increase = -1
									break
								case "down":
									x_increase = 0
									y_increase = 1
									break
							}
							random_index = -1
							for (var j = 0; j < array_length(global.saved_tiles); j++)
							{
								if current_x == global.saved_tiles[j][0] and current_y == global.saved_tiles[j][1]
								{
									if global.saved_tiles[j][4] != "player"
									{
										random_index = j
										break
									}
								}
							}
							if random_index != -1
							{
								global.saved_tiles[random_index][2] = 0
								has_hit_path = true
							}
							else
							{
								var tile = "deep_water"
								if exit_amount_left > 0
								{
									tile = "exit_shortcut"
									exit_amount_left -= 1
								}
								array_push(global.saved_tiles, [current_x, current_y, 0, 0, tile])
							}
							current_x += x_increase
							current_y += y_increase
							turn_cooldown -= 1
							if turn_cooldown <= 0 and random(1) <= 0.1 and turn_amount < 4 and has_hit_path
							{
								if river_direction == "down" or river_direction == "up"
								{
									directions = ["right", "left"]
								}
								else
								{
									directions = ["up", "down"]
								}
								river_direction = directions[round(random(1))]
								turn_amount += 1
								turn_cooldown = 4
							}
						}
					}
					river_amount -= 1
				}
				break
			case "holes_down":
				var progress = 0
				var needed_progress = global.area_generation_patterns[global.area_id][1][style_index] * array_length(global.map_generation_turns)
				while progress < needed_progress
				{
					var funny_layer = global_layer + 1
					while funny_layer != global_layer
					{
						global_attempts += 1
						if global_attempts >= 10000
						{
							break
						}
					
					
						random_index = irandom(array_length(global.map_generation_turns) - 1)
						turn_index = random_index
						funny_layer = global.map_generation_turns[turn_index][3]
						if (global.map_generation_turns[turn_index][0] == 0 and global.map_generation_turns[turn_index][1] == 0) or is_inside_array(global.map_generation_turns[turn_index][4], ["hole_up", "hole_down"])
						{
							funny_layer = global_layer + 1
						}
					}
					if global_attempts >= 10000
					{
						break
					}
					turn = global.map_generation_turns[turn_index]
					current_x = turn[0]
					current_y = turn[1]
					current_height = turn[2]
					current_layer = turn[3]
					current_type = turn[4]
					for (var j = 0; j < array_length(global.tile_types_good); j++)
					{
						if current_type == global.tile_types_good[j]
						{
							array_push(good_tiles, current_type)
						}
					}
					for (var j = 0; j < array_length(global.tile_types_bad); j++)
					{
						if current_type == global.tile_types_bad[j]
						{
							array_push(bad_tiles, current_type)
						}
					}
					for (var j = 0; j < array_length(global.tile_types_neutral); j++)
					{
						if current_type == global.tile_types_neutral[j] and current_type != "none"
						{
							array_push(neutral_tiles, current_type)
						}
					}
				
					for (var j = 0; j < array_length(global.saved_tiles); j++)
					{
						if global.saved_tiles[j][0] == current_x and global.saved_tiles[j][1] == current_y and global.saved_tiles[j][3] == current_layer
						{
							global.saved_tiles[j][4] = "hole_down"
						}
					}
					global.map_generation_turns[turn_index][3] = global_layer - 1
					global.map_generation_turns[turn_index][4] = "hole_up"
					var exist_other_part = false
					for (var l = 0; l < array_length(global.saved_tiles); l++)
					{
						if global.saved_tiles[l][0] == current_x and global.saved_tiles[l][1] == current_y and global.saved_tiles[l][3] == current_layer - 1
						{
							for (var j = 0; j < array_length(global.tile_types_good); j++)
							{
								if current_type == global.tile_types_good[j]
								{
									array_push(good_tiles, current_type)
								}
							}
							for (var j = 0; j < array_length(global.tile_types_bad); j++)
							{
								if current_type == global.tile_types_bad[j]
								{
									array_push(bad_tiles, current_type)
								}
							}
							for (var j = 0; j < array_length(global.tile_types_neutral); j++)
							{
								if current_type == global.tile_types_neutral[j] and current_type != "none"
								{
									array_push(neutral_tiles, current_type)
								}
							}
							global.saved_tiles[l][4] = "hole_up"
							exist_other_part = true
						}
					}
					if not(exist_other_part)
					{
						array_push(global.saved_tiles, [current_x, current_y, current_height, current_layer - 1, "hole_up"])
					}
					progress += 1
				}
				break
			case "holes_up":
				var progress = 0
				var needed_progress = global.area_generation_patterns[global.area_id][1][style_index] * array_length(global.map_generation_turns)
				while progress < needed_progress
				{
					var funny_layer = global_layer - 1
					while funny_layer != global_layer
					{
						global_attempts += 1
						if global_attempts >= 10000
						{
							break
						}
					
					
						random_index = irandom(array_length(global.map_generation_turns) - 1)
						turn_index = random_index
						funny_layer = global.map_generation_turns[turn_index][3]
						if global.map_generation_turns[turn_index][0] == 0 and global.map_generation_turns[turn_index][1] == 0 or is_inside_array(global.map_generation_turns[turn_index][4], ["hole_up", "hole_down"])
						{
							funny_layer = global_layer - 1
						}
					}
					if global_attempts >= 10000
					{
						break
					}
					turn = global.map_generation_turns[turn_index]
					current_x = turn[0]
					current_y = turn[1]
					current_height = turn[2]
					current_layer = turn[3]
					current_type = turn[4]
					for (var j = 0; j < array_length(global.tile_types_good); j++)
					{
						if current_type == global.tile_types_good[j]
						{
							array_push(good_tiles, current_type)
						}
					}
					for (var j = 0; j < array_length(global.tile_types_bad); j++)
					{
						if current_type == global.tile_types_bad[j]
						{
							array_push(bad_tiles, current_type)
						}
					}
					for (var j = 0; j < array_length(global.tile_types_neutral); j++)
					{
						if current_type == global.tile_types_neutral[j] and current_type != "none"
						{
							array_push(neutral_tiles, current_type)
						}
					}
				
					for (var j = 0; j < array_length(global.saved_tiles); j++)
					{
						if global.saved_tiles[j][0] == current_x and global.saved_tiles[j][1] == current_y and global.saved_tiles[j][3] == current_layer
						{
							global.saved_tiles[j][4] = "hole_up"
						}
					}
					global.map_generation_turns[turn_index][3] = global_layer + 1
					global.map_generation_turns[turn_index][4] = "hole_down"
					var exist_other_part = false
					for (var l = 0; l < array_length(global.saved_tiles); l++)
					{
						if global.saved_tiles[l][0] == current_x and global.saved_tiles[l][1] == current_y and global.saved_tiles[l][3] == current_layer + 1
						{
							for (var j = 0; j < array_length(global.tile_types_good); j++)
							{
								if current_type == global.tile_types_good[j]
								{
									array_push(good_tiles, current_type)
								}
							}
							for (var j = 0; j < array_length(global.tile_types_bad); j++)
							{
								if current_type == global.tile_types_bad[j]
								{
									array_push(bad_tiles, current_type)
								}
							}
							for (var j = 0; j < array_length(global.tile_types_neutral); j++)
							{
								if current_type == global.tile_types_neutral[j] and current_type != "none"
								{
									array_push(neutral_tiles, current_type)
								}
							}
							global.saved_tiles[l][4] = "hole_down"
							exist_other_part = true
						}
					}
					if not(exist_other_part)
					{
						array_push(global.saved_tiles, [current_x, current_y, current_height, current_layer + 1, "hole_down"])
					}
					progress += 1
				}
				break
			case "garden_pathways":
				var points = []
				for (var j = min_y; j <= max_y; j++)
				{
					if j % 4 != 0
					{
						continue
					}
					for (var k = min_x; k <= max_x; k++)
					{
						if k % 4 == 0
						{
							var skip = false
							for (var i = 0; i < array_length(global.saved_tiles); i++)
							{
								if global.saved_tiles[i][0] == k and global.saved_tiles[i][1] == j and global.saved_tiles[i][3] == global_layer
								{
									skip = true
									break
								}
							}
							if skip
							{
								continue
							}
							array_push(global.saved_tiles, [k, j, 5, global_layer, "tree_0"])
							array_push(points, [k, j])
						}
					}
				}
				while array_length(points) > 0
				{
					current_x = points[0][0]
					current_y = points[0][1]
					var directions = []
					for (var j = 1; j < array_length(points); j++)
					{
						if current_x + 4 == points[j][0] and current_y == points[j][1]
						{
							array_push(directions, "r")
						}
						if current_x - 4 == points[j][0] and current_y == points[j][1]
						{
							array_push(directions, "l")
						}
						if current_x == points[j][0] and current_y + 4 == points[j][1]
						{
							array_push(directions, "u")
						}
						if current_x == points[j][0] and current_y - 4 == points[j][1]
						{
							array_push(directions, "d")
						}
						if array_length(directions) == 4
						{
							break
						}
					}
					while array_length(directions) > 0
					{
						x_increase = 0
						y_increase = 0
						switch directions[0]
						{
							case "r":
								x_increase = 1
								break
							case "l":
								x_increase = -1
								break
							case "u":
								y_increase = 1
								break
							case "d":
								y_increase = -1
								break
						}
						for (var j = 1; j < 4; j++)
						{
							array_push(global.saved_tiles, [current_x + (x_increase * j), current_y + (y_increase * j), 5, global_layer, "tree_0"])
						}
						array_delete(directions, 0, 1)
					}
					array_delete(points, 0, 1)
				}
				break
			case "decor":
				var amount_to_place = (abs(max_x) + abs(min_x) + 1) * (abs(max_y) + abs(min_y) + 1) + 1
				var attempts = 0
				var placed_coordinates = []
				for (var j = 0; j < array_length(global.saved_tiles); j++)
				{
					var current_tile = global.saved_tiles[j]
					if current_tile[3] == current_layer
					{
						if not(is_inside_array([current_tile[0], current_tile[1]], placed_coordinates))
						{
							amount_to_place -= 1
							array_push(placed_coordinates, [current_tile[0], current_tile[1]])
						}
						for (var k = 1; k < global.area_decor_separation[global.area_id] + 1; k++)
						{
							if current_tile[0] + k <= max_x and not(is_inside_array([current_tile[0] + k, current_tile[1]], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] + k, current_tile[1]])
							}
							if current_tile[0] - k >= min_x and not(is_inside_array([current_tile[0] - k, current_tile[1]], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] - k, current_tile[1]])
							}
							if current_tile[1] + k <= max_y and not(is_inside_array([current_tile[0], current_tile[1] + k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0], current_tile[1] + k])
							}
							if current_tile[1] - k >= min_y and not(is_inside_array([current_tile[0], current_tile[1] - k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0], current_tile[1] - k])
							}
							if current_tile[0] + k <= max_x and current_tile[1] + k <= max_y and not(is_inside_array([current_tile[0] + k, current_tile[1] + k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] + k, current_tile[1] + k])
							}
							if current_tile[0] - k >= min_x and current_tile[1] + k <= max_y and not(is_inside_array([current_tile[0] - k, current_tile[1] + k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] - k, current_tile[1] + k])
							}
							if current_tile[0] - k >= min_x and current_tile[1] - k >= min_y and not(is_inside_array([current_tile[0] - k, current_tile[1] - k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] - k, current_tile[1] - k])
							}
							if current_tile[0] + k <= max_x and current_tile[1] - k >= min_y and not(is_inside_array([current_tile[0] + k, current_tile[1] - k], placed_coordinates))
							{
								amount_to_place -= 1
								array_push(placed_coordinates, [current_tile[0] + k, current_tile[1] - k])
							}
						}
					}
				}
				amount_to_place = round(amount_to_place * global.area_decor_density[global.area_id])
				if global.area_decor_density[global.area_id] == 1
				{
					attempts = 1000
				}
				while attempts < 1000 and amount_to_place > 0
				{
					attempts += 1
					var current_x = round(random_range(min_x, max_x))
					var current_y = round(random_range(min_y, max_y))
					if is_inside_array([current_x, current_y], placed_coordinates)
					{
						continue
					}
					else
					{
						array_push(global.saved_tiles, [current_x, current_y, 5, current_layer, global.area_decor_tiles[global.area_id][round(random(array_length(global.area_decor_tiles[global.area_id]) - 1))]])
						array_push(placed_coordinates, [current_x, current_y])
						amount_to_place -= 1
					}
				}
				if amount_to_place > 0
				{
					for (var j = min_y; j <= max_y; j++)
					{
						for (var k = min_x; k <= max_x; k++)
						{
							if is_inside_array([k, j], placed_coordinates)
							{
								continue
							}
							else
							{
								amount_to_place -= 1
								array_push(global.saved_tiles, [k, j, 5, current_layer, global.area_decor_tiles[global.area_id][round(random(array_length(global.area_decor_tiles[global.area_id]) - 1))]])
							}
							if amount_to_place <= 0
							{
								break
							}
						}
						if amount_to_place <= 0
						{
							break
						}
					}
				}
				break
		}
		
		
		if global_attempts >= 10000
		{
			break
		}
	}
	
	
	
	

	
	if global_attempts >= 10000
	{
		show_message("Hey! It seems that the game is struggling to generate\nthis layout. Tell the developer that seed " + string(random_seed) + " doesn't work.\nAnyway, switching to a different seed.")
		scr_map_creation(random_seed + 1)
	}
}






function save_tiles()
{
	var shift_x = 0
	var shift_y = 0
	with (obj_map_tile)
	{
		var tile_data = [
			hover_x_position, hover_y_position, height, tile_layer, child
		]
		array_push(global.saved_tiles, tile_data)
		if child == "player"
		{
			shift_x = hover_x_position
			shift_y = hover_y_position
		}
		if corrupted
		{
			tile_data = [
			hover_x_position, hover_y_position, tile_layer, 1
			]
			array_push(global.saved_corruption, tile_data)
		}
	}
	for (var i = 0; i < array_length(global.saved_tiles); i++)
	{
		global.saved_tiles[i][0] = (global.saved_tiles[i][0] - shift_x) / 64
		global.saved_tiles[i][1] = (global.saved_tiles[i][1] - shift_y) / 64
	}
	for (var i = 0; i < array_length(global.saved_corruption); i++)
	{
		global.saved_corruption[i][0] = (global.saved_corruption[i][0] - shift_x) / 64
		global.saved_corruption[i][1] = (global.saved_corruption[i][1] - shift_y) / 64
	}
	global.saved_tiles = array_reverse(global.saved_tiles)
	global.saved_corruption = array_reverse(global.saved_corruption)
	
}





function add_time(time_to_add = 0)
{
	
	var on_map = true
	if array_length(global.saved_tiles) != 0
	{
		on_map = false
	}
	
	
	if global.game_time < 6 and global.game_time + time_to_add >= 6
	{
		reset_shop_items()
	}
	global.game_time += time_to_add
	if global.game_time >= 24
	{
		global.game_time -= 24
		global.seeker_spawn_progress += 0.05 * global.area_id + global.player_fear
		if global.area_id == 5
		{
			global.seeker_spawn_progress += 0.15
		}
		if not(global.seeker_defeated) and random(1) <= global.seeker_spawn_progress
		{
			var turned = false
			var attempts = 0
			var not_random_index = 0
			if not(on_map)
			{
				not_random_index = array_length(global.saved_tiles) - 1
				while not(turned)
				{
					if attempts < 30
					{
						var random_index = round(random_range(0, array_length(global.saved_tiles) - 1))
						if power(power(global.saved_tiles[random_index][0] * 64, 2) + power(global.saved_tiles[random_index][1] * 64, 2), 0.5) > global.current_vision_range and global.saved_tiles[random_index][3] == 0 and not(is_inside_array(global.saved_tiles[random_index][4], ["player", "deep_water"]))
						{
							array_push(global.saved_tiles, [global.saved_tiles[random_index][0], global.saved_tiles[random_index][1], global.saved_tiles[random_index][2], global.saved_tiles[random_index][3], "seeker"])
							turned = true
						}
					}
					else
					{
						if power(power(global.saved_tiles[not_random_index][0] * 64, 2) + power(global.saved_tiles[not_random_index][1] * 64, 2), 0.5) > global.current_vision_range and global.saved_tiles[not_random_index][3] == 0 and not(is_inside_array(global.saved_tiles[not_random_index][4], ["player", "deep_water"]))
						{
							array_push(global.saved_tiles, [global.saved_tiles[not_random_index][0], global.saved_tiles[not_random_index][1], global.saved_tiles[not_random_index][2], global.saved_tiles[not_random_index][3], "seeker"])
							turned = true
						}
						not_random_index -= 1
						if not_random_index < 0
						{
							turned = true
						}
					}
					attempts += 1
				}
			}
			else
			{
				var max_index = 0
				with obj_map_tile
				{
					if tile_index > max_index
					{
						max_index = tile_index
					}
				}
				while not(turned)
				{
					if attempts < 30
					{
						var random_index = round(random_range(0, max_index))
						with obj_map_tile
						{
							if random_index == tile_index
							{
								if power(power(hover_x_position, 2) + power(hover_y_position, 2), 0.5) > global.current_vision_range and tile_layer == 0 and not(is_inside_array(child, ["player", "deep_water"]))
								{
									var seeker = instance_create_layer(hover_x_position, hover_y_position, "Instances_Entities", obj_map_tile_seeker)
									seeker.tile_layer = tile_layer
									turned = true
									break
								}
							}
						}
					}
					else
					{
						with obj_map_tile
						{
							if power(power(hover_x_position, 2) + power(hover_y_position, 2), 0.5) > global.current_vision_range and tile_layer == 0 and not(is_inside_array(child, ["player", "deep_water"]))
							{
								instance_create_layer(hover_x_position, hover_y_position, "Instances_Entities", obj_map_tile_seeker)
								turned = true
								break
							}
						}
						turned = true
					}
					attempts += 1
				}
			}
		}
	}
	
	if global.smimic_locked
	{
		for (var i = 0; i < time_to_add; i++)
		{
			global.smimic_money += ceil(global.smimic_money * 0.01)
		}
	}
	
	for (var i = 0; i < time_to_add; i++)
	{
		if not(on_map)
		{
			for (var j = 0; j < array_length(global.saved_corruption); j++)
			{
				if global.saved_corruption[j][3] == 1
				{
					for (var epic = 0; epic < 4; epic++)
					{
						var x_increase = 0
						var y_increase = 0
						switch epic
						{
							case 0:
								x_increase = 1
								break
							case 1:
								y_increase = 1
								break
							case 2:
								x_increase = -1
								break
							case 3:
								y_increase = -1
								break
						}
						for (var k = 0; k < array_length(global.saved_tiles); k++)
						{
							if global.saved_tiles[k][0] == global.saved_corruption[j][0] + x_increase and global.saved_tiles[k][1] == global.saved_corruption[j][1] + y_increase
							{
								if global.saved_tiles[k][3] == global.saved_corruption[j][2] and not(is_inside_array(global.saved_tiles[k][4], global.tile_types_decor))
								{
									array_push(global.saved_corruption, [global.saved_tiles[k][0], global.saved_tiles[k][1], global.saved_tiles[k][3], 0.5])
								}
							}
						}
					}
				}
			}
			for (var j = 0; j < array_length(global.saved_corruption); j++)
			{
				global.saved_corruption[j][3] = 1
			}
		}
	}
	
	for (var i = 0; i < time_to_add; i++)
	{
		for (var j = 0; j < array_length(global.current_weathers); j++)
		{
			global.current_weather_duration[j] -= 1
			switch global.current_weathers[j]
			{
				case 0: // none
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = choose_weighted(global.area_weathers[global.area_id][0], global.area_weathers[global.area_id][1])
						global.current_weather_duration[j] = round(random_range(global.weather_durations[global.current_weathers[j]][0], global.weather_durations[global.current_weathers[j]][1]))
					}
					break
				case 1: //rain
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 0
						global.current_weather_duration[j] = round(random_range(global.weather_durations[0][0], global.weather_durations[0][1]))
					}
					else
					{
						var turned = false
						var attempts = 0
						var not_random_index = 0
						if not(on_map)
						{
							not_random_index = array_length(global.saved_tiles) - 1
							while not(turned)
							{
								if attempts < 15
								{
									var random_index = round(random_range(0, array_length(global.saved_tiles) - 1))
									if global.saved_tiles[random_index][4] == "none"
									{
										global.saved_tiles[random_index][4] = "mud"
										turned = true
									}
								}
								else
								{
									if global.saved_tiles[not_random_index][4] == "none"
									{
										global.saved_tiles[not_random_index][4] = "mud"
										turned = true
									}
									not_random_index -= 1
									if not_random_index < 0
									{
										turned = true
									}
								}
								attempts += 1
							}
						}
						else if instance_number(obj_map_tile) > 0
						{
							var max_index = 0
							with obj_map_tile
							{
								if tile_index > max_index
								{
									max_index = tile_index
								}
							}
							while not(turned)
							{
								if attempts < 15
								{
									var random_index = round(random_range(0, max_index))
									with obj_map_tile
									{
										if random_index == tile_index
										{
											if child == "none"
											{
												replace_tile(obj_map_tile_mud)
												turned = true
											}
										}
									}
								}
								else
								{
									with obj_map_tile
									{
										if child == "none"
										{
											replace_tile(obj_map_tile_mud)
											turned = true
											break
										}
									}
									turned = true
								}
								attempts += 1
							}
						}
					}
					break
				case 2: //fog
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 0
						global.current_weather_duration[j] = round(random_range(global.weather_durations[0][0], global.weather_durations[0][1]))
					}
					else
					{
						global.current_vision_range -= 75
						if global.current_vision_range < 100
						{
							global.current_vision_range = 100
						}
					}
					break
				case 3: //blizzard
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 0
						global.current_weather_duration[j] = round(random_range(global.weather_durations[0][0], global.weather_durations[0][1]))
					}
					else
					{
						global.current_vision_range -= 25
						if global.current_vision_range < 100
						{
							global.current_vision_range = 100
						}
						global.current_temperature -= 0.5
					}
					break
				case 4: //sandstorm
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 0
						global.current_weather_duration[j] = round(random_range(global.weather_durations[0][0], global.weather_durations[0][1]))
					}
					else
					{
						global.player_fear += 0.025
						global.current_vision_range -= 45
						if global.current_vision_range < 100
						{
							global.current_vision_range = 100
						}
					}
					break
				case 5: //drought
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 0
						global.current_weather_duration[j] = round(random_range(global.weather_durations[0][0], global.weather_durations[0][1]))
					}
					else
					{
						global.current_water_level -= 0.5
					}
					break
				case 6: //acid rain
					if global.current_weather_duration[j] <= 0
					{
						global.current_weathers[j] = 1
						global.current_weather_duration[j] = round(random_range(global.weather_durations[1][0], global.weather_durations[1][1]) / 2)
					}
					else
					{
						global.current_acidicity += 0.75
					}
					break
			}
		}
		if not(is_inside_array(2, global.current_weathers)) and not(is_inside_array(3, global.current_weathers)) and not(is_inside_array(4, global.current_weathers))
		{
			if global.current_vision_range < global.area_vision_ranges[global.area_id]
			{
				global.current_vision_range += 50
				if global.current_vision_range > global.area_vision_ranges[global.area_id]
				{
					global.current_vision_range = global.area_vision_ranges[global.area_id]
				}
			}
			else if global.current_vision_range > global.area_vision_ranges[global.area_id]
			{
				global.current_vision_range -= 50
				if global.current_vision_range < global.area_vision_ranges[global.area_id]
				{
					global.current_vision_range = global.area_vision_ranges[global.area_id]
				}
			}
		}
		if not(is_inside_array(4, global.current_weathers))
		{
			global.player_fear -= 0.05
			if global.player_fear < 0
			{
				global.player_fear = 0
			}
		}
		if global.area_id == 3
		{
			global.current_temperature -= 0.5
		}
		if not(is_inside_array(5, global.current_weathers))
		{
			if global.current_water_level < global.area_water_levels[global.area_id]
			{
				global.current_water_level += 0.5
				if global.current_water_level > global.area_water_levels[global.area_id]
				{
					global.current_water_level = global.area_water_levels[global.area_id]
				}
			}
			else if global.current_water_level > global.area_water_levels[global.area_id]
			{
				global.current_water_level -= 0.5
				if global.current_water_level < global.area_water_levels[global.area_id]
				{
					global.current_water_level = global.area_water_levels[global.area_id]
				}
			}
		}
	}
	
	if global.current_temperature < -10
	{
		global.current_temperature = -10
	}
	
	with obj_weather_manager
	{
		event_user(0)
	}
	with obj_map_real_time_manager
	{
		event_user(0)
	}
}



function enter_new_area(area_progress = 1)
{
	global.saved_tiles = []
	global.game_time = 6
	global.current_weathers = [0]
	global.current_weather_duration = [6]
	global.enemy_stat_multiplier += 1
	global.seeker_spawn_progress = 0
	global.area_visited += area_progress
	global.area_id += area_progress
	if global.final_area
	{
		global.end_condition = "win"
	}
	if global.area_id > array_length(global.area_names) - 1
	{
		global.area_id -= array_length(global.area_names)
		if global.game_mode == "story"
		{
			global.area_id = 0
			global.final_area = true
		}
	}
	for (var i = 0; i < area_progress; i++)
	{
		global.player_experience += round(xp_needed(global.player_level) * global.player_area_xp)
		while global.player_experience >= xp_needed(global.player_level)
		{
			global.player_experience -= xp_needed(global.player_level)
			global.player_level += 1
			global.level_ups_area_screen += 1
			level_up()
		}
	}
	reset_shop_items()
	global.current_vision_range = global.area_vision_ranges[global.area_id]
	global.current_temperature = 0
	global.current_acidicity = 0
	global.player_is_boat = false
	global.player_fear = 0
	global.player_oxygen = global.player_oxygen_limit
	global.current_water_level = global.area_water_levels[global.area_id]
	global.gmimic_items_sold = 0
	global.smimic_canbe_unlocked = true
	if global.end_condition != "win"
	{
		transition_to_area_popup()
	}
	else
	{
		transition_to_gameover()
	}
}

function tile_action_choose(all_tile_actions = ["none"])
{
	var priority = "none"
	for (var i = 0; i < array_length(all_tile_actions); i++)
	{
		var skip = false
		var current_action = all_tile_actions[i]
		for (var j = 0; j < array_length(global.tile_priorities); j++)
		{
			if global.tile_priorities[j] == priority
			{
				skip = true
				break
			}
			else if global.tile_priorities[j] == current_action
			{
				break
			}
		}
		if skip
		{
			continue
		}
		priority = current_action
	}
	return priority
}