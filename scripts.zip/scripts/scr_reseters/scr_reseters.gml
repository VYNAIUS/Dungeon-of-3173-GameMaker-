function reset_fighting()
{
	global.fighting_turn = 0
	global.stop_failsave = false
	global.action_done = false
	global.is_selecting_item = false
	global.enemy_action = false
	global.good_guy_done_count = 0
	global.enemy_done_count = 0
	global.is_turn = false
	global.action_type = "none"
	global.enemy_damage_dealt = 0
	global.enemy_index = 0
	global.turn_speed = global.default_turn_speed
	global.fighting_choice = "none"
	global.specific_target = noone
	global.entity_choose_type = "none"
	global.button_description = "none"
	global.upgrade_description = "none"
	global.is_map_transitioning = false
	global.coins_earned = 0
	global.experience_gained = 0
	global.shop_index_selected = 0
	global.spawnable_enemies_regular = [ obj_fight_bush_man , obj_fight_arachnoflower, obj_fight_ent,
	obj_fight_venomous_roser, obj_fight_plantmage, obj_fight_vine_bookster, obj_fight_buff_man,
	obj_fight_ambush_man, obj_fight_crystal_assasin, obj_fight_crystal_enemy, obj_fight_dark_mage,
	obj_fight_necromancer, obj_fight_spider_cave, obj_fight_soul, obj_fight_skeleton_warrior,
	obj_fight_snowman, obj_fight_icewarrior, obj_fight_iceghost, obj_fight_snowman_shotgun,
	obj_fight_spiderling, obj_fight_gargoyle, obj_fight_medusa, obj_fight_spider_matriarch,
	obj_fight_antlion_larva, obj_fight_antlion, obj_fight_cactus, obj_fight_tumbleweeder,
	obj_fight_sandwitch, obj_fight_wrom_small, obj_fight_ent_rotten, obj_fight_lifegiver,
	obj_fight_heretic_witch ]
	global.spawnable_enemies_heresy = [ obj_fight_heretic, obj_fight_heretic_summoner ]
	global.spawnable_bosses = [ obj_fight_rose_knight, obj_fight_shield_man, obj_fight_soul_catcher,
	obj_fight_yeti, obj_fight_spider_queen, obj_fight_jerboa, obj_fight_dark_knight ]
	
	global.shopkeeper_stolen_items_at_once = 0
}

function reset_map_variables()
{
	global.saved_tiles = [] // [x, y, height, layer, tile id]
	global.saved_corruption = [0, 0, 0] // [x, y, layer]
	global.player_move_by_x = 0
	global.player_move_by_y = 0
	global.level_ups_area_screen = 0
	global.area_id = 0
	global.final_area = false
	global.area_visited = 0
	global.area_altar_amounts = [5, 6, 7, 8, 9, 10, 9]
	global.area_fight_amounts = [7, 8, 8, 9, 9, 12, 11]
	global.area_treasure_amounts = [3, 2, 1, 1, 1, 1, 2]
	global.area_elite_fight_amounts = [1, 1, 1, 2, 1, 1, 2]
	global.area_specific_tiles = [
	["herbalist", "shop", "altar_grand"],
	["herbalist", "shop", "boat_person", "mimic_golden"],
	["herbalist", "shop", "boat_person", "mimic_steel", "alchemist"],
	["herbalist", "shop", "boat_person", "mimic_golden", "mimic_steel", "alchemist"],
	["herbalist", "shop", "boat_person", "mimic_golden", "mimic_steel", "alchemist"],
	["herbalist", "shop", "mimic_golden", "mimic_steel", "alchemist"],
	["herbalist", "shop", "boat_person", "mimic_golden", "mimic_steel", "alchemist", "heretic"]]
	global.area_path_lengths = [[3, 3], [1, 4], [1, 3], [2, 4], [1, 4], [3, 5], [2, 4]]
	global.area_size_limit_x = [20, 24, 15, 24, 40, 20, 25]
	global.area_size_limit_y = [15, 20, 15, 20, 5, 20, 20]
	global.area_start_position = [["ul", "ml", "dl"], ["um", "dm"], ["mm"], ["ur", "mr", "dr"],
	["ul", "ur"], ["dr", "dm", "dl"], ["ur", "um", "ul"]]
	global.area_space_thickness = [3, 3, 1, 2, 1, 2, 2]
	global.area_decor_density = [1, 0.4, 0.3, 0.02, 0.2, 0.07, 0.35]
	global.area_decor_separation = [1, 0, 0, 0, 0, 0, 0]
	global.area_decor_tiles = [["bush_0", "bush_1", "bush_2"], ["bush_0", "bush_1", "bush_2", "tree_0", "tree_0", "tree_1", "tree_1"],
	["stalagmite_0", "stalagmite_1", "stalagmite_2"], ["snowgrower_0", "snowgrower_1", "snowgrower_2"],
	["stalagmite_0", "stalagmite_1", "stalagmite_2"],
	["cactus_0", "cactus_0", "cactus_0", "cactus_0", "cactus_0", "cactus_0", "cactus_1", "cactus_2"],
	["tree_rotten_0", "tree_rotten_1"]]
	global.area_height_ranges = [[0, 0], [-1, 1], [-1, 1], [-1, 1], [-1, 1], [-2, 1], [-2, 2]]
	global.area_river_amount = [0, 1, 1.75, 2.3, 0, 1.5, 2.7]
	global.area_escape_river = [0, 1, 1, 1, 0, 1, 0]
	global.area_map_colors = [ #00D000, #208020, #8C8C8C, #C8C8E6, #96B496, #E5E550, #565656 ]
	global.area_map_decor_colors = [ #00D000, #20A020, #707070, #C8C8E6, #96B496, #00FF82, #646464 ]
	global.area_water_map_colors = [ #00C0FF, #0080FF, #404080, #009696, #00AA64, #00A6D8, #00FF00 ]
	global.area_water_levels = [1, 2, 2, 1, 1, -4, 0.75]
	global.area_names = [ "Garden", "Deep Forest", "Cave", "Tundra", "Canyon", "Desert", "Rotten Forest" ]
	global.area_music = [ mus_garden, mus_deep_forest, mus_cave, mus_tundra, mus_canyon, mus_desert, mus_rotten_forest ]
	global.area_ambient = [ undefined, amb_forest, amb_cave, undefined, undefined, undefined, undefined ]
	global.area_weathers = [ [[0], [1]], [[0, 1, 2, 5], [1, 3, 1, 1]], [[0], [1]], [[0, 2, 3], [1, 1, 3]],
	[[0, 1, 2], [2, 1, 1]], [[0, 4], [2, 3]], [[0, 6], [1, 2]] ]
	global.area_vision_ranges = [ 6969, 700, 400, 500, 700, 800, 600 ]
	global.area_generation_patterns = [
	[["basic", "elite_battles", "boss", "garden_pathways", "decor"], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]],
	[["basic", "elite_battles", "boss", "water", "decor"], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]],
	[["basic", "elite_battles", "change", "boss", "water", "decor"], [0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0]],
	[["basic", "elite_battles", "boss", "water", "decor"], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]],
	[["basic", "elite_battles", "boss", "decor"], [0, 0, 0, 0], [0, 0, 0, 0]],
	[["basic", "holes_down", "basic", "holes_up", "basic", "elite_battles", "boss", "water", "decor"], [0.7, 0.1, 0.3, 0.05, 0, 0, 0, 0, 0], [0, 0, -1, -1, 0, -1, 0, 0, 0]],
	[["basic", "elite_battles", "boss", "water", "decor"], [0, 0, 0, 0, 0], [0, 0, 0, 0, 0]]
	]
	global.map_generation_turns = []
	global.tile_types = ["none", "altar", "fight", "shop", "herbalist", "boss", "boat_person", "mimic_golden", "mimic_steel",
	"treasure", "alchemist", "altar_grand", "hole_down", "hole_up", "heretic", "change"]
	global.tile_types_good = ["altar", "shop", "herbalist", "boat_person", "mimic_golden", "mimic_steel", "treasure",
	"alchemist", "altar_grand", "heretic", "change"]
	global.tile_types_bad = ["fight", "boss"]
	global.tile_types_neutral = ["none", "hole_down", "hole_up"]
	global.tile_types_decor = ["bush_0", "bush_1", "bush_2", "tree_0", "tree_1", "stalagmite_0",
	"stalagmite_1", "stalagmite_2", "snowgrower_0", "snowgrower_1", "snowgrower_2", "cactus_0",
	"cactus_1", "cactus_2", "tree_rotten_0", "tree_rotten_1"]
	global.tile_priorities = ["seeker", "boss", "boss_corrupted", "fight", "fight_corrupted", "altar",
	"treasure", "treasure_corrupted", "altar_grand", "altar_grand_corrupted", "boat_person",
	"boat_person_corrupted", "mud", "mud_corrupted", "escape_main", "escape_main_corrupted", "hole_down",
	"hole_up", "hole_down_corrupted", "hole_up_corrupted", "alchemist", "alchemist_corrupted", "shop",
	"shop_corrupted", "herbalist", "herbalist_corrupted", "mimic_golden", "mimic_golden_corrupted", "mimic_steel", "mimic_steel_corrupted",
	"heretic", "heretic_corrupted", "change", "change_corrupted", "altar_corrupted"]
	global.current_weathers = [0]
	global.current_weather_duration = [6]
	global.weather_names = ["", "Rain", "Fog", "Blizzard", "Sandstorm", "Drought", "Toxic Rain"]
	global.weather_durations = [[5, 6], [6, 12], [5, 10], [6, 8], [6, 10], [4, 8], [4, 8]]
	global.area_extra_battles_rewards = [[obj_shop_item_vines, obj_shop_item_pure_blossom],
	[obj_shop_item_barrier, obj_shop_item_shield_dagger, obj_shop_item_impenetrability],
	[obj_shop_item_mana_crystal, obj_shop_item_traveller_hallow],
	[obj_shop_item_penetrator_icicle, obj_shop_item_yeti_fur],
	[obj_shop_item_gargoyle_feather, obj_shop_item_antidote],
	[obj_shop_item_fear_eye, obj_shop_item_cactus],
	[obj_shop_item_lifegiver_mask, obj_shop_item_undead_mark]]
	global.current_water_level = global.area_water_levels[global.area_id]
	global.current_vision_range = global.area_vision_ranges[global.area_id]
	global.current_temperature = 0
	global.current_acidicity = 0
	global.game_time = 6
}

function reset_shop_items()
{
	if global.alchemist_encountered_today and not(global.alchemist_bought) and not(global.alchemist_anger == -1)
	{
		global.alchemist_anger += 0.4
	}
	global.shopkeeper_dead_rn = false
	global.alchemist_encountered_today = false
	global.alchemist_bought = false
	var shopkeeper_possible_items = []
	var alchemist_possible_items = []
	for (var i = 0; i < array_length(global.shopkeeper_possible_items_idnames); i++)
	{
		array_push(shopkeeper_possible_items, global.shopkeeper_possible_items_idnames[i])
	}
	for (var i = 0; i < array_length(global.alchemist_possible_items_idnames); i++)
	{
		array_push(alchemist_possible_items, global.alchemist_possible_items_idnames[i])
	}
	if global.area_id == 3
	{
		array_push(shopkeeper_possible_items, "tea_winter")
	}
	else if global.area_id == 4
	{
		array_push(shopkeeper_possible_items, "antidote")
	}
	global.shopkeeper_items = []
	global.alchemist_items = []
	for (var i = 0; i < 3; i++)
	{
		var item = shopkeeper_possible_items[round(random_range(0, array_length(shopkeeper_possible_items) - 1))]
		array_delete(shopkeeper_possible_items, array_get_index(shopkeeper_possible_items, item), 1)
		array_push(global.shopkeeper_items, item)
		item = alchemist_possible_items[round(random_range(0, array_length(alchemist_possible_items) - 1))]
		array_delete(alchemist_possible_items, array_get_index(alchemist_possible_items, item), 1)
		array_push(global.alchemist_items, item)
	}
	if random(1) < global.shopkeeper_suspicion
	{
		global.shopkeeper_knows = true
	}
	else
	{
		global.shopkeeper_knows = false
	}
}

function reset_player_stats()
{
	global.player_max_hp = 100
	global.player_dmg = 5
	global.player_base_defense = 0
	global.player_base_magic_defense = 0
	global.player_power_level = 1
	global.player_crit_chance = 0.05
	global.player_poison = 0
	
	global.player_fear = 0
	
	global.player_money_boost = 0
	global.player_area_xp = 0
	global.player_consume = 0
	
	global.player_current_skill_0 = "defend"
	global.player_current_skill_1 = "idle"
	global.player_skills = []
	global.skill_tutorial = 0
	
	global.player_money = 0
	global.player_experience = 0
	global.player_level = 0
	
	global.player_oxygen_limit = 4 - (global.game_difficulty - 40) / 30
	global.player_oxygen = global.player_oxygen_limit
	global.player_oxygen_penalty = 0
	
	global.player_boat_durability = 0
	global.player_is_boat = false
	global.player_consumable_items = []
	global.player_passive_items = []


	global.enemy_stat_multiplier = 0

	global.enemies_to_place = []
	global.players_to_place = []
	global.fight_type = "none"


	global.altar_choice = "none"
	global.altar_grand_choice = "none"
	global.altar_upgrades = []
	global.altar_last_upgrades = []
	global.altar_encounters = 0
	global.corrupted_altar_encounters = 0
	
	global.last_treasure = "none"
	global.rejected_treasure_inarow = 0
	
	
	global.boat_bought = false
	global.player_boat_tutorial = false
	global.player_enter_tutorial = false
	global.player_saved_times = 0
	
	global.gmimic_item_shown = false
	global.gmimic_items_sold = 0
	global.gmimic_current_item = 0
	global.gmimic_last_item = 0
	
	global.shopkeeper_suspicion = 0
	global.shopkeeper_debt = 0
	global.shopkeeper_deaths = 0
	global.shopkeeper_dead_rn = false
	
	global.herbalist_defeated = false
	global.herbalist_fool_tried = 0
	
	global.alchemist_anger = 0
	global.alchemist_bought = false
	global.alchemist_encountered_today = false
	global.alchemist_deaths = 0
	global.midas_state = 0
	
	global.smimic_money = 0
	global.smimic_locked = true
	global.smimic_canbe_unlocked = true
	
	global.change_reputation = 0
	global.change_state = 0 // -2 - consumed; -1 - cleansed; 0 - alive; 1 - helping
	global.death_state = 0 // -2 - consumed; -1 - escaped; 0 - none; 1 - battle ready; 2 - battle completed 
	
	global.seeker_defeated = false
	global.seeker_spawn_progress = 0
	
	global.heretic_reputation = 0
	global.heretic_joining_attempts = 0
	global.heretic_deaths = 0
	
	global.altar_told_dialog = []
	global.shopkeeper_told_dialog = []
	global.alchemist_told_dialog = []
	global.boatperson_told_dialog = []
	global.gmimic_told_dialog = []
	global.change_told_dialog = []
	global.smimic_told_dialog = []
	global.fear_told_dialog = []
	global.seeker_told_dialog = []
	global.heretic_told_dialog = []
	global.herbalist_told_dialog = []
	global.finale_told_dialog = []
	
	global.shopkeeper_encounters = 0
	global.alchemist_encounters = 0
	global.boatperson_encounters = 0
	global.gmimic_encounters = 0
	global.change_encounters = 0
	global.smimic_encounters = 0
	global.heretic_encounters = 0
	global.herbalist_encounters = 0
	global.fear_encounters = 0
}

function main_reset()
{
	global.menu_song_played = undefined
	global.battle_song_played = undefined
	global.area_song_played = undefined
	global.npc_song_played = undefined
	
	global.area_ambiance_played = undefined
	global.panic_ambiance_played = undefined
	global.rain_ambiance_played = undefined
	global.blizzard_ambiance_played = undefined
	global.sandstorm_ambiance_played = undefined
	
	global.game_mode = global.game_original_mode
	global.game_difficulty = global.game_original_difficulty
	
	global.end_condition = "lose"
	global.current_exit_type = "none"
	
	global.fear_trick_refusal = 0
	
	reset_fighting()
	
	reset_dialogue()
	
	reset_map_variables()
	
	reset_player_stats()
	
	
	global.every_single_consumable_item = [ obj_consitem_item, obj_consitem_cookie, obj_consitem_tea_winter,
obj_consitem_potion_heal, obj_consitem_potion_stun, obj_consitem_poison_flask, obj_consitem_potion_berserk,
obj_consitem_potion_impenetrability ]
	global.every_single_passive_item = [ obj_passitem, obj_passitem_impenetrability,
obj_passitem_spikes, obj_passitem_undeadmark, obj_passitem_lifesteal, obj_passitem_enemyexplotano,
obj_passitem_gargoylefeather, obj_passitem_yetifur, obj_passitem_lifegivermask, obj_passitem_penetratoricicle,
obj_passitem_feareye, obj_passitem_barrier, obj_passitem_shielddagger, obj_passitem_antidote,
obj_passitem_cactus, obj_passitem_vines, obj_passitem_manacrystal, obj_passitem_pureblossom ]
	
	
	global.shopkeeper_possible_items = [ obj_shop_item_poison_flask, obj_shop_item_armor_spikes,
	obj_shop_item_midas_bottle, obj_shop_item_cookie, obj_shop_item_tea_winter,
	obj_shop_item_antidote ]
	global.alchemist_possible_items = [ obj_shop_item_tea_winter, obj_shop_item_potion_heal,
	obj_shop_item_potion_stun, obj_shop_item_potion_berserk, obj_shop_item_potion_impenetrability ]
	global.shopkeeper_possible_items_idnames = []
	global.alchemist_possible_items_idnames = []
	for (var i = 0; i < array_length(global.shopkeeper_possible_items); i++)
	{
		var item = instance_create_depth(0, 0, 0, global.shopkeeper_possible_items[i])
		array_push(global.shopkeeper_possible_items_idnames, item.id_name)
		instance_destroy(item)
	}
	for (var i = 0; i < array_length(global.alchemist_possible_items); i++)
	{
		var item = instance_create_depth(0, 0, 0, global.alchemist_possible_items[i])
		array_push(global.alchemist_possible_items_idnames, item.id_name)
		instance_destroy(item)
	}
	global.shopkeeper_possible_items_THATCANBESTORED = [ obj_shop_item_nothing ]
	global.alchemist_possible_items_THATCANBESTORED = [ obj_shop_item_nothing ]
	array_copy(global.shopkeeper_possible_items_THATCANBESTORED, 1, global.shopkeeper_possible_items, 0, array_length(global.shopkeeper_possible_items))
	array_copy(global.alchemist_possible_items_THATCANBESTORED, 1, global.alchemist_possible_items, 0, array_length(global.alchemist_possible_items))
	
	global.golden_mimic_possible_items = [ obj_shop_item_midas_bottle, obj_shop_item_impenetrability,
obj_shop_item_undead_mark, obj_shop_item_lifesteal, obj_shop_item_traveller_hallow,
obj_shop_item_enemy_explotano, obj_shop_item_shield_dagger, obj_shop_item_barrier ]
	
	global.possible_treasures_common = [ obj_shop_item_undead_mark, obj_shop_item_fear_eye, obj_shop_item_penetrator_icicle,
obj_shop_item_barrier ]
	global.possible_treasures_rare = [ obj_shop_item_impenetrability, obj_shop_item_vines,
obj_shop_item_shield_dagger, obj_shop_item_mana_crystal ]
	global.possible_treasures_epic = [ obj_shop_item_lifegiver_mask, obj_shop_item_yeti_fur,
obj_shop_item_gargoyle_feather, obj_shop_item_cactus, obj_shop_item_enemy_explotano ]
	
	global.current_ui_layer = 0
	global.is_paused = false
	global.pause_delay = false


	global.is_dialogue = false
	global.tile_action = "none"
	global.player_can_move = false
	global.is_map_transitioning = false
	global.transition_type = "none"
	global.jankcode_thing = 0
	global.is_keybind_change = false
	
	
	randomize()
	reset_shop_items()
}