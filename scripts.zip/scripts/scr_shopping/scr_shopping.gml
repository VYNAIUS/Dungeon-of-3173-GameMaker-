function shop_buy(index)
{
	if room == rom_shop
	{
		index = global.shopkeeper_items[index].id_name
	}
	else if room == rom_shop_alchemist
	{
		index = global.alchemist_items[index].id_name
	}
	grant_item_upgrade(index)
}

function grant_item_upgrade(index)
{
	switch (index)
	{
	case "poison_flask":
		array_push(global.player_consumable_items, "poison_flask")
		global.upgrade_description = "poison_flask"
		break
	case "armor_spikes":
		array_push(global.player_passive_items, "spikes")
		global.upgrade_description = "armor_spikes"
		break
	case "midas_bottle":
		global.player_money_boost += 5
		global.upgrade_description = "midas_bottle"
		break
	case "cookie":
		array_push(global.player_consumable_items, "cookie")
		global.upgrade_description = "cookie"
		break
	case "tea_winter":
		array_push(global.player_consumable_items, "tea_winter")
		global.upgrade_description = "tea_winter"
		break
	case "impenetrability":
		array_push(global.player_passive_items, "impenetrability")
		global.upgrade_description = "impenetrability"
		break
	case "undead_mark":
		array_push(global.player_passive_items, "undead_mark")
		global.upgrade_description = "regen_increase"
		break
	case "lifesteal":
		array_push(global.player_passive_items, "lifesteal")
		global.upgrade_description = "lifesteal"
		break
	case "traveller_hallow":
		global.player_area_xp += 0.15
		global.upgrade_description = "traveller_hallow"
		break
	case "consume":
		global.player_consume += 0.03
		global.upgrade_description = "consume"
		break
	case "lifegiver_mask":
		array_push(global.player_passive_items, "lifegiver_mask")
		global.upgrade_description = "lifegiver_mask"
		break
	case "yeti_fur":
		array_push(global.player_passive_items, "yeti_fur")
		global.upgrade_description = "yeti_fur"
		break
	case "fear_eye":
		array_push(global.player_passive_items, "fear_eye")
		global.upgrade_description = "fear_eye"
		break
	case "vines":
		array_push(global.player_passive_items, "vines")
		global.upgrade_description = "vines"
		break
	case "shield_dagger":
		array_push(global.player_passive_items, "shield_dagger")
		global.upgrade_description = "shield_dagger"
		break
	case "penetrator_icicle":
		array_push(global.player_passive_items, "penetrator_icicle")
		global.upgrade_description = "penetrator_icicle"
		break
	case "gargoyle_feather":
		array_push(global.player_passive_items, "gargoyle_feather")
		global.upgrade_description = "gargoyle_feather"
		break
	case "enemy_explotano":
		array_push(global.player_passive_items, "enemy_explotano")
		global.upgrade_description = "enemy_explotano"
		break
	case "cactus":
		array_push(global.player_passive_items, "cactus")
		global.upgrade_description = "cactus"
		break
	case "barrier":
		array_push(global.player_passive_items, "barrier")
		global.upgrade_description = "barrier"
		break
	case "antidote":
		array_push(global.player_passive_items, "antidote")
		global.upgrade_description = "antidote"
		break
	case "mana_crystal":
		array_push(global.player_passive_items, "mana_crystal")
		global.upgrade_description = "mana_crystal"
		break
	case "pure_blossom":
		array_push(global.player_passive_items, "pure_blossom")
		global.upgrade_description = "pure_blossom"
		break
	case "potion_heal":
		array_push(global.player_consumable_items, "potion_heal")
		global.upgrade_description = "potion_heal"
		break
	case "potion_stun":
		array_push(global.player_consumable_items, "potion_stun")
		global.upgrade_description = "potion_stun"
		break
	case "potion_berserk":
		array_push(global.player_consumable_items, "potion_berserk")
		global.upgrade_description = "potion_berserk"
		break
	case "potion_impenetrability":
		array_push(global.player_consumable_items, "potion_impenetrability")
		global.upgrade_description = "potion_impenetrability"
		break
	}
}

function golden_mimic_new_item()
{
	if instance_exists(obj_button_gmimic_accept) == false
	{
		instance_create_layer(683, 250, "Instances_UI", obj_button_gmimic_accept)
	}
	if instance_exists(obj_button_gmimic_reroll) == false
	{
		instance_create_layer(683, 400, "Instances_UI", obj_button_gmimic_reroll)
	}
	global.gmimic_item_shown = true
	while true
	{
		with obj_shop_item
		{
			event_user(0)
		}
		var item = global.golden_mimic_possible_items[round(random(array_length(global.golden_mimic_possible_items) - 1))]
		global.gmimic_current_item = instance_create_layer(obj_item_box_gmimic.x, obj_item_box_gmimic.y, "Instances_UI", item)
		if global.gmimic_last_item == global.gmimic_current_item.id_name
		{continue}
		else
		{break}
	}
	with obj_item_box_gmimic
	{
		item_rarity = global.gmimic_current_item.item_rarity
	}
	global.gmimic_current_item.hover_x_position = obj_item_box_gmimic.x
	global.gmimic_current_item.hover_y_position = obj_item_box_gmimic.y
	global.gmimic_last_item = global.gmimic_current_item.id_name
}

function treasure_new_item()
{
	if global.rejected_treasure_inarow < 3
	{
		var rarity = choose_weighted(["common", "rare", "epic"], [4, 3, 1])
		var item = obj_shop_item
		while true
		{
			with obj_shop_item
			{
				event_user(0)
			}
			if global.fight_type == "none"
			{
				switch rarity
				{
					case "common":
						item = global.possible_treasures_common[round(random(array_length(global.possible_treasures_common) - 1))]
						break
					case "rare":
						item = global.possible_treasures_rare[round(random(array_length(global.possible_treasures_rare) - 1))]
						break
					case "epic":
						item = global.possible_treasures_epic[round(random(array_length(global.possible_treasures_epic) - 1))]
						break
				}
			}
			else if global.fight_type == "elite"
			{
				item = global.area_extra_battles_rewards[global.area_id][round(random(array_length(global.area_extra_battles_rewards[global.area_id]) - 1))]
			}
			item = instance_create_layer(obj_item_box_treasure.x, obj_item_box_treasure.y, "Instances", item)
			with obj_item_box_treasure
			{
				item_rarity = item.item_rarity
			}
			if global.last_treasure == item.id_name
			{
				instance_destroy(item)
				continue
			}
			else
			{break}
		}
		global.last_treasure = item.id_name
	}
	else
	{
		var item = instance_create_layer(obj_item_box_treasure.x, obj_item_box_treasure.y, "Instances", obj_shop_item_consume)
		with obj_item_box_treasure
		{
			item_rarity = item.item_rarity
		}
	}
}