function scr_grant_altar_upgrades()
{
	if room == rom_altar
	{
		switch global.altar_choice
		{
			case "vitality":
				global.player_max_hp += 10
				global.button_description = "vitality_upgrade"
				audio_play_sound(snd_altar_vitality, 0, false, 1, 0, 1)
				break
			case "strength":
				global.player_dmg += 2
				global.button_description = "strength_upgrade"
				audio_play_sound(snd_altar_strength, 0, false, 1, 0, 1)
				break
			case "protection":
				global.player_base_defense += 2
				global.button_description = "protection_upgrade"
				audio_play_sound(snd_altar_protection, 0, false, 1, 0, 1)
				break
			case "might":
				global.player_crit_chance += 0.05
				global.button_description = "might_upgrade"
				audio_play_sound(snd_altar_might, 0, false, 1, 0, 1)
				break
			case "magic_protection":
				global.player_base_magic_defense += 2
				global.button_description = "magic_protection_upgrade"
				audio_play_sound(snd_altar_magic_protection, 0, false, 1, 0, 1)
				break
			case "innocence":
				if global.player_power_level - round(global.player_power_level * 95) / 100 >= 0.05
				{
					global.player_power_level = round(global.player_power_level * 95) / 100
				}
				else
				{
					global.player_power_level = round(global.player_power_level * 100) / 100 - 0.05
				}
				if global.player_power_level < 0
				{
					global.player_power_level = 0
				}
				global.button_description = "innocence_upgrade"
				audio_play_sound(snd_altar_innocence, 0, false, 1, 0, 1)
				break
		}
	}
	else if room == rom_altar_grand
	{
		switch global.altar_grand_choice
		{
			case "skill_split":
				array_push(global.player_skills, "split")
				audio_play_sound(snd_altar_vitality, 0, false, 1, 0, 1)
				break
			case "skill_parry":
				array_push(global.player_skills, "parry")
				audio_play_sound(snd_altar_strength, 0, false, 1, 0, 1)
				break
			case "skill_impenetrability":
				array_push(global.player_skills, "impenetrability")
				audio_play_sound(snd_altar_protection, 0, false, 1, 0, 1)
				break
			case "skill_reap":
				array_push(global.player_skills, "reap")
				audio_play_sound(snd_altar_might, 0, false, 1, 0, 1)
				break
			case "skill_pickpocket":
				array_push(global.player_skills, "pickpocket")
				break
			case "skill_trick":
				array_push(global.player_skills, "trick")
				audio_play_sound(snd_altar_innocence, 0, false, 1, 0, 1)
				break
			case "skill_crystalise":
				array_push(global.player_skills, "crystalise")
				audio_play_sound(snd_altar_mana, 0, false, 1, 0, 1)
				break
		}
	}
	instance_create_layer(683, 544, "Instances", obj_button_altar_continue)
}

function scr_altar_upgrades_define()
{
	reset_fighting()
	global.altar_encounters += 1
	if global.altar_encounters >= 4
	{
		array_sort(global.altar_last_upgrades, true)
		var current_upgrades_sorted = []
		array_copy(current_upgrades_sorted, 0, global.altar_last_upgrades, 0, array_length(global.altar_last_upgrades))
		while arrays_identical(current_upgrades_sorted, global.altar_last_upgrades)
		{
			global.altar_upgrades = []
			var possible_upgrades = ["V", "P", "S", "M", "MP", "I"]
			for (var i = 0; i <= 2; i++)
			{
				var upgrade = possible_upgrades[round(random_range(0, array_length(possible_upgrades) - 1))]
				array_delete(possible_upgrades, array_get_index(possible_upgrades, upgrade), 1)
				array_push(global.altar_upgrades, upgrade)
			}
			array_copy(current_upgrades_sorted, 0, global.altar_upgrades, 0, 3)
			array_sort(current_upgrades_sorted, true)
		}
	}
	else
	{
		switch global.altar_encounters
		{
			case 1:
				global.altar_upgrades = ["V", "P", "S"]
				break
			case 2:
				switch global.altar_choice
				{
					case "vitality":
						global.altar_upgrades = ["M", "P", "S"]
						break
					case "protection":
						global.altar_upgrades = ["V", "MP", "S"]
						break
					case "strength":
						global.altar_upgrades = ["V", "P", "M"]
						break
					case "none":
						global.altar_upgrades = ["V", "P", "S"]
						break
				}
				break
			case 3:
				global.altar_upgrades = ["MP", "M", "I"]
			
		}
	}
	array_copy(global.altar_last_upgrades, 0, global.altar_upgrades, 0, 3)
	global.altar_choice = "none"
	
	var has_vitality = false
	var has_strength = false
	var has_protection = false
	var has_magic_protection = false
	var has_might = false
	var has_innocence = false
	
	for (var i = 0; i < array_length(global.altar_upgrades); i++)
	{
		var data = global.altar_upgrades[i]
		switch data
		{
		case "V":
			data = obj_button_altar_vitality
			has_vitality = true
			break
		case "S":
			data = obj_button_altar_strength
			has_strength = true
			break
		case "P":
			data = obj_button_altar_protection
			has_protection = true
			break
		case "M":
			data = obj_button_altar_might
			has_might = true
			break
		case "MP":
			data = obj_button_altar_magic_protection
			has_magic_protection = true
			break
		case "I":
			data = obj_button_altar_innocence
			has_innocence = true
			break
		}
		instance_create_layer(268 + (i * 415), 128, "Instances", data)
	}
	
	
	var possible_dialogue = []
	
	if global.fear_encounters > 0 and has_innocence
	{
		array_push(possible_dialogue, "Altar Talk: Innocence Suggestion")
	}
	
	var confirmed_dialog = []
	for (var i = 0; i < array_length(possible_dialogue); i++)
	{
		var place_it = true
		var dialogue_line = possible_dialogue[i]
		if is_inside_array(dialogue_line, global.altar_told_dialog)
		{
			place_it = false
		}
		if place_it
		{
			array_push(confirmed_dialog, dialogue_line)
		}
	}
	
	if array_length(confirmed_dialog) > 0
	{
		var random_index = round(random_range(0, array_length(confirmed_dialog) - 1))
		array_push(global.altar_told_dialog, confirmed_dialog[random_index])
		dialogue_place(confirmed_dialog[random_index])
	}
}

function scr_altar_grand_upgrades_define()
{
	reset_fighting()
	var current_upgrades_sorted = []
	var possible_upgrades = ["split", "impenetrability", "parry", "reap", "pickpocket", "trick", "crystalise"]
	for (var i = 0; i <= 2; i++)
	{
		var upgrade = possible_upgrades[round(random_range(0, array_length(possible_upgrades) - 1))]
		array_delete(possible_upgrades, array_get_index(possible_upgrades, upgrade), 1)
		array_push(current_upgrades_sorted, upgrade)
	}
	
	for (var i = 0; i < array_length(current_upgrades_sorted); i++)
	{
		var data = "skill_" + current_upgrades_sorted[i]
		var button = instance_create_layer(268 + (i * 415), 128, "Instances", obj_button_altar_grand_skill)
		button.skill_to_gain = data
	}
}