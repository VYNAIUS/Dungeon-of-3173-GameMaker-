function scr_fight_choose_enemies()
{
	global.enemies_to_place = []
	var possible_enemies = []
	var possible_power_levels = []
	
	if global.fight_type == "none" or global.fight_type == "elite"
	{
		var team = global.spawnable_enemies_regular
		if global.area_id == 6 and not(global.fight_type == "elite") and not(global.heretic_reputation == 1)
		{
			if random(1) > 0.7
			{
				team = global.spawnable_enemies_heresy
			}
		}
		
		for (var i = 0; i < array_length(team); i++)
		{
			var	enemy_check = instance_create_depth(-1000, 0, 0, team[i])
			var power_level = enemy_check.power_level
			var area_spawn = enemy_check.can_be_spawned_at
			var enemy_id = enemy_check.id_name
			instance_destroy(enemy_check)
			if is_inside_array(global.area_id, area_spawn) or (enemy_id == "wrom_small" and is_inside_array(5, global.current_weathers))
			{
				array_push(possible_enemies, team[i])
				array_push(possible_power_levels, power_level)
			}
		}
	}
	else if global.fight_type == "boss"
	{
		for (var i = 0; i < array_length(global.spawnable_bosses); i++)
		{
			var	enemy_check = instance_create_depth(-1000, 0, 0, global.spawnable_bosses[i])
			var power_level = enemy_check.power_level
			var area_spawn = enemy_check.can_be_spawned_at
			instance_destroy(enemy_check)
			if is_inside_array(global.area_id, area_spawn)
			{
				array_push(possible_enemies, global.spawnable_bosses[i])
				array_push(possible_power_levels, power_level)
			}
		}
	}
	var current_power_level = global.player_power_level 
	if global.fight_type == "elite"
	{
		current_power_level *= 2.75
	}
	if global.game_time < 6
	{current_power_level += (6 - global.game_time) * 0.015}
	else if global.game_time >= 18
	{current_power_level += (global.game_time - 18) * 0.015}
	
	while array_length(possible_enemies) > 0
	{
		var random_index = irandom(array_length(possible_enemies) - 1)
		if current_power_level - possible_power_levels[random_index] >= 0
		{
			array_push(global.enemies_to_place, possible_enemies[random_index])
			current_power_level -= possible_power_levels[random_index]
		}
		else
		{
			array_delete(possible_power_levels, random_index, 1)
			array_delete(possible_enemies, random_index, 1)
		}
	}
	
	if global.fight_type == "shopkeeper_fight"
	{
		array_push(global.enemies_to_place, obj_fight_shopkeeper)
	}
	if global.fight_type == "herbalist_fight"
	{
		array_push(global.enemies_to_place, obj_fight_bush_herbalist)
	}
	if global.fight_type == "alchemist_fight"
	{
		array_push(global.enemies_to_place, obj_fight_alchemist)
	}
	if global.fight_type == "change_fight"
	{
		array_push(global.enemies_to_place, obj_fight_change)
	}
	if global.fight_type == "death_fight"
	{
		array_push(global.enemies_to_place, obj_fight_death_body)
	}
	if global.fight_type == "seeker_fight"
	{
		array_push(global.enemies_to_place, obj_fight_seeker)
	}
	if global.fight_type == "heretic_tutorial_fight"
	{
		array_push(global.enemies_to_place, obj_fight_heretic_tutorial)
	}
	if global.fight_type == "3173"
	{
		array_push(global.enemies_to_place, obj_fight_3173)
		if global.heretic_reputation == 1 or global.change_state == 2
		{
			array_push(global.enemies_to_place, obj_fight_cycle)
		}
	}
	
	if global.fight_type == "none" or global.fight_type == "boss"
	{
		if array_length(global.enemies_to_place) == 0 and global.fear_encounters >= 1
		{
			trigger("spawn fearspirit")
		}
	}
}

function scr_fight_choose_players()
{
	global.players_to_place = []
	array_push(global.players_to_place, obj_fight_player)
	if global.heretic_reputation == 1
	{
		array_push(global.players_to_place, obj_fight_heretic_brin_ally)
		if global.fight_type == "3173"
		{
			array_push(global.players_to_place, obj_fight_heretic_ally)
			array_push(global.players_to_place, obj_fight_shopkeeper_ally)
		}
	}
	else if global.change_state == 2
	{
		if global.fight_type == "3173"
		{
			array_push(global.players_to_place, obj_fight_change_ally)
			if global.death_state == 2
			{
				array_push(global.players_to_place, obj_fight_death_body_ally)
			}
		}
	}
}


function scr_use_consumable(item_id = "undefined")
{
	audio_play_sound(snd_item_use, 0, false, 1, 0, random_range(0.95, 1.05))
	if room == rom_fight
	{
		switch item_id
		{
			case "undefined":
				show_message("UNDEFINED ITEM! THIS IS A BUG, TELL THE DEVELOPER!!")
				break
			case "cookie":
				with obj_fight_player
				{
					var heal_amount = round(max_hp * 0.2)
					total_heal_amount += heal_amount
					var defense_increase = round(original_defense * 0.1)
					if defense_increase <= 0
					{
						defense_increase = 2
					}
					defense += defense_increase
					var funny_text = instance_create_depth(x, y, 0, obj_text_defincrease)
					funny_text.def_amount = defense_increase
					funny_text.ui_layer = 0
					funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_hploss)
					funny_text.dmg_amount = - heal_amount
					funny_text.text_color = #00FF00
					funny_text.ui_layer = 0
				}
				return true
			case "tea_winter":
				if global.current_temperature < 0
				{
					global.current_temperature += 5
					if global.current_temperature > 3
					{
						global.current_temperature = 3
					}
				}
				else
				{
					global.current_temperature += 1
				}
				with obj_fight_player
				{
					if stunned_type == "cold"
					{
						stunned -= 2
						if stunned < 0
						{
							stunned = 0
						}
					}
					if defense < 0
					{
						var defense_increase = abs(defense)
						defense = 0
						var funny_text = instance_create_depth(x, y, 0, obj_text_defincrease)
						funny_text.def_amount = defense_increase
						funny_text.ui_layer = 0
					}
					var heal_amount = round(max_hp * 0.1)
					total_heal_amount += heal_amount
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_hploss)
					funny_text.dmg_amount = - heal_amount
					funny_text.text_color = #00FF00
					funny_text.ui_layer = 0
					var damage_increase = 0.1
					with obj_fight_entity
					{
						if is_inside_array(id_name, ["snow_man", "snow_man_shotgun", "iceghost", "icewarrior", "yeti"])
						{
							damage_increase += 0.05
						}
					}
					damage_increase = round(original_dmg * damage_increase)
					dmg += damage_increase
					funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_dmgincrease)
					funny_text.dmg_amount = damage_increase
					funny_text.ui_layer = 0
				}
				return true
			case "potion_heal":
				with obj_fight_player
				{
					var actual_heal_amount = max_hp - hp
					total_heal_amount += actual_heal_amount
					var fake_heal_numb = "69"
					while real(fake_heal_numb) < actual_heal_amount
					{
						fake_heal_numb = fake_heal_numb + "69"
					}
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_hploss)
					funny_text.dmg_amount = - fake_heal_numb
					funny_text.text_color = #00FF00
					funny_text.ui_layer = 0
				}
				return true
			case "potion_stun":
				with obj_fight_entity
				{
					if is_enemy
					{
						stunned += 3
						if not(is_hidden)
						{
							var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
							funny_text.text = "Stunned"
							funny_text.text_color = #FFFF64
							funny_text.ui_layer = 0
						}
					}
				}
				return true
			case "potion_berserk":
				with obj_fight_player
				{
					var dmg_increase = round(original_dmg * 0.3)
					dmg += dmg_increase
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_dmgincrease)
					funny_text.dmg_amount = dmg_increase
					funny_text.ui_layer = 0
					var crt_increase = round(crit_chance * 150) / 100 - crit_chance
					crit_chance += crt_increase
					funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_crtincrease)
					funny_text.crt_amount = crt_increase
					funny_text.ui_layer = 0
				}
				if global.current_temperature < 0
				{
					global.current_temperature += 1
				}
				return true
			case "poison_flask":
				global.entity_choose_type = "poison_flask"
				return true
			case "potion_impenetrability":
				with obj_fight_player
				{
					max_impenetrability += 2
					impenetrability = obj_fight_player.max_impenetrability
					if imper_thing == undefined or not(instance_exists(imper_thing))
					{
						imper_thing = instance_create_layer(x, y, "Instances_FX", obj_fight_vf_impenetrability)
					}
					var funny_text = instance_create_layer(x, y, "Instances_UI", obj_text_custom)
					funny_text.text = "Now Impenetrable!"
					funny_text.text_color = #00FFFF
					funny_text.ui_layer = 0
				}
				return true
		}
	}
	else
	{
		switch item_id
		{
			case "undefined":
				show_message("UNDEFINED ITEM! THIS IS A BUG, TELL THE DEVELOPER!!")
				break
			case "poison_flask":
				global.player_poison += 1
				return true
			default:
				var random_index = round(random(2))
				if global.player_fear < 0.5
				{
					dialogue_place("3174: Cannot Use Item Map " + string(random_index))
				}
				else
				{
					dialogue_place("3174: Cannot Use Item Map Fear " + string(random_index))
				}
				break
		}
	}
	return false
}

function scr_use_passive(entity_id = obj_fight_entity, use_type = "fight_start", activator_entity = obj_fight_entity)
{
	if instance_exists(entity_id)
	{
		for (var i = 0; i < array_length(entity_id.items); i++)
		{
			for (var j = 0; j < array_length(entity_id.items[i].use_type); j++)
			{
				if entity_id.items[i].use_type[j] == use_type
				{
					entity_id.items[i].current_type = use_type
					if instance_exists(activator_entity)
					{
						entity_id.items[i].activator = activator_entity
					}
					else
					{
						entity_id.items[i].activator = noone
					}
					with entity_id.items[i]
					{
						event_user(0)
					}
					break
				}
			}
		}
	}
}

function scr_battle_spawn(entity = obj_fight_bush_man)
{
	var highest_enemy_number = -1
	var amount_of_spawned = 0
	var x_place = 0
	var enemy = instance_create_layer(-1000, 388, "Instances", entity)
	if enemy.is_enemy
	{
		with obj_fight_entity
		{
			if is_enemy and enemy != id
			{
				amount_of_spawned += 1
				if enemy_number > highest_enemy_number
				{
					highest_enemy_number = enemy_number
				}
			}
		}
		x_place = 860 + (440 / (amount_of_spawned + 2) * (amount_of_spawned + 1))
	}
	else
	{
		with obj_fight_entity
		{
			if not(is_enemy) and enemy != id
			{
				amount_of_spawned += 1
				if enemy_number > highest_enemy_number
				{
					highest_enemy_number = enemy_number
				}
			}
		}
		x_place = 130 + (440 / (amount_of_spawned + 2) * (amount_of_spawned + 1))
	}
	instance_destroy(enemy)
	enemy = instance_create_layer(x_place, 388, "Instances", entity)
	enemy.enemy_number = highest_enemy_number + 1
	enemy.coins = 0
	enemy.original_coins = 0
	enemy.xp = 0
	enemy.is_spawning = true
	return enemy
}

function scr_items_create()
{
	global.player_current_fight_items = []
	for (var i = 0; i < array_length(global.player_consumable_items); i++)
	{
		var item = undefined
		for (var j = 0; j < array_length(global.every_single_consumable_item); j++)
		{
			item = instance_create_depth(-64, -64, 0, global.every_single_consumable_item[j])
			if item.id_name == global.player_consumable_items[i]
			{
				break
			}
			else
			{
				instance_destroy(item)
			}
		}
		item.self_index = i
		array_push(global.player_current_fight_items, item.id)
	}
}

function scr_items_passive_create()
{
	global.player_current_fight_passive_items = []
	for (var i = 0; i < array_length(global.player_passive_items); i++)
	{
		var item = undefined
		for (var j = 0; j < array_length(global.every_single_passive_item); j++)
		{
			item = instance_create_depth(535, 672, 0, global.every_single_passive_item[j])
			if item.id_name == global.player_passive_items[i]
			{
				break
			}
			else
			{
				instance_destroy(item)
			}
		}
		item.self_index = i
		array_push(global.player_current_fight_passive_items, item.id)
	}
}


function scr_health_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var hp_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 2 + 1)
	if id_name == "player"
	{hp_multi = 1}
	return hp_multi
}
function scr_damage_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var dmg_multi = ((difficulty_multi - 40) / 150 + random(0.1) + 0.8) * (global.enemy_stat_multiplier / 2.1 + 1)
	if id_name == "player"
	{dmg_multi = 1}
	return dmg_multi
}
function scr_defense_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var def_multi = ((difficulty_multi - 40) / 300 + random(0.15) + 0.85) * (global.enemy_stat_multiplier / 2 + 1)
	if id_name == "player"
	{def_multi = 1}
	return def_multi
}
function scr_defense_addition(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var def_add = floor(difficulty_multi / 75 * (global.enemy_stat_multiplier / 2 + 0.75))
	if id_name == "player"
	{def_add = 0}
	return def_add
}
function scr_crt_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var crt_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 5 + 1)
	if id_name == "player"
	{crt_multi = 1}
	return crt_multi
}
function scr_spk_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var spk_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 2 + 1)
	if id_name == "player"
	{spk_multi = 1}
	return spk_multi
}
function scr_psn_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var psn_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 4 + 1)
	if id_name == "player"
	{psn_multi = 1}
	return psn_multi
}
function scr_reg_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var reg_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 6.75 + 1)
	if id_name == "player"
	{reg_multi = 1}
	return reg_multi
}
function scr_lfst_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var lfst_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 2.75 + 1)
	if id_name == "player"
	{lfst_multi = 1}
	return lfst_multi
}
function scr_imp_multi(id_name)
{
	var difficulty_multi = global.game_difficulty
	if string_pos("_ally", id_name) > 0
	{
		difficulty_multi = 40
	}
	var imp_multi = ((difficulty_multi - 40) / 75 + random(0.1) + 0.7) * (global.enemy_stat_multiplier / 3.75 + 1)
	if id_name == "player"
	{imp_multi = 1}
	return imp_multi
}