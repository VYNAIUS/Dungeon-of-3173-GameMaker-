function dialogue_place(dialogue_index)
{
	if instance_exists(obj_text_box)
	{return}
	
	var dialogue_box = instance_create_depth(683, 640, -1000, obj_text_box)
	dialogue_box.set_text_box(dialogue_index)
}

function reset_dialogue()
{
	global.alchemist_voices = [snd_alchemist_talk_0, snd_alchemist_talk_1, snd_alchemist_talk_2,
	snd_alchemist_talk_3]
	global.seeker_voices = [snd_seeker_talk_0, snd_seeker_talk_1, snd_seeker_talk_2]
	
	global.dialogues = {}
	
	global.dialogues[$ "Hello World"] = [
	[[snd_hp_decrease, 1.5, 3, #FFFFFF]], // these are speakers, each one is an array; they contain sound, pitch, speed delay and color
	["Hey. I'm not really a fan of you poking inside the files of this game.",
	"What if you get spoilered? You would ruin the fun for yourself.",
	"Isn't it more fun to explore and be clueless about the sheer scale of this world?",
	"And don't tell me you know everything about this game. I can confidently say you don't.",
	"Have you seen all of the areas? Have you seen all of the enemies? Have you beaten all 6 secret bosses?",
	"Need a hint for them? Alright: innocence, theft, source of crystals, lack of potions, hide and seek, split. One hint for each boss.",
	"Stop trying to explore the world through its code. Explore it through the lens of the main character.",
	"Otherwise, you will lose most of the fun."
	], // dialog text
	[0], // speakers for each line, if the array ends early, the last speaker will be used for the rest of the lines
	"none"] // trigger
	
	global.dialogues[$ "3174: Loss 0"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Don't blame yourself.", "It is a game for you, after all."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Loss 1"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Try experimenting with stuff?", "I don't know."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Loss 2"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Imagine if I could respond to their voices with my own.",
	"I would constantly talk for hours! That would be so fun!",
	"But that would make you impatient.\nAnd you would abandon me."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Loss 3"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Don't you feel like this world is shallow?",
	"As if it doesn't exist outside of your view?",
	"Why is everyone so hostile?\nAnd those who aren't, try to profit off of us.",
	"Why does the terrain always change? How is that logical?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Regular No Change Endings"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Amazing. You helped me finally defeat it.",
	"But that wasn't our final goal, was it?",
	"There is a certain God of mana, that we need to defeat.",
	"Cycle told me that he is in the Cave.",
	"So can you explore it more next time?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Change Desperation No PB"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Do you want to know what happens next?",
	"At least I do.", "There will be more, but not in this version.",
	"That's at least what I believe.",
	"...", "Remember how Cycle said that only Life and Death\ncan extract souls of Gods?",
	"What if we somehow get one of them to join us?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Change Desperation Yes PB No H"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Do you want to know what happens next?",
	"At least I do.", "There will be more, but not in this version.",
	"That's at least what I believe.",
	"...", "What if we become friends with the heretics?",
	"They said they need us to have consume powers.",
	"I think the Alchemist knows how to get it.",
	"He might share that secret if we don't anger him."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Change Desperation Yes PB Yes H No Change Consume"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Do you want to know what happens next?",
	"At least I do.", "There will be more, but not in this version.",
	"That's at least what I believe.",
	"...",
	"We can achieve Cycle's goal, instead of helping Change.",
	"We just need to have consume powers when cleansing him.",
	"I think the Alchemist knows how to get it.",
	"He might share that secret if we don't anger him."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Change Desperation Yes PB Yes H Yes Change Consume"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Do you want to know what happens next?",
	"At least I do.", "There will be more, but not in this version.",
	"That's at least what I believe.",
	"...", "Still diligently following my advice, while commanding\n my body.",
	"Have you defeated every foe yet?",
	"Herbalist, Shopkeeper, Alchemist, Seeker?",
	"What about my fear?", "I'm still suppressing his presence within me.",
	"But with low enough innocence he will awaken."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Partial Balance No CD"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["This might be one of the best outcomes.",
	"It is great that you haven't been heartbroken by similar one.",
	"But what if we didn't cooperate with Death?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Partial Balance Yes CD No H"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["This might be one of the best outcomes.",
	"...", "What if we become friends with the heretics?",
	"They said they need us to have consume powers.",
	"I think the Alchemist knows how to get it.",
	"He might share that secret if we don't anger him."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Partial Balance Yes CD Yes H"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["This might be one of the best outcomes.",
	"...", "Incredible.",
	"You will not abandon me, right?",
	"...", "Did you know that if our power level is too low,\nsomething interesting happens?",
	"Isn't that a very neat fact?", "...",
	"Please, don't abandon me.", "No. Who am I to tell you what to do?\nDo whatever you desire.",
	"More secrets might await you.", "But more importantly, have fun."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Stalemate No FV No GC"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["There is a better way to end this.",
	"We can prevent this stalemate with powers of consume.",
	"I think the Alchemist knows how to get it.",
	"He might share that secret if we don't anger him."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Stalemate Yes Change Consume"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["You did this out of curiosity, did you not?",
	"Perhaps to see what I would say.",
	"...", "Bestiary doesn't exist yet, but I will give you\na hint how to encouter an obscure foe.",
	"Long forgotten, but he is still in the back\nof my mind, suppressed to nothingness.",
	"He will reveal himself, when there is no one to fight us.",
	"When our power level is so low,\nthat nobody wants to challenge us."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Fake Victory No GC"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Did you see the screen after the fight?",
	"Might remained.", "It means God of might still exists.",
	"Her weakness is in a skill called Split.",
	"If we consume her, Cycle could achieve its victory."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Great Cycle No CD No PB"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["You did everything that Cycle has tasked us with.",
	"Congratulations.",
	"...", "What if we went in complete opposite direction?",
	"What if we try to befriend them instead of consuming?",
	"Change is waiting for help.",
	"But will accept it only from those, who have the ability\nto Crystalise."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Heresy No Change Assist"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["It feels so good to get my revenge on them.",
	"I will never forgive them for how they trained me.",
	"...", "Consume allows us to defeat Change.",
	"But we can go in a different direction.\nEntirely.",
	"Change is waiting for help. We can provide it.",
	"He only accepts help from those, who have the ability\nto Crystalise."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Heresy No M"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Finally, I got revenge on them.",
	"I will never forgive them for how they trained me.",
	"...", "Did you see the pink glyph on the screen after the fight?",
	"That's Pleasure, Midas, Greed. Whichever name you prefer.",
	"I wonder if we can help him.", "Maybe with the skill of Pickpocket?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Midas No Change Assist"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Amazing. You did it.",
	"Midas has acquired our help.",
	"We can help someone else.",
	"Change is waiting for help in his cave.",
	"But he only accepts help from those, who have the ability\nto Crystalise."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win Midas"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Amazing. You did it.",
	"Even if Midas was our ultimate goal,\nit doesn't mean there's nothing more to this world.",
	"You're not going to abandon me, right?",
	"...", "Did you know that if our power level is too low,\nsomething interesting happens?",
	"Isn't that a very neat fact?", "...",
	"Please, don't abandon me.", "No. Who am I to tell you what to do?\nDo whatever you desire.",
	"More secrets might await you.", "But more importantly, have fun."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win 0"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Great journey. I had fun.",
	"But what matters to you? The journey or the result?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win 1"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Don't you think it is unrealistic?",
	"Journey ending on a high note?",
	"Shouldn't it continue afterwards, up until my death?",
	"Isn't that how your journey works?",
	"Or maybe I die at that moment?"],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Win 2"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["My applause.", "You've done it again.", "Against all odds.",
	"Isn't that saying nonsensical?",
	"There was a chance for you to succeed, and you have achieved that.",
	"So at least one 'odd' was on your side."],
	[0],
	"main_menu_quit"]
	
	global.dialogues[$ "3174: Cannot Use Item Map 0"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Can't use it on the map.", "Try during a fight?"],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Cannot Use Item Map 1"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Not on the map.", "Maybe during a fight?"],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Cannot Use Item Map 2"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Probably only usable during a fight."],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Cannot Use Item Map Fear 0"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Oh, that. No, can't.", "Only during a fight."],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Cannot Use Item Map Fear 1"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["I'm struggling to suppress my fear,\nwhile you are taunting me with these items.",
	"They are usable only during a fight."],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Cannot Use Item Map Fear 2"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Stop, they are only usable during a...",
	"...", "a fight. Finally, I remembered it."],
	[0],
	"none"]
	
	global.dialogues[$ "3174: Extras"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["It is unfinished."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Story Start"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child, defeat enemies,\nconsume power, and acquire strength.",
	"And once you are strong enough,\ncome back here for the final test..."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Story Final Area"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child, I feel your presence.",
	"Prepare for your final fight.",
	"Your sibling is waiting for you..."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight: Regular 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["This is the culmination of your journey.",
	"Consume your sibling through combat.",
	"Once both of you are prepared, begin."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight: Regular 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child, take your time.",
	"If you need to prepare, do so.",
	"Your sibling knows that from the training\nyou had with it."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight: Change Lost 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["My child, why did you do this?",
	"Oooh yeaah. Hey there, buddy.\nI really appreciate you giving me the key to success.",
	"The key to success is my beautiful\nand definitely not annoying voice!",
	"Can you stop talking, please?", "I need to tell my child what to do.",
	"Go ahead, sib.", "This is the culmination of your journey.",
	"Remove the 'L' from culmination!\nHahah.", "Shut up, please.",
	"What? Come on, that one is pretty funny!",
	"My child, just start fighting when you are ready.",
	"Wow, I didn't know you promote family violence."],
	[0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight: Change Lost 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["My child, don't hurry.",
	"But please, don't take your time.",
	"So should it hurry or not?\nI'm a little confused on that.",
	"How do they deal with your\nconstantly contradicting sentences?",
	"Shut up, please."],
	[0, 0, 1, 1, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight: Midas 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_midas_talk, 1, 3, #FF007F]],
	["This is the culmination of your journey.",
	"Oh, enough zoning out for me."],
	[0, 1],
	"finale_midas_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Midas 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_midas_talk, 1, 3, #FF007F]],
	["Are you not going to appear?", "No, who are you?", "Does the glyph on my face fail to explain who I am?",
	"It looks familiar,\nbut I can't remember what it represents.",
	"Do I really have to give you a lesson in history?",
	"Yes, you do.", "Okay, I got all time in the world.",
	"A long time ago, one God could no longer sustain itself.\nExistence was its name.",
	"And so it splitted into 4 pairs of Gods.",
	"Life and Death, Protection and Exposure, Change and Cycle...",
	"and the most infamous duo: Suffering and Pleasure.",
	"Do I have to explain further?", "No.",
	"But why did you reveal that you are alive?",
	"My children have to consume you too.",
	"Well, I'm a business man. I'm here to make a deal with you.",
	"How about we work together?\nI've seen what kind of control you can establish.",
	"And I could use this control for stable economy.", "And what do I get in return?",
	"I will help you find a certain God of magic.",
	"...", "Sounds reasonable.", "I accept your offer, Pleasure.",
	"Thank you, Cycle.\nOh and by the way, can you call me 'Midas' instead?",
	"Why?", "It's more of a modern name.", "Understood.",
	"You can establish your territory\nanywhere outside of my gardens.",
	"Thank you. I will start doing so right away.", "Goodbye.", "Farewell."],
	[1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0],
	"midasgoaway"]
	
	global.dialogues[$ "Cycle Final Fight: End Regular"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Incredible, my child.",
	"You have completed this journey,\nand managed to defeat your greatest foe yet.",
	"It is time to embrace what you are made for.",
	"You are an everwarrior.", "You continue the Great Cycle.",
	"You are the 3174th one."],
	[0],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Caught Change"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Incredible, my child.",
	"You have completed this journey,\nand managed to defeat your greatest foe yet.",
	"Hold on. You have consumed Change?",
	"Incredible, truly incredible.",
	"My child, there is no point\nin continuing the Great Cycle.",
	"You have finished it.",
	"Thank you. And sorry.", "As this is your fate and your end."],
	[0],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Lost Change"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Incredible, my child.",
	"Wait, it was fighting?\nDid I miss the entire spectacle?",
	"Thankfully, yes.", "Oh come on!\nI wanted to do some funny things.",
	"Well, you have to deal\nwith me until you give up.",
	"...", "It is time to embrace what you are made for, my child.",
	"Hey, respond to me!",
	"You are an everwarrior.",
	"Stop ignoring me!",
	"You continue the Great Cycle.",
	"How? What?\nWhat are you even going to do in the future?",
	"You are the 3174th one.", "What? How do you keep track of that?"],
	[0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Caught Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Incredible, my child.",
	"You have completed this journey,\nand managed to defeat your greatest foe yet.",
	"Hold on. You have consumed Death?",
	"How did she escape our grasp?",
	"But having you consumed her back,\nwe can guarantee more success.",
	"Thank you, 3174th one."],
	[0],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Caught Change Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Incredible, my child.",
	"You have completed this journey,\nand managed to defeat your greatest foe yet.",
	"Hold on. You have consumed Change and Death?",
	"How did she escape our grasp?",
	"How did you manage to consume two Gods at once?",
	"My child, I am more than proud of you.",
	"The Great Cycle can finally end.",
	"And it ends with you.",
	"You will be remembered as the most powerful everwarrior."],
	[0],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Helped Change"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Finally. Finally! The Great Cycle is over!", "I did it! No. We did it!",
	"Thank you, everwarrior! Thank you!", "You wouldn't succeed without my child.",
	"What? You're still alive? Where are you?", "I no longer have my physical body.",
	"But I am still here.",
	"Alright, we will banish you in a moment.\nI just need to figure out where are all of the Gods.",
	"Gone.", "What? What do you mean?", "You two killed my child, who contained them inside of it.",
	"You killed them all too.", "There was no way for you to restore them in any case.",
	"The only two Gods\nwho could do that are Life and Death.", "But they were consumed.",
	"D-does that mean we were doomed from the start!?", "Yes.",
	"No-no-no-no. You're lying! You must be lying!",
	"I can fix everything, I can restore the old world!",
	"I can make it so everything will be back to normal!",
	"Why are you rejecting this reality?",
	"You are literal representation of all new and variety.",
	"Shut up! Shut shut shut!\nI will banish you myself, if you don't!",
	"Understood, enjoy your powers.", "Goodbye, my child.",
	"Okay. Okay! I will make a new world!\nI will show them! I will show them all! What I can do!",
	"And you, everwarrior, are going to be the judge\nof how good it is!"],
	[1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: End Helped Change Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_full_talk, 1, 3, #FF8000]],
	["Finally. Finally! The Great Cycle is over!",
	"We can finally restore the world.",
	"Death, can you extract the souls of Gods, please?",
	"Yes, of course.", "Let us finish this."],
	[1, 1, 1, 2, 2],
	"transition_balance"]
	
	global.dialogues[$ "Cycle Final Fight: Heretic 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["This is the... who is that?",
	"Is that a friend of yours?",
	"Incredible, truly.",
	"Um... everwarrior, are we going\nto fight that thing or no?",
	"And they can speak.\nI am beyond impressed, my child.",
	"In fact, I want to talk with them."],
	[0, 0, 0, 1, 0, 0],
	"finale_cycle_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Heretic 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Greetings.", "Oh, uh, um... hello.",
	"By my appearance, you probably assumed I am Cycle.\nAnd that assumption is correct.",
	"However, I can't figure out who you are.\nThe symbol on your uniform isn't familiar to me.",
	"So tell me. Who are you?\nAnd how did you become friends with my child?",
	"That's a long story, and I'm not\nthe only friend of your child.",
	"They are coming to help the everwarrior out.",
	"But in the mean time, why don't you\nguess whose symbol I bear on my clothes?",
	"How interesting.", "Well, the symbol isn't mine, nor Change's.",
	"Protection's is similar to mine,\nand I remember Exposure's pretty well.",
	"Death's looks like a face, and Life's is almost a circle.",
	"The only one left is Suffering's, but\nhis symbol represents eyes, and I see none on this one.",
	"I've ruled out all possible symbols.", "Tell me the answer, please.",
	"Oh look! Our friends!"],
	[0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1],
	"finale_heretics_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Heretic 2"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["Hey there.", "Hello.", "Time to tell you what the symbol is.",
	"It is heresy.\nAnd we've come to overthrow you and other Gods.",
	"That makes more sense.",
	"It is a great idea to befriend my child,\nto use against me, but there is one issue with your plan.",
	"You can't simply defeat God.", "However, don't surrender yet.\nI want to kill you all in a battle.",
	"Bring it on, Cycle."],
	[3, 2, 1, 1, 0, 0, 0, 0, 3],
	"boss_battle"]
	
	global.dialogues[$ "Cycle Final Fight: Change 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["This is the... who is approaching?\nIs that Change?"],
	[0],
	"finale_change_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Change 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Oooh, Cycle!\nCome out, come out, wherever you are!"],
	[1],
	"finale_cycle_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Change 2"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Oh, there you are.", "Why are you here, Change?", "Did you finally give up?",
	"Quite the opposite,\nI am going to end the Great Cycle.",
	"I have two of my children by my side,\nwhile you are all alone.",
	"Nope. This one is my ally.\nIsn't that right, buddy?",
	"...", "It can't speak.", "I know. How about instead of talking\nwe actually start some action?",
	"Impatient, are you not? Don't worry.\nI will not hold off any longer.",
	"And, my child, why did you betray us?\nLet this be your punishment."],
	[1, 0, 0, 1, 0, 1, 1, 0, 1, 0],
	"boss_battle"]
	
	global.dialogues[$ "Cycle Final Fight: Change 2 Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Oh, there you are.", "Why are you here, Change?", "Did you finally give up?",
	"Quite the opposite,\nI am going to end the Great Cycle.",
	"I have two of my children by my side,\nwhile you are all alone.",
	"Nope. This one is my ally.\nIsn't that right, buddy?",
	"...", "It can't speak.",
	"I know. But there is also another ally,\nwho told me that she would change everything.",
	"She isn't here for some reason...\nWhere is she?",
	"Why are you asking me? She's your ally, not mine.",
	"Oh look!"],
	[1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1],
	"finale_death_appear"]
	
	global.dialogues[$ "Cycle Final Fight: Change 3 Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_talk, 1, 4, #646464]],
	["Hello, Change.\nHello, Cycle.", "Who, what are you?",
	"Your children know me as Boat Person.\nIt is quite selfexplanatory why.",
	"Despite my appearance, I am not a life giver.\nI am something you both know, and are afraid of.",
	"Honestly, I have no idea what that could be.\nCan we just start fighting? My powers are itching.",
	"I am ready.", "Alright, let's see what you three can do."],
	[2, 0, 2, 2, 1, 2, 0],
	"boss_battle"]
	
	global.dialogues[$ "Cycle Final Fight: Start Regular"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Fight with honor and dignity, my children."],
	[0],
	"boss_battle"]
	
	global.dialogues[$ "Cycle Final Fight: 3173 Trick"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["Why are you not fighting?",
	"Continue combat, now."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["Your end is close.",
	"My child can do wonders, if it really desires to.",
	"It sure can."],
	[0, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 0 No Brin"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["Your end is close.",
	"My child can do wonders, if it really desires to."],
	[0, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["You can't defeat me.", "But we can defeat your child.",
	"...", "No."],
	[0, 2, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 1 No Shopkeeper"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["You can't defeat me.", "But we can defeat your child.",
	"...", "No."],
	[0, 3, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 1 No Shopkeeper & No Jalt"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["You can't defeat me.", "But we can defeat your child, silly.",
	"...", "No."],
	[0, 1, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Generic 1 No One"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_3174_talk, 1, 3, #F9F1A5]],
	["You can't defeat me, my child.", "...", "Attacking my sibling is the only way to win."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Split Cycle"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child, this doesn't work on me."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Reap Cycle"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child, I have no soul for you to reap.."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: 3173 Lost"] = [
	[[snd_cycle_talk, 1, 3,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_cycle_talk, 1, 5,	#00FFFF]],
	["No! My child!", "Not emotionally immune now, are you?", "...",
	"I will. Do something.", "What is it?", "..."],
	[0, 1, 0, 2, 1, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: 3173 Lost No Brin"] = [
	[[snd_cycle_talk, 1, 3,	#00FFFF], [snd_shopkeeper_talk, 1, 3, #72FF72],
	[snd_cycle_talk, 1, 5,	#00FFFF]],
	["No! My child!", "Surrender, please.",
	"...", "Finish me off.", "Really?", "Yes, but be quick."],
	[0, 1, 0, 2, 1, 2],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: 3173 Lost No Brin & No Shopkeeper"] = [
	[[snd_cycle_talk, 1, 3,	#00FFFF], [snd_heretic_talk_0, 1, 3, #00AA14],
	[snd_cycle_talk, 1, 5,	#00FFFF]],
	["No! My child!", "It's time to surrender, Cycle.",
	"...", "Finish me off.", "Really? That's it?", "Yes, there's nothing more."],
	[0, 1, 0, 2, 1, 2],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: 3173 Lost No One"] = [
	[[snd_cycle_talk, 1, 3,	#00FFFF], [snd_3174_talk, 1, 3, #F9F1A5],
	[snd_cycle_talk, 1, 5,	#00FFFF]],
	["No! My child!", "Why did you do that!?\nDid they really have that much effect on you?",
	"...", "I wish I could know why.", "But, it doesn't matter.\nFinish me off.",
	"...", "If I could speak, I would tell you.\nBut you didn't give me that ability.",
	"Let's do as it said:\nfinish it off."],
	[0, 0, 0, 2, 2, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Concern"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_heretic_talk_1, 1, 3, #2FA108],
	[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_0, 1, 3, #00AA14]],
	["Are you going to fight back or?", "...",
	"What's the point?", "I don't know, maybe follow your original plan!?",
	"Why do I have to explain that?", "It is near impossible now.",
	"Oh."],
	[1, 0, 0, 1, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Concern No One"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Why are you hesitating?\nThere is no other extra ending right at the end.",
	"Attack it now.\nElse I'm going to do it myself."],
	[0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Heretic: Concern No One Pissed"] = [
	[[snd_3174_talk, 1, 3, #F9F1A5]],
	["Fine, I can do it myself.",
	"I don't need you to finish the job."],
	[0],
	"player_lose_control"]
	
	global.dialogues[$ "Cycle Final Fight Change: Generic 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Your end is soon, Change.", "The Great Cycle will reign supreme.",
	"Can you talk any slower?\nI'm already falling asleep.",
	"Even in your speech you want everything to be quick.",
	"You never enjoy any single moment of existence,\ninstead you want constant acceleration.",
	"And you have been enjoying a single moment\nfor thousands of weeks with your Great Cycle.",
	"...", "Continue combat."],
	[0, 0, 1, 0, 0, 1, 0, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: Generic 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["You will never defeat us.", "A new era will begin after this fight.",
	"One thing I like more about everwarriors than you\nis the fact that they don't monologue for hours.",
	"...", "Shut. Shut up."],
	[0, 0, 1, 0, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: 3173 Lost"] = [
	[[snd_cycle_talk, 1, 3,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_cycle_talk, 1, 5,	#00FFFF]],
	["My child! No!", "Ha! You feel that? That's what they call\n'Change's awesomeness.'",
	"Now we just have to defeat you.", "...", "Go ahead.", "Oh I sure will."],
	[0, 1, 1, 0, 2, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: Concern"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["Hey, are you going to fight back?", "What's the point?",
	"To win, maybe?", "I won't.", "At least you admit it.\nI guess."],
	[1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: Split Change"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["You know that splitting doesn't work on me, right?",
	"I do, but my child didn't.", "How careless of you not to tell it about that."],
	[1, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: Split Cycle"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["My child, this doesn't work on me.", "That would be cool if it did.",
	"No, cool is my blood, when we will defeat you."],
	[0, 1, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change: Reap Cycle"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00]],
	["My child, I have no soul for you to reap.",
	"Oh, so that's why you are so soulless.",
	"You didn't have to say that.", "Sorry, I just couldn't resist.\nOh wait! Why am I apologizing? Heh."],
	[0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change & Death: Generic 0"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_talk, 1, 4, #646464]],
	["Your end is soon, Change.", "The Great Cycle will reign supreme.",
	"Can you talk any slower?\nI'm already falling asleep.",
	"Even in your speech you want everything to be quick.",
	"You never enjoy any single moment of existence,\ninstead you want constant acceleration.",
	"Do you two always bicker like this?", "No.", "Yes.",
	"He can't help but always find\na reason to argue with me.",
	"I mean, we are literal opposite Gods,\nhow are we supposed not to argue?",
	"Well, Life and I- I mean, I heard that Life and Death\nwere on quite decent terms with each other.",
	"And Innocence murdered Pleasure.\nOne example doesn't define the rules.",
	"Do not mention that.", "Let us continue combat."],
	[0, 0, 1, 0, 0, 2, 1, 0, 0, 1, 2, 0, 2, 2],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change & Death: Generic 1"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_talk, 1, 4, #646464]],
	["You will never defeat us.", "A new era will begin after this fight.",
	"One thing I like more about everwarriors than you\nis the fact that they don't monologue for hours.",
	"The joke is on point.", "...", "Shut. Shut up, you two."],
	[0, 0, 1, 2, 0, 0],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change & Death: 3173 Lost"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_full_talk, 1, 3, #FF8000]],
	["That was bound to happen.", "Perhaps it is really the end for me.",
	"As if anyone was doubting that, right, Death?",
	"Absolutely.", "I will extract the souls of other Gods in a minute.",
	"But for now, let us obliterate our tormenter.",
	"My legacy will live forever.\nYou won't be able to erase history.",
	"Yeah, everyone will remember you with disgust.",
	"...", "Finish me off.", "More than glad to do so."],
	[0, 0, 1, 2, 2, 2, 0, 1, 0, 0, 2],
	"none"]
	
	global.dialogues[$ "Cycle Final Fight Change & Death: Split Death"] = [
	[[snd_cycle_talk, 1, 5,	#00FFFF], [snd_change_full_talk, 1, 2, #FFFF00],
	[snd_death_full_talk, 1, 3, #FF8000]],
	["What? Death?", "Oh, um... I...",
	"Death? You were here the entire time!?\nWhy didn't you tell me you were Death!?",
	"We don't even need an everwarrior to succeed\nif you let yourself use your full potential!",
	"You... You are right! I do not need to hide myself anymore.\nI am all powerul and mighty God!",
	"But one of my children has consumed you.\nHow are you still here?",
	"I do not need my physical body to exist.\nNow, let us end this madness.",
	"Oh no."],
	[0, 2, 1, 1, 2, 0, 2, 0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Knows Map"] = [
	[[snd_shopkeeper_talk, 0.9, 3, #72FF72]],
	["You. Come here.\nI have something to say."],
	[0],
	"transition_shopkeeper"]
	
	global.dialogues[$ "Shopkeeper Greet First Time"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Oh. Customer!", "Welcome. Take a look at these items."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Leave Tutorial"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72]],
	["By the way.", "No need to enter if you are just passing by."],
	[0],
	"transition_map"]
	
	global.dialogues[$ "Shopkeeper Poor"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72]],
	["Stealing?", "I don't allow that. Pay full price."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Poor Brin"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Hey, what are you doing?", "We can't just steal!\nWhat if he notices it?"],
	[1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet 1"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Customer!", "Welcome. Welcome back."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet 2"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Ah. Customer.", "Welcome back."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Intro Brin"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome, customer.",
	"Oh, there's another one here.",
	"You look familiar, heretic.",
	"How do you know that?\nIs that common knowledge?",
	"Not at all.", "Brin, right?", "Oh, were you a heretic?",
	"Yes.", "Is the plan in motion?", "Yeah, this is our only chance.",
	"I see. Have a discount.", "Really?", "I will help you out.",
	"Oh, umm... the everwarrior seems impatient.",
	"Let's cut the talk.", "Yeah."],
	[0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet Brin 0"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome, customers.", "Hey."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet Brin 1"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Ah, you two.\nWelcome.", "Hey, there."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet Sleepy 1"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Customer...", "Welcome..."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Greet Sleepy 2"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["...", "Welcome. To my... Sleep."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Notice Sleep"] = [
	[[snd_shopkeeper_talk, 0.9, 3, #72FF72]],
	["...", "I see.", "Pay. Now.", "...", "Greed? Too bad."],
	[0],
	"shopkeeper_battle"]
	
	global.dialogues[$ "Shopkeeper Notice"] = [
	[[snd_shopkeeper_talk, 0.9, 3, #72FF72]],
	["You. I know it's you.", "Thief.", "Pay. Now."],
	[0],
	"shopkeeper_pay_debt_prompt"]
	
	global.dialogues[$ "Shopkeeper Glad"] = [
	[[snd_shopkeeper_talk, 0.97, 3, #72FF72]],
	["I appreciate your honesty.", "...", "Take a look at these items."],
	[0],
	"shopkeeper_reset_sus"]
	
	global.dialogues[$ "Shopkeeper Begin Fight Greed"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72]],
	["...", "Greedy?", "The hard way, then."],
	[0],
	"shopkeeper_battle"]
	
	global.dialogues[$ "Shopkeeper Begin Fight Poor"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72]],
	["...", "Poor?", "Your trinkets will serve value."],
	[0],
	"shopkeeper_battle"]
	
	global.dialogues[$ "Shopkeeper Fight 50% HP"] = [
	[[snd_shopkeeper_talk, 0.95, 3, #72FF72]],
	["I underestimated your kind. Perhaps."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Fight 90% HP"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["The thrill of combat.", "Strength unites us all.", "Continue your struggle. Thief."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Fight Clone"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Who is that?", "Is that me?", "What have you done? Is it power of mana?",
	"No, it is Life's power.", "Are you sure?", "Yes. It is called 'split'.",
	"How do you remember that, but I don't?", "I felt more alive. And assumed it is Life's power.",
	"Understood."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Death Greet 0"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Customer. Hello.", "My head aches.", "Someone robbed and beat me.",
	"Can you find them? They have my goods."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Introduction"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Me? I'm Shopkeeper. That's my nickname.", "I sell items. Your kind buys them.",
	"I deposit money. I get more items.", "That's it."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: No Dialog 0"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["...", "I have nothing more to say.", "I like listening. Not talking."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: No Dialog 1"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["What?", "I have nothing more to say."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: No Dialog Brin 0"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["...", "...", "What does it want?", "I don't know.", "I have nothing more to say."],
	[0, 1, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Poison Flask Ad"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["See that poison flask? Useful.", "It looks weak. But combine multiple and see the result."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Sleep"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["...", "Sell... Warrior... Buy... Cult...", "..."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Empty Shop"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["You bought everything.", "Don't worry. I will get more tomorrow."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Alchemist"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["There is an insane man.", "He has high prices. And gets angry if you don't buy.",
	"Be careful."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Boat Person"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Disgusting thing was here one time.", "She asked for boats. I didn't trust her.",
	"She is a God fanatic. Disgusting.", "Beware."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Rain"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["I hate rain.", "It's made by no God, but still manages to annoy."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Fog"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["The fog has come.", "I wonder how it comes to be.",
	"Does Cycle create it?", "If not, who creates it?"],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Blizzard"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["My bones freeze.", "Winter tea saves me here."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Canyon"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Deathly Canyon.", "Only gargoyles inhabited it.",
	"Now spiders infest here.",
	"Antidote is helpful here."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Sandstorm"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["It's hard to see. At least now.",
	"But residents can. They adapted.",
	"Beware."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Orphan"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["Sometimes, I envy others. That have God.",
	"Being an orphan is hard.\nNo God to help. No respect from others.",
	"That's why some orphans unite.\nUnite to fight back.",
	"You won't get it. You have powers.\nFrom your God. Your parent.",
	"My parents were heretics. And probably still are.",
	"They wanted me to be one too.\nBut it was too hard.",
	"I'm still struggling.\nAnd business doesn't help much.",
	"Sorry. Do you want to buy? Anything?"],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Infinite Mode"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72]],
	["When will this end?", "Is this eternal?", "I don't like infinity."],
	[0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Boat Person Brin"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Amalgam of four life givers was here.", "She wanted boats.\nBut she is a God fanatic.",
	"Oh, I know her. We call her Boat Person.\nFor obvious reasons.",
	"She doesn't seem to be an actual life giver, though."],
	[0, 0, 1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Prophet Brin"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Have you heard what the prophet has said?", "Which one? The Heresy Prophet?",
	"Yeah, her.", "No. Tell me.", "After 3173rd one\'persistence' will be stronger than ever.",
	"What's 'persistence'?",
	"I don't know. But why care about it?\nHeresy Prophet is insane. Isn't she?",
	"Yeah. That's part of the reason we exiled her.\nThe other part is that she attacked us.",
	"Is she alive?", "We are yet to hear from her."],
	[1, 0, 1, 0, 1, 0, 1, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Life Brin"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["How's life going?", "Not great.\nThings don't get easier.",
	"Why? Aren't you staying out of troubles and battles?",
	"Sometimes I have to punish thieves.", "Moving my shop is also hard.",
	"Why move it?", "To have more customers.\nEverwarriors are most common ones.",
	"I see. I'm sorry.", "It will get better after the plan.", "If we succeed that is."],
	[1, 0, 1, 0, 0, 1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Shopkeeper Talk: Infinite Mode Brin"] = [
	[[snd_shopkeeper_talk, 1, 3, #72FF72], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Is this eternal?", "It seems to be so.", "Why help everwarrior then?",
	"Maybe it will end at some point.", "I see."],
	[0, 1, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Hello, another one.", "I am no threat to you.\nQuite the opposite.",
	"I can provide a boat.\nIt will let you traverse water safely.",
	"But the boat is fragile.\nAfter a while it will break.", "So will you take it?"],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Heretic Never"] = [
	[[snd_death_talk, 1, 4, #646464], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Incredible, truly incredible.", "Oh, the boat person.\nHello.",
	"Do not speak to me, disgusting piece of flesh.",
	"Huh? What have I ever done to you?",
	"I was yet to see you at all,\nand you managed to take the path of a heretic.",
	"I will not provide any of my services.",
	"Bye."],
	[0, 1, 0, 1, 0],
	"death_crawl_away"]
	
	global.dialogues[$ "Boat Person Intro Heretic"] = [
	[[snd_death_talk, 0.9, 4, #646464], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["I see how it is.", "Oh, the boat person.\nHello.",
	"Do not speak to me, disgusting piece of flesh.",
	"Huh? What have I ever done to you?",
	"Everwarrior, my services are no more.",
	"Your path of heresy will bring you nowhere.",
	"Not even Death would accept you.", "Bye."],
	[0, 1, 0, 1, 0],
	"death_crawl_away"]
	
	global.dialogues[$ "Boat Person Accept"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Great choice. Use the boat wisely.", "It is not safe for either of us to stay in the same place.",
	"Meet me later."],
	[0],
	"death_crawl_away"]
	
	global.dialogues[$ "Boat Person Deny"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Interesting.", "Your cockiness may be the death of yours.",
	"In either case, I need to find a safer place.", "We will meet again."],
	[0],
	"death_crawl_away"]
	
	global.dialogues[$ "Boat Person Money Explanation"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["We meet again.", "Acquiring boats has become harder for me.",
	"Which is why, I will charge you money."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Payment Surprise"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You are actually paying?", "...", "Use your boat wisely."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Poor"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You are actually paying?", "...", "That is not enough. Perhaps, no boat this time."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Tip"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["I do not accept extra payment.\nYou have already paid for your boat."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Split Warning"] = [
	[[snd_death_talk, 0.9, 4, #646464]],
	["Do not do that.",
	"If you try this action again,\nI will fight back.",
	"And it is a fate worse than death."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: No Dialog"] = [
	[[snd_death_talk, 0.95, 4, #646464]],
	["Stop asking me about myself.", "Your creator must not know anything about me."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Shopkeeper"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Have you seen the orphan selling goods?", "His eyes are easily closed by the darkness of the night.",
	"While he is sleeping, you may sneak in and steal.\nJust do not be cocky with it."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Infinite Mode"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Are we repeating the route?", "Has the Great Cycle changed?",
	"Ironic that the God of repetition has gotten tired of\nrepeating the same cycle for ages.",
	"It feels infinite. Too infinite.\nEven for your parent."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Everwarrior"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["At times, I feel pity for your kind.",
	"I cannot imagine what it is like to be\ncreated with a single purpose.",
	"Everwarriors, like you, have extreme survivability.\nA strong human is less powerful than the weakest of your kind."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Reap"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Do you practice your reaping?",
	"If so, then here is a tip:\ntry to build up your might during the battle.",
	"It becomes much more effective with it.",
	"I hope my advice will aid you."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Alchemist"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["I have seen the Alchemist.", "He is one of the only people,\nwho fills me with hope.",
	"His body alterations and attitude towards money\nremind me of Pleasure.",
	"As if he is coming back.\nWhat a wonderful feeling.",
	"I would finally be able to apologise for...",
	"I have forgotten again that I am speaking to an everwarrior.",
	"I do not think you would be able\nto piece it together. But please, do not think about it.",
	"Can you erase it from your memory?\nIs that not an ability you have?"],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Cave"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Crystals grow everywhere in this cave.", "They contain incredible amount of mana.",
	"I heard your kind is able cleanse mana.\nIf that is the case, you may use that to destroy crystals.",
	"However, it is only a hypothesis that I have created right now."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Tundra"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["It is quite cold here.", "If you freeze, you should consume something warm.",
	"I do not believe that you are created\nto withstand such temperature. Especially during blizzards.",
	"Exposure made sure only strong ones survive in her land."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Canyon"] = [
	[[snd_death_talk, 0.95, 4, #646464]],
	["I will not elaborate on my feelings\ntowards this canyon.",
	"Do not even think about it."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Rotten Life"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["This place used to bloom with Life.",
	"It was known as the Holy Forest.",
	"Those who wished to gain eternal life lived here.",
	"Wonderful times, but it didn't last forever.",
	"When Life was consumed by one of your kind,\neverything has changed.",
	"Those who were tired of their eternity\ncould not ask to revoke it.",
	"And so they started to rot,\nno longer trying to sustain their bodies.",
	"...",
	"I still miss him.\nHe used to compliment my existence with his own.",
	"Excuse me, I did not mean to feel sorrow."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Life Giver"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Those who have a body similar\nto mine are a threat.",
	"To you, at least. To me they are neutral.",
	"They are afraid of my body, which is fair.\nThis is not my original one.",
	"And I might have borrowed some of the components for it.\nOf those who were willing to stop their eternity, of course."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Change Plan"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Do not worry, I will not immediately reap\nyour soul out of your body.",
	"But I will deal significant damage.",
	"Do not forget:\nwe are going to fight in the Deathly Canyon.",
	"If I do not see you there,\nI will tell him that you have failed.",
	"Remember that."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Talk: Stare"] = [
	[[snd_death_talk, 0.95, 4, #646464]],
	["Everwarrior. Can you at least look at me?",
	"Why do you always stare in that direction?"],
	[0],
	"player_stare"]
	
	global.dialogues[$ "Boat Person Intro Garden"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["So, this is the Eternal Garden.", "...",
	"Your creator seems to take great care of it.\nIt is quite neat.",
	"I do not think you need a boat here.\nBut if you really desire it, then I will not stop you."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Canyon"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Do you feel it?", "Is this called 'pride'?", "Nice feeling.",
	"In either case, do you really need a boat here?"],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Rotten"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["This place is not what it used to be.",
	"Water is filled with pure hatred.",
	"That is why you should have a boat.",
	"I will charge you less here."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Missed Fight"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You have avoided me in the Deathly Canyon.",
	"I have told him that you have failed to reach me.",
	"He did not believe me and\ndecided to abandon my help.",
	"Perhaps you two will achieve victory by yourselves.",
	"I will not assist you.", "...", "Do you require a boat?",
	"I will charge you less here."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Generic 0"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["We meet again.", "Do you require a boat?"],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Intro Change"] = [
	[[snd_death_talk, 1, 4, #646464], [snd_change_talk, 1, 2, #007FFF]],
	["And then I have to go left, right?", //ch
	"That is correct.", //d
	"Gods spare me, can you talk any slower?", //ch
	"Oh, everwarrior! Hello again.\nI'm just confirming the route.", //ch
	"Are you friends with an everwarrior?\nI assumed their kind is the one to bring an end to you.", //d
	"Weeellll, I jus- Wait, how do you know who I am?", //ch
	"Oh, I spoke too much.", //d
	"It is obvious by your appearance,\nthat you are one of Gods.", //d
	"Why are you friends with an everwarrior?", // d
	"We are going to help each other.\nAnd we might end the Great Cycle.", //ch
	"What if the everwarrior is not powerful enough?", //d
	"Uhhh... That's actually a good concern.", //ch
	"Did you trust it for no apparent reason?", //d
	"Hey! Don't judge me. Give me some credit.\nI managed to survive the longest out of all of Gods.", //ch
	"You will be surprised by a revelation later.", //d
	"However, I would like to propose an idea:\nI will examine the power of the everwarrior in a battle with me.", //d
	"If it is able to defeat me, it is strong enough.", //d
	"If not, I will become stronger.", //d
	"Sounds shady, but I guess it's better\nthan risking the rest of God balance.", //ch
	"Alright, I will wait in Eternal Garden.\nTell me if it succeeds.", //ch
	"Yes, I will battle it in the Deathly Canyon\nand notify you immediately.", //d
	"Alright, bye everyone.", //ch
	"Farewell."],
	[1, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0],
	"changegoaway"]
	
	global.dialogues[$ "Boat Person Fight"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You arrive.",
	"I do not have enough time\nto wait for your preparation.",
	"So I hope you are ready for our combat.",
	"Let us begin."],
	[0],
	"death_battle"]
	
	global.dialogues[$ "Boat Person Fight Split"] = [
	[[snd_death_talk, 0.9, 4, #646464]],
	["You desire to defeat me.",
	"In that case, your soul will ripped out of your body\nand consumed by me.",
	"I will not hold back."],
	[0],
	"death_battle"]
	
	global.dialogues[$ "Boat Person Battle: Tutorial 0"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Your goal is not to defeat me.",
	"It is to survive for long enough."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Battle: Tutorial 1"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You need reliable healing capabilities.",
	"Otherwise, you will not survive in a long battle."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Battle: HP Too Low"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["That is incredible strength.",
	"I will protect myself from your incoming attacks."],
	[0],
	"none"]
	
	global.dialogues[$ "Boat Person Battle: Trick"] = [
	[[snd_death_talk, 0.95, 4, #646464], [snd_death_talk, 0.9, 3, #646464]],
	["Are you trying to trick me?",
	"I would put into question how you manage to fight me at all,\nbut I will not tolerate you.",
	"I will obliterate your soul, disgusting piece of flesh.",
	"To shun your own power to appear weak is\nworse than to be a heretic!"],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Boat Person Battle: Tutorial Almost"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["Survive a few more blows.",
	"However, these attacks are far more dangerous."],
	[0],
	"none"]
	
	global.dialogues[$ "Death Battle: Split 0"] = [
	[[snd_death_full_talk, 1, 3, #FF8000]],
	["Is this what you desired to see?",
	"In either case, prepare to lose your soul."],
	[0],
	"none"]
	
	global.dialogues[$ "Death Battle: Split 1"] = [
	[[snd_death_full_talk, 1, 3, #FF8000]],
	["What is it that you want from me?",
	"Do you desire to satiate your curiosity?"],
	[0],
	"none"]
	
	global.dialogues[$ "Death Battle: Back 0"] = [
	[[snd_death_full_talk, 1, 3, #FF8000], [snd_death_talk, 1, 4, #646464]],
	["Excuse me, let me use the shell again.",
	"I can hide forever from your reach."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Death Battle: Back 1"] = [
	[[snd_death_full_talk, 1, 3, #FF8000], [snd_death_talk, 1, 4, #646464]],
	["Stop.", "You are not going to simply defeat God."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Death Battle: End No Consume"] = [
	[[snd_death_full_talk, 1, 3, #FF8000]],
	["Enough.", "Do you desire exposition?\nI can provide some.",
	"I am Death, yes.\nAnd I was not consumed by any of your kind.",
	"When one everwarrior had attempted to do so,\nI escaped my original body.",
	"I do not require one to exist.\nI can change them very easily.",
	"I fled to the Holy Forest, and took a few bodies of those,\nwho were willing to give up their lives.",
	"That is how I managed to attain the shell, you just destroyed.",
	"What will I do now?", "I will most likely search for a new shell.",
	"A more human one, perhaps."],
	[0],
	"end_battle"]
	
	global.dialogues[$ "Death Battle: End Consume"] = [
	[[snd_death_full_talk, 1, 3, #FF8000]],
	["I will not succumb. I will escape you.",
	"No. I will not.", "You are my new shell.",
	"I only have to figure out how to control\nalive beings like you.",
	"Your journey has become so much harder.",
	"You will not succeed."],
	[0],
	"end_battle"]
	
	global.dialogues[$ "Death Battle: End Consume & Change"] = [
	[[snd_death_full_talk, 1, 3, #FF8000], [snd_change_full_talk, 1, 2, #FFFF00]],
	["I will not succumb. I will escape you.",
	"That's what I also thought.",
	"Change?! Is that you?",
	"Yup. I also got consumed.",
	"I tried to help you.\nI stunned it, damaged it, summoned crystals.",
	"But it persisted. I guess it is really over now.",
	"No. It is not over.", "I only have to figure out\nhow to control an alive body.",
	"Or I can help you defeat it from the inside.",
	"How about we do both of those things?", "Sounds great."],
	[0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0],
	"end_battle"]
	
	global.dialogues[$ "Boat Person Battle: Tutorial Done"] = [
	[[snd_death_talk, 1, 4, #646464]],
	["You have proven to possess incredible survivability.",
	"My brother would be proud of you.",
	"...",
	"It is good to know that we are to free him and others.",
	"I will notify your new friend\nthat you have passed the test.",
	"When you reach your final destination,\nI will assist you two.",
	"I hope we succeed together.", "Farewell."],
	[0],
	"end_battle"]
	
	global.dialogues[$ "Golden Mimic Intro"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Hey pal!", "It's rude to open a mimic's mouth without permission.",
	"But don't worry, pal! I'll forgive you,\nif you play a game with me.",
	"I'll present you a gift, and if you don't like it,\nyou can pay me to get a different one!"],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Intro Generic"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Welcome back, pal!"],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Intro Generic Brin"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome back, pals!", "Hey."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Golden Mimic Stop"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Pal! Who am I giving this gift to?", "...",
	"That's you. I ain't letting you leave until you get it."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Can't Talk 0"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Man, it's hard for me to talk\nwhile I have items in upper jaw.",
	"Can we chat after you take the item?"],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Can't Talk 1"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Pal, I can't talk with food in my mouth.",
	"Take the item, and I'll chat with you."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Poor 0"] = [
	[[snd_gmimic_talk_1, 0.97, 3, #B2B235]],
	["Pal, that's not enough money.",
	"I can tell how many coins you have with my eyes closed.\nIf I had any eyes to begin with...",
	"Anyway, you're poor, pal."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Poor 1"] = [
	[[snd_gmimic_talk_1, 0.97, 3, #B2B235]],
	["Play by the rules, pal.",
	"I won't give you a discount just because you're poor."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Tired"] = [
	[[snd_gmimic_talk_1, 0.97, 3, #B2B235]],
	["Pal, just how much money do you have?!",
	"I'm so tired of eating coins for now,\nand you are a neverending supply of them.",
	"Can you feed me some in the next area?"],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: No Dialog 0"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Pal... I've ran out of my extremely insightful dialog.",
	"I think we should chat some time later."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: No Dialog 1"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Nothing more to say, pal.", "We should chat later."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Shopkeeper"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Pal, have you seen that shopkeeper guy?",
	"He lost so much money on me, trying to get Midas power,\nthat he now hates me.",
	"Poor guy."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Too Much Water"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Pal, it's quite wet here.", "Are you sure you're not drowning?"],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Pickpocket"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["What's that skill you have, pal?", "Master of being a thief, yeah?",
	"Don't worry, it's quite natural for Midas' followers\nto be proficient in stealing.",
	"Wait, are you even trying to worship Midas?",
	"I think we might be able to bring Midas back.\nDespite what the tale says, I don't think he is fully dead.",
	"Something of his still remains in the world.",
	"But who am I to know that, right?\nBut there is an insane man that might.",
	"I feel as if you already know him."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Midas"] = [
	[[snd_gmimic_talk_1, 0.97, 3, #B2B235]],
	["Pal, do you wanna know about this Midas guy?",
	"He was the God of greed, and\nwas the one to build economy and trades.",
	"Pretty good stuff, right?", "Well, his brother, Innocence, hated him.",
	"He manipulated Death into taking lives of all Midas' followers.",
	"And then, guess what, Innocence murdered him himself.", "Dark stuff, pal."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Infinite Mode"] = [
	[[snd_gmimic_talk_1, 0.95, 3, #B2B235]],
	["Pal, I can feel it.", "Infinite mode? What is that?\nAs if it was finite before.",
	"How do I know? Well, Cycle's reign feels\nmore and less opressing, at the same time.",
	"Perhaps, Midas' power let me feel that."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Cave Heading"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["You're heading to the Ever.. I mean, Stale Cave over there, right?\nWhat a dumb name.",
	"Just sayin', I'm not going to be there.", "That place is quite wicked and weird.",
	"But don't worry, I'll be in the Barren Tundra."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Tundra"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["So how did it go in the Everchaning Cave?\nOops, excuse me. I meant 'Stale Cave.'",
	"Since you are alive, I assume it went well.", "But pal, don't let your guard down yet.",
	"You probably already noticed that it's quite chilly here.\nIn terms of weather, of course.",
	"If you freeze, go ask Shopkeeper for some tea.",
	"Other than that, residents of this land might beat your.. kill you.\nYeah."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Canyon"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["Not really a fan of getting sucked here.\nI'm talking about my soul.",
	"Those gargoyles have no sympathy nor empathy.",
	"My poor cousin tried er.. convincing one of them\nto join its side. It didn't go well."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Desert"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235]],
	["I hate it here, pal. Have you seen\nthe amount of coins bad guys drop here?",
	"It's less than pathetic! But it makes sense.",
	"These followers hate Midas,\nand the concept of economy in its entirety.",
	"I think my cousin will provide\nmost of the coins here for you."],
	[0],
	"none"]
	
	global.dialogues[$ "Golden Mimic Talk: Heretic"] = [
	[[snd_gmimic_talk_1, 1, 3, #B2B235], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["I think I've made a couple deals with you, pal.",
	"You did. They really did help me.",
	"Oh I'm glad to hear that, buddy.",
	"Anyway, have you met my cousin?",
	"That steel chest? Ew, don't even remind me of it.",
	"What? Did it go that bad?", "Worse than you can imagine.\nI don't want to talk about that.",
	"When or if we come across it,\nI will pretend to not exist.",
	"Yeah, it is bad at understanding\nhow many people there are around it.",
	"Just don't walk too loudly.", "Yeah."],
	[0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1],
	"none"]
	
	global.dialogues[$ "Fear Desert"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["I finally feel at home."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Fight"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Nobody.", "I mean, who would want to\nfight such an innocent creature like you?",
	"But who would reward you for your innocence?\nFor your fear?",
	"Exactly, nobody, except me.", "Allow me to entertain you."],
	[0],
	"spawn fearspirit"]
	
	global.dialogues[$ "Fear Talk: Friends"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Here is a friend to keep you company.", "Don't worry, it is as mute as you are."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Cloned"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["You're quite eager to make friends.", "Even if it means to create them out of thin air."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Sympathy"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["What? You don't want to fight?", "You are so adorable.\nHow could anyone raise their weapon against you?"],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Generic 0"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["You know, I would like to thank you.", "You've suppressed me for so long. Far too long.",
	"But now, I can entertain you again.", "Forever."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Shopkeeper"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Remember that shopkeeper?", "His eyes are chilling.\nHave you noticed how he glares at you?",
	"He is some kind of predator, isn't he?", "He wants us dead."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Golden Mimic"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["That golden chest is terrifying.", "Its sharp teeth could easily snap us in half.",
	"Do you think it is luring us with those gifts?"],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Boat Person"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Cycle didn't tell you what creature the boat person is.", 
	"Does it even know that such thing exists?",
	"Tentacles intertwined to create a body.", "She must be from the land of eternal life."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Steel Mimic"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["The steel chest must be a master in manipulation.", 
	"It lures us with the promise of money,\nbut one time it will bite off our arm, as we try to put money inside.",
	"It can't wait to savor our flesh.\nI know it, you know it."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Seeker"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Why did Seeker attack you too?",
	"I thought it would feel my presence\nwithin your body.",
	"Perhaps you suppress me that well,\nthat no one can see the truth.",
	"But if Seeker was that weak, I can accept its fate.",
	"Even if it is my child."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Change Not Killed"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Wasn't that Change?", "Are you sure we can't do anything about him?",
	"If not consume, then maybe cleanse him at least?",
	"Of course, if you think that he will easily kill us,\nthen there's no point in risking that."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Change Cleansed"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["I'm sorry. Please forgive me.",
	"It was my fault making you think\nthat cleansing him will do anything good.",
	"Cycle will be mad at us.", "Sorry for dragging you down with me."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Death Not Killed"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["We met Death, right?", "Why couldn't we defeat her?",
	"We should have consumed her.", "Perhaps it is too late for that.",
	"She escaped and will never be seen again.", "At least we won't be the ones to see her."],
	[0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Midas"] = [
	[[snd_selffear_talk, 1, 4, #800080], [snd_midas_talk, 1, 3, #FF007F]],
	["Oohh, Pleasure. Come out come out, wherever you are!",
	"What even are you?\nSome kind of Suffering's follower?",
	"Something much more."],
	[0, 1, 0],
	"none"]
	
	global.dialogues[$ "Fear Talk: Brin"] = [
	[[snd_selffear_talk, 1, 4, #800080], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Everwarrior, who are you fighting?",
	"See? His eyes inflict fear,\nbut cannot see it.",
	"Or maybe he wants to betray us?"],
	[1, 0],
	"none"]
	
	global.dialogues[$ "Fear Talk: No Trick"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["Sorry to interrupt you,\nbut there is nobody you can trick here.", "Just attack."],
	[0],
	"none"]
	
	global.dialogues[$ "Altar Talk: Innocence Suggestion"] = [
	[[snd_selffear_talk, 1, 4, #800080]],
	["You know which one to choose.", "And I will entertain you even more."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Intro Finale"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Hey, buddy.", "Are you sure we're going to make it?",
	"Crystalise me again to confirm it, okay?"],
	[0],
	"none"]
	
	global.dialogues[$ "Change Intro Finale Generic"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Welcome back. Changed your mind?"],
	[0],
	"none"]
	
	global.dialogues[$ "Change Intro"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["What? How did you find me?",
	"Don't even try. Unlike your kind,\nI have completed successfully these kind of battles.",
	"...", "I won't waste my energy without being provoked.\nSooo, if you pose a threat then come fight me.",
	"If not, then leave."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Intro Generic 0"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Why did you come back?", "Don't bother telling others where I am.\nI'm gonna change spots anyway."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Intro Generic 1"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Did you come back for a piece of advice?",
	"Well, if you're asking... Don't come here.\nI think that's some great advice."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Fight Attempt 0"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Huh? You wanna fight?", "Ha. You don't seem to pose any threat to me.",
	"You wouldn't hurt a fly, would ya?",
	"Hahahaha. Haha. Ha... Heh.", "Haven't laughed like that in a while.\nNow, scram."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Fight Attempt 1"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Fighting Gods isn't as simple as tickling them\nwith that sword to death.",
	"Hasn't your parent told you that?\nOr should your uncle do that?",
	"How uncaring of it. Heh.", "Now, go learn something."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Fight Attempt 2"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Buddy. Nephew. Niece. Whichever title you prefer. Listen.", 
	"Stop trying. You're no match for me."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Fight Cleanse"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Hey, hey, hey! What are you doing?", "Wait, Cycle's plan changed?!",
	"But won't that destroy only my physical body?",
	"Whatever. You wanted to fight me?\nWell, bring it on!"],
	[0],
	"change_battle"]
	
	global.dialogues[$ "Change Fight Consume"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Hey, hey, hey! Is that power of consume?!", "Am I actually doomed?",
	"Oh please, spare me! I have a family!",
	"Nah, of course I don't.\nI won't surrender without a fight.",
	"Bring it on, warrior!"],
	[0],
	"change_battle"]
	
	global.dialogues[$ "Change Battling: 95% HP"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Feels great, putting this body to use\n after so long.", 
	"You can already surrender, by the way."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: 30% HP"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Hey, mind slowing down?", "I get it. You are stronger than me.\nAre we cool now?",
	"Please. Stop."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Split"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["I am God of magic, mana and stuff.\nI'm not God of the dead."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Reap"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["I am God of magic, mana and stuff.\nI'm not God of the living."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Crystalise"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Using my powers against me? That's quite hilarious.",
	"Thanks for the heal, I guess."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Ask Help"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Heey! You! Yes, you!", "Mind helping your God?", "What? Who?",
	"Alright, just be here quickly.", "...",
	"Don't worry who I was talking with.\nLet's continue our combat."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Help Arrived"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Finally you came.", "You two distract it."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Help Lost"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Oh no.", "My loyal followers!", "...", "Actually I'm quite surprised they sacrificed\ntheir lives for me.",
	"I didn't think they were that loyal.", "Oh well."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Defeated Cleanse"] = [
	[[snd_change_full_talk, 1, 2, #FFFF00]],
	["A terrible chill went down your spine...", 
	"Just kidding.\nThat's my voice, when I'm not suppressing myself.",
	"You know, my soul is still here,\nand there is little you can do now.",
	"What was your plan exactly?\nDoesn't this make capturing me even harder?",
	"Oh well, Cycle, do you hear me? It's me, Change.\nYour child has destroyed my physical body.",
	"I don't know how you plan on murdering me in this state,\nso perhaps I've won? In a way.",
	"Anyway, I will go taunt you and your other child in your garden.\nYou'll see me soon... or rather, hear.",
	"And as for you, everwarrior... I'm bored with you.\nThough your combat was almost good.",
	"But come back to the Eternal Garden, we all will have a chat.\nAnyway, byeeeee!"],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Defeated Consume"] = [
	[[snd_change_full_talk, 1, 2, #FFFF00]],
	["I will not give up. I won't surrender.",
	"Urgh. You still have the entirety\nof your journey ahead of you.",
	"What's with my voice? That's just my true power.",
	"Anyway, you won't succeed. I will do everything to stop you.",
	"Crystals will infest your body.\nBreathing will be even harder for you.",
	"I will decorate your body, I will end you from the inside.",
	"It's not over. It's not over!\nIt's just the beginning of your struggles."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Battling: Defeated Consume & Death"] = [
	[[snd_change_full_talk, 1, 2, #FFFF00], [snd_death_full_talk, 1, 3, #FF8000]],
	["I will not give up. I won't surrender.",
	"Please do not.",
	"Whose voice is that? Death?",
	"Correct. I was still not consumed.\nBut now I am.",
	"How did it find you?\nNo, it doesn't matter.",
	"I guess it is over for us.",
	"It is not. It has the entirety of its journey left\nbefore it reaches Cycle.",
	"Help me defeat it from the inside.\nPlease.",
	"I guess that's the only thing we can do now."],
	[0, 1, 0, 1, 0, 0, 1, 1, 0],
	"none"]
	
	global.dialogues[$ "Change Help"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["What? You like my little skill?\nThanks buddy.",
	"...", "Hmm, if you are toying with this ability,\nperhaps you would enjoy some of my powers.",
	"How about this: let me assist you in your final battle,\nand you will help me defeat your... parent.",
	"I mean, I'm so tired of waiting,\nmaybe we can finally alter the course of things?",
	"I understand, if you aren't willing\nto go against your creator. That's totally reasonable.",
	"Just, tickle me with that crystal ability again,\nif you are sure.", "...",
	"Really? You are willing to do that?\nWithout a second thought?",
	"Alrighty then, let's do this.",
	"Meet me at the Eternal Garden.\nI need to be sure we are going along with the plan.",
	"Don't worry, I know my way around this cave system.",
	"Goodbye, friend."],
	[0],
	"changegoaway"]
	
	global.dialogues[$ "Change Help Garden 0"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["So you are sure.",
	"Well... Okay I don't know how to be dramatic.\nI'll just reveal my full potential."],
	[0],
	"changetransform"]
	
	global.dialogues[$ "Change Help Garden 1"] = [
	[[snd_change_full_talk, 1, 2, #FFFF00]],
	["Ah, finally. So nice to use this form.",
	"Friend, I will slowly travel to the final arena, alright?",
	"Hopefully you make it there before me.",
	"Anyway, thank you for actually attempting this.\nI really do apreciate it, friend.",
	"Even if we won't succeed, I'm glad you decided\nto take this risk for me.",
	"Heh. Of course we will succeed.\nWe'll see that when we get to that.",
	"Goodbye."],
	[0],
	"changegoaway"]
	
	global.dialogues[$ "Change Help Garden 1 Death"] = [
	[[snd_change_full_talk, 1, 2, #FFFF00]],
	["Ah, finally. So nice to use this form.",
	"Friend, I will slowly travel to the final arena, alright?",
	"Hopefully you make it there before me.",
	"The Boat Person told me that she will also make an appearance.\nHopefully she won't be late.",
	"Anyway, thank you for actually attempting this.\nI really do apreciate it, friend.",
	"Even if we won't succeed, I'm glad you decided\nto take this risk for me.",
	"Heh. Of course we will succeed.\nWe'll see that when we get to that.",
	"Goodbye."],
	[0],
	"changegoaway"]
	
	global.dialogues[$ "Change Talk: No Dialog"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["I've talked for way too long for now.", 
	"How 'bout you annoy some other people?"],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: No Dialog Polite"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Buddy, I've been talking for quite a while.", 
	"I got nothing more to say.\nCan you give me a little break?"],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Distrust"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["You want me to talk?\nAfter your, albeit funny, threats?", 
	"After Innocence got consumed my self preservation skills\nhave been expanded.",
	"By that I mean that I don't trust you.\nAnd probably never will."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Crystal"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Now, I would like to apologize.", 
	"You've probably noticed those crystals growing,\non the floor, walls, ceiling and even on creatures.",
	"I'm no expert on God contamination, but I think\nthe source of those crystals is me.",
	"I think I've suppressed my powers for so long,\nthat they've started to become so stale\nthey are able to meld together into those crystals on their own.",
	"Oh yeah, sorry if I look awful right now.\nI haven't been taking care of myself for a while."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Garden"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["The Eternal Garden has improved since last I've seen it.",
	"I'm planning on inhereting it.\nAfter defeating your parent of course.",
	"I don't think it will take too much convincing\nto banish Cycle with the help of other Gods.",
	"I probably shouldn't think this much ahead,\nbut hey, this is one of the only times I do that!",
	"Anyway, crystalise me again, if you support my idea.\nThen I'll help you out."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Sorrow"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Don't pity me. I'll live through this era.", 
	"Surely your parent will give up soon.", "How long will it still be determined to end me?",
	"Not long. It can't be long.",
	"And after that, it will realise what kind of mistake it was\nto even start the Great Cycle."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Spirits"] = [
	[[snd_change_talk, 1, 3, #007FFF]],
	["Are you okay? You look like you're being haunted.", "Buddy, listen.",
	"I understand how it feels when no one can hear you.\nI've been there. And kind of still am.",
	"Whatever you're facing right now, I'm sure you will overcome it.",
	"Don't let it slow you down. You can do it.\nJust remember that."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Split"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Nice skill you have.",
	"Splitting is something that Life could do to his enemies.\nLike a form of torture."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Parry"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["You seem quite skilled at parrying.",
	"It's one of the things that Exposure used to\nteach her followers about.",
	"Despite her short fuse, she understood\nthat patience is useful in combat."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Impenetrability"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["You know how to create impenetrability?",
	"I assume it's one of Protection's skills.",
	"Honestly, she might be the most cryptic God among us.",
	"Even her followers know her somewhat poorly."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Reap"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Easily the most recognisable skill you have.",
	"Are you trying to become a reaper or something?",
	"Death used to let anyone become one of them,\nas long as they were loyal to her.",
	"Even orphans and heretics would get a chance\nif they wished so.",
	"No wonder she got manipulated into killing Pleasure."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Crystalise"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["Hey! What a funny skill you have!",
	"Do I really need to comment on the greatest God,\nthat has this skill?",
	"Of course, he is strong, handsome, funny, powerful... Haha. Heh.",
	"At least, he used to be.\nNow he is just waiting for Cycle to give up.",
	"And I have been waiting for quite some time.\nBut I won't stop. I won't lose.",
	"I never lose. And that is the only thing\nthat is never going to change about me."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Trick"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["What is that skill?", "It does nothing? How is that useful?",
	"Oh wait. Hold on a minute, buddy.",
	"That energy. That power. That is... Innocence?",
	"Is it supposed to backstab? Vile. Disgusting.",
	"I never liked him.\nAn always power hungry little pest, that's what he is.",
	"He always tried to appear as an innocent guy\nthat would never hurt a fly.",
	"Yet he managed to setup everything to kill Pleasure.\nOr how modern folks call him, 'Midas.'",
	"If you are to follow his steps,\nyou will be at peace only when you reach the Suffering Desert.",
	"Oh yeah, his other name is Suffering."],
	[0],
	"none"]
	
	global.dialogues[$ "Change Talk: Skill Pickpocket"] = [
	[[snd_change_talk, 1, 2, #007FFF]],
	["What's this skill?", "Did you learn this 'ability'\nfrom a bandit or something?",
	"Hah! You gotta admit that one is good.",
	"Seriously, though. Whose skill is this?\nI don't recognize it at all."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Intro"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Oh my Gods! Thank you! Thank you!", "I will never be able to thank you enough!",
	"...", "...", "Actually, I think I will.",
	"I'm a special little chest, I can duplicate coins!\nIf you give me some of yours, I will return you even more!",
	"The more you give, the faster I will duplicate them!",
	"What do you think of this idea, friend?", "...", "Can you speak?", "Oh, you're one of the everwarriors!",
	"In that case, just give me the coins whenever you like."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Intro Generic"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Hi! My friend, I've missed you!",
	"It's been more than 2 seconds since last we met!"],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Stop"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Friend, are you sure you want to leave without\nmaking me duplicate your money?",
	"You need to lock me, so that I make more money."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Stop Tutorial"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Friend, there is one more thing.",
	"In order for me to duplicate your money,\nI need to be locked.",
	"The key will break.\nBut you will be able to find a different one in the next area!",
	"Don't worry about me. I'm used to being locked."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Cave"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["This place is now called the Stale Cave.\nCycle wanted to emphasise the fact that it is now the leader.",
	"I still think this place should be called\nthe Everchanging Cave, because of the constantly growing crystals.",
	"The locals say that it is because of the presence of their God.\nThey say he is the literal source of those crystals.",
	"Sometimes I wonder, what's his voice like.\nAnd whether I talked to him without realising that he is God."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Midas"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Have you heard of Midas? Or Greed? Or Pleasure?",
	"All of those names are for the same God.\nAnd I assume you heard the tale of his death.",
	"I think that he might not be entirely dead.\nLike, he just lacks a body and his soul is\nspread out over the entire world.",
	"I mean, how would any of his powers, including mine,\nstill exist, if he was dead?",
	"But, y'know, that's just a theory of mine.\nI would love to hear yours.\nOnly if you could speak."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Golden Mimic"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["Friend, you should meet my cousin.",
	"It is the golden chest.\nIt really likes gambling and giving gifts.",
	"And it is somehow more successful in finding a partner than me.",
	"As if it has stuff that I don't.\nLike how is it so different from me?",
	"Is it because of its gambling addiction?\nSince when is that an attractive trait?",
	"Like... Oh wait, I think I shouldn't be talking about that. Eheh."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Freezing"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["My friend! Are you freezing?", "Oh no, your beautiful voice is also frozen!",
	"Oh wait, you can't talk in general.\nSorry, I forgot.",
	"But if you are freezing, you should get some tea!\nIt really helps!"],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Tundra"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["I've met the locals today, and they weren't so kind.",
	"One snowman taught me a lesson in how strength works.",
	"Another showed me some weird contraption. It was very loud,\nand the pain was very sharp from it.",
	"There was also this fluffy guy with a spear,\nunlike snowmen he had the ability to make sounds\nwith his mouth!",
	"He must be really strong and tall,\nconsidering how easily and high up he picked me up."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Canyon"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["My friend, don't try befriending those gargoyles!\nIt's dangerous.",
	"No matter how alluring the rustle of their wings is,\nthey will make sure you fear them.",
	"I've tried having a conversation with a few of them.",
	"They all sounded excited, but only because\nI had a soul they wanted to reap.",
	"Kind of like food, y'know."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: Desert"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["My friend! This is when my services\nfinally pay off!",
	"I am more than happy to be useful for you!",
	"By the way, during a sandstorm\nmake sure to be prepared for anything!",
	"During it, it's hard to see or hear anything.\nI can only confirm the hearing part though."],
	[0],
	"none"]
	
	global.dialogues[$ "Steel Mimic Talk: No Dialog"] = [
	[[snd_gmimic_talk_0, 1, 3, #969696]],
	["I think I've somehow ran out of things to say.",
	"I would love to talk even more,\nbut I don't know what I could talk about anymore."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Meta 0"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Hallo, everwarrior!", 
	"Don't be zurpriset by my brewery.\nYou probably haffn't seen a houze, haff ya?",
	"Anyway, look at zis potionz!\nAnd buy zem."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Meta 1"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Hallo, everwarrior!", 
	"You aren't zurprizet by my brewery?",
	"Now you are! HAehah ho!",
	"Anyway, look at zis potionz!\nAnd buy zem."],
	[0, 1, 0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Brin First"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Hallo, everwarrior!\nAnd anozer one.", "Hello.",
	"Look at zis potionz!\nAnd buy zem.", "It's up to the everwarrior.",
	"Ya, ya."],
	[0, 1, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Generic 0"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Welcome back, everwarrior.", "Came to buy my potionz?"],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Generic 1"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Welcome back to my potionz."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Brin Generic 0"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome back, everwarrior and ze ozer guy.", "Came to buy ny potionz?",
	"Maybe."],
	[0, 0, 1],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Brin Generic 1"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome back to my potionz.",
	"Yeah, hello."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Alchemist Intro Angry"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["My patience iz running out.", "Buy my potionz."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Poor 0"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Your trickery won't work.", "I can zmell you don't haff enough."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Poor 1"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["No. Stop.", "I don't haff a potion to fix your poverty."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Poor Night 0"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Even in my zleep I can zmell that lie.", "Not enough aurum."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Poor Night 1"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Unlike zat Shopkeeparer, I don't zleep.", "Don't even try to zteal from me."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Cave"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Zis cave is filled wiz soulz. I can hear zem.", "Mana potion allowz me to do zat."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Tundra"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Cold? Get winter tea potion.", "It iz warm."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Desert"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Zuffering zands. Do you like it here?\nI don't.",
	"I feel hundredz of eyez constantly watching me.",
	"Iz zat why zey say\n'eyez are plentiful and zey are always watching'?",
	"Anyway, buy some of my amazing potionz!"],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Sandstorm"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["I hear a weird wind outzide.",
	"A zandztorm, right?",
	"It hidez what'z on ze outzide,\nbut showz what'z wizin each perzon.",
	"But I don't need a zandztorm to know you have money wizin you."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Seeker"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["I fought a weird inzectoid a week ago.",
	"It wanted to kill every everwarrior.",
	"It ran away before I could defeat it."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Fear"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_midas_talk, 1, 3, #FF007F]],
	["Fear iz in your eyez.",
	"I know you aren't tryink to anger me,\nbut inzide me it awakenz zomezing...",
	"Rageful.", "Zorry, what waz zat? Muzt haff been ze wind."],
	[0, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Heretic"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Who are you?\nZe ozer guy.", "Oh, I'm a... I'm a plant mage.",
	"Interezting. Haffn't zeen one before.", "Do you haff any money?",
	"Umm, I don't collect the money from enemies.\nI usually give it to the everwarrior.",
	"I zee."],
	[0, 1, 0, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Infinite Mode"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["What? Infinite mode?", "Ze everwarrior iz ze source?",
	"Why are ya all zo loud?", "Zorry, everwarrior."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Houses"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Ztop looking at me like zat!",
	"Juzt becauze I haff multiple houzes\ndoezn't mean I am insane.",
	"Ztop being zo envious."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Consume"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Do you haff conzume?",
	"No? Hmm.", "To get it, you haff to reject typical rewardz.",
	"After enouff rejecting, ze prize will wait for you."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Midas Quest 0"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_midas_talk, 1, 3, #FF007F]],
	["Zomezing else?", "Gold chezt told you?\nAbout Midaz?",
	"Very well then.", "My voice falls silent upon this world,\nI haven't been here for some time.",
	"And I am longing for it.", "You are a perfect empty shell\nto do my bidding.",
	"We only have time up until you reach\na certain decaying forest.", "That will be our last meeting.",
	"For now, your first task is\nto gain 20% of my power.", "I'll contribute to that right now.",
	"Once you do gain it, come back\nand talk to this shell and I will guide you further.",
	"For now though...", "Zat's enough talking.\nBuy zome potionz."],
	[0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
	"alchemist_boost_0"]
	
	global.dialogues[$ "Alchemist Talk: Midas Quest 1"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_midas_talk, 1, 3, #FF007F]],
	["Done wiz hiz power?", "Amazing. And it's in a timely fashion.",
	"Despite what you may think,\nthis is not the only part of my plan.",
	"Next step is much harder.",
	"I haven't been paying attention\nto what my shell has to say to you,\nbut he might have mentioned one thing.",
	"An insectoid of sorts.\nIts nickname is Seeker.", "Oh, yez. Kill zat zing.\nIt'z annoying.",
	"Please, don't interrupt me.", "Anyway, it is found most commonly in Suffering Sands.",
	"Why so dumbfounded? Do you not know\nwhat that desert's original name is?",
	"Well, you don't have to search for that creature.\nBecause it is searching for you.",
	"Once you execute it, come back to my shell.", "Enough talking. Buy my potionz."],
	[0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Midas Quest 2"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF], [snd_midas_talk, 1, 3, #FF007F]],
	["Done wiz Zeeker?", "Good.",
	"That's actually not part of my plan at all,\nbut I wanted to get revenge on Suffering.",
	"Who iz zat?", "How do you not know him?\nHe's Innocence and the Eyeful.",
	"Oh. Zat name is not uzed, az far az I know.",
	"I see. I haven't heard people in a while.",
	"Anyway, now since you did all of that,\nyou proved yourself to be loyal.",
	"Alchemist, do you mind if I switch?",
	"No, my mazter.", "Don't call me 'your master'.\nI command no one.",
	"Right, zorry.", "Anyway, enjoy your privacy.\nEverwarrior, enjoy your full Midas' power.",
	"Now, the plan is for you\nto serve your full purpose.",
	"Defeat your sibling,\nbut before that I want to chat with your parent.",
	"And you, Alchemist.\nI hope you will find happiness in your business.", "Farewell.",
	"Farewell."],
	[0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0],
	"midas"]
	
	global.dialogues[$ "Alchemist Talk: No Dialog 0"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Zat's enough talking.", "Don't act like Shopkeepererer\nby conztantly azking ztuff."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: No Dialog 1"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Ztop ztaring at me.", "Buy already."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Angry 0"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["I won't talk wiz ya, until ya buy zome of my potionz."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Talk: Angry 1"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["I need profit. Buy potionz, now."],
	[0],
	"none"]
	
	global.dialogues[$ "Alchemist Fight 0"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Enough. Ya don't want to pay.", "I will forze ya to pay.",
	"With your life!", "HAhea ha ho haeha HEHA haaah."],
	[0],
	"alchemist_battle"]
	
	global.dialogues[$ "Alchemist Fight 1"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["Enough. I am mad again.", "Ready for round two?"],
	[0],
	"alchemist_battle"]
	
	global.dialogues[$ "Alchemist Fight End"] = [
	[[global.alchemist_voices, 0.9, 3, #C83CFF]],
	["I can fight forever.", "But my business would die becauze of zat."],
	[0],
	"end_battle"]
	
	global.dialogues[$ "Alchemist Cloned"] = [
	[[global.alchemist_voices, 1, 3, #C83CFF]],
	["Really? Ya zink splitting me will do any gut?",
	"I haff already created potionz for zis situation.",
	"But let'z play along."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Poison"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["In shadows eyes are plentiful, and as they watch,\nMy poison ripens, prepared for no botch."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Heretic"] = [
	[[global.seeker_voices, 1, 3, #666666], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Human one, I insist, please flee,\nDon't stay here, you don't want to see.",
	"...", "I can tell you are torn,\nBut tell me, is this why you've been born?",
	"What? What does that even mean?", "Your eyes widen in fear,\nIs that why you're here?",
	"This is my only chance to thrive.\nDon't take it away from me.",
	"Loyalty permeates the air,\nLet's see what you two dare.",
	"That doesn't make much sense either.",
	"I'm making these as we go. Have some respect.\nI will stick to ones I've prepared beforehand.",
	"Alright, I won't interrupt you."],
	[0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Seeker Generic 0"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["The end is close, the end is nigh,\nSoon falls eternal night."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Generic 1"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["Once Innocence is free,\nNo everwarrior will flee."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Generic 2"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["Great Suffering awaits us all,\nEach everwarrior will fall."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Generic 3"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["Those praising Innocence in delight,\nWill soon forget the world's cruelest light."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Round 2"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["Yes, I am back from the dead.\nBut this time I will tear off your head."],
	[0],
	"none"]
	
	global.dialogues[$ "Seeker Trick"] = [
	[[global.seeker_voices, 1, 3, #666666]],
	["You praise Innocence? Oh forgive me, please forgive me.\nI didn't know such everwarriors.. uh.. can come to be.",
	"Enough with rhyming.\nI will not go against those, who praise my Father.",
	"Find success in your journey.\nBut for now, you should enjoy my gift."],
	[0],
	"end_battle"]
	
	global.dialogues[$ "Heretic Intro"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_0, 0.9, 4, #00AA14]],
	["Finally you arrive.\nHello, everwarrior!",
	"I would like to apologise for any\nand every hurtful encounter you had with us.",
	"We need to gain materials and\npower somehow, y'know.",
	"I can tell others to stop attacking you,\nbut only if you are willing to make a deal.",
	"The way you are trying to avoid eye contact\nmakes me believe that you know what I mean.",
	"I can tell you are holding a grudge.\nMaybe you can get revenge, and we can assist you.",
	"However, we aren't going to risk our entire campaign\nif you don't have enough power.",
	"We will only help you, if you have power of absorbing others.",
	"Power of consume.",
	"Show me that you have that power,\nand we will assist you.",
	"Don't worry, you can do that any time you want.\nNo pressure."],
	[0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0],
	"none"]
	
	global.dialogues[$ "Heretic Intro Generic 0"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Welcome back."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Intro Generic 1"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Hello again."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Intro Generic Brin 0"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Came to visit me?", "I guess so."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Heretic Intro Generic Brin 1"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Welcome back.", "Hi again."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Heretic Join No Consume 0"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Oh, so you would like to join us?",
	"Lemme see your power.",
	"...", "Sorry, but you don't have consume.",
	"I heard you, everwarriors, get it from treasures.",
	"Other than that, I have no idea how to get it."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join No Consume 1"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["You got consume?",
	"...", "Doesn't seem like it.",
	"Not much time has passed last time you tried to join us anyway."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join No Consume 2"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Hmm... No consume.",
	"Reminder: we only accept the ones with consume powers."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join Alliance 0"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Oh, so you would like to join us?",
	"Lemme see your power.",
	"...", "What the?",
	"I can feel mana brewing in your blood.",
	"Have you created an alliance with God of mana?",
	"Yeah, no. We are heretics. Not free help services.\nWe aren't going to help those who work for Gods.",
	"It wasn't a grudge after all."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join Alliance 1"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Joining us is no longer an option.",
	"Don't worry, I will not release the bird into the wild.\nNice saying, right? Barb made it up few days ago.",
	"It means: I won't tell others. I respect having secrets."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join Alliance 2"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Please stop trying to join us.",
	"We won't help you."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Join Success"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Oh, so you would like to join us?",
	"Lemme see your power.",
	"...", "Ohohoho!",
	"That's what I'm talking about!\nFinally an everwarrior that has consume!",
	"Uh. Sorry, I forgot what I have to do.\nY'know I haven't had this scenario in a while.",
	"Oh, right! I have to call a friend of mine to assist you for now."],
	[0],
	"whistle that summons a heretic"]
	
	global.dialogues[$ "Heretic Brin Intro"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["There you are, Brin.\nLook at who we have!",
	"An everwarrior? With consume?", "Exactly!",
	"Oh, great. So, I'm supposed to help it, right?",
	"Yes, you are supposed to assist it in every battle.\nAnd I do mean every single one.",
	"Are you sure you can handle that?",
	"Of course. Who else would help the warrior?",
	"The rest of us, no?",
	"Speaking of, we will make an appearance at the great battle.",
	"If you two make it there.",
	"Both of us? Even me?", "Yes. Especially you.\nYou are one of the greatest warriors.",
	"Okay. I'm tired of talking.\nCan we get moving?",
	"Wait, shouldn't we teach the everwarrior to command you?",
	"Oh right. Let's do that."],
	[0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1],
	"heretic_tutorial_fight"]
	
	global.dialogues[$ "Heretic Brin Tutorial 0 Attacked"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Woah, I didn't even say anything\nand you already attack.",
	"Go on.", "Ahem, everwarrior.\nYou need to learn how to be in a team.",
	"You need to learn how to work together.",
	"It's quite easy. I repeat everything I can after you.",
	"That's it.", "And as you can see, he attacks if you attack.",
	"He defends if you defend and whatever.",
	"Now show me, what you have.", "On it."],
	[0, 1, 0, 0, 1, 1, 0, 0, 0, 1],
	"none"]
	
	global.dialogues[$ "Heretic Brin Tutorial 0"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Everwarrior.\nYou need to learn how to be in a team.",
	"You need to learn how to work together.",
	"It's quite easy. I repeat everything I can after you.",
	"That's it.", "That means that, he attacks if you attack.",
	"He defends if you defend and etc.",
	"Now show me, what you have.", "On it."],
	[0, 0, 1, 1, 0, 0, 0, 1],
	"none"]
	
	global.dialogues[$ "Heretic Brin Tutorial 1"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["By the way, the items you might use\nhave no effect on me.",
	"They are purely yours.", "Oh yeah, thanks for pointing that out.",
	"I forgot about that myself.", "It's okay."],
	[1, 1, 0, 0, 1],
	"none"]
	
	global.dialogues[$ "Heretic Brin Tutorial End Too Long"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Okay, that's enough fighting for me.",
	"Oh come on, we were getting started.", "That's enough of a warmup for you two.",
	"Plus you're going to have\nway more battles ahead.", "Fair enough."],
	[0, 1, 0, 0, 1],
	"end_battle"]
	
	global.dialogues[$ "Heretic Brin Tutorial End Little HP"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["You are way too strong for me.\nCan we stop?",
	"Oh come on, we were getting started.", "You're going to face much more dangerous foes soon.",
	"Alright."],
	[0, 1, 0, 1],
	"end_battle"]
	
	global.dialogues[$ "Heretic Talk: Altar"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["I hope you aren't angry at us for using this shrine.",
	"You're not the only one, who can use these, y'know.",
	"For example, we are practicing our magic defense here.",
	"This is the part, where you would ask why.\nI'm going to pretend like you did.",
	"Why? Well, we're going to fight fire with fire!",
	"Neat saying, right? Harl made it up a few weeks ago."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Talk: Job"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Y'know, we all have different tasks.",
	"Mine is to greet and convince you\nand others alike to join us.",
	"As you can see, I haven't been really successful.",
	"The one time I managed to convince an everwarrior to join,\nit just drowned in the water of hatred.",
	"It probably thought that joining us is enough\nto have hatred water immunity.",
	"I probably should have mentioned that it takes time\nfor that to happen. At least 3 cycles or so."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Talk: Shopkeeper"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["I heard that one of our past members\nis still selling goods to your kind.",
	"I wonder if he is still an orphan\nor started to worship one of Gods.",
	"I hope he won't reveal us to any God."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Talk: No Dialog"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14]],
	["Alright, that's enough talking for now.\nI'm a little tired, and dry on topics."],
	[0],
	"none"]
	
	global.dialogues[$ "Heretic Talk: No Dialog Brin"] = [
	[[snd_heretic_talk_0, 1, 3, #00AA14], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Alright, that's enough talking for now.\nI'm a little tired, and dry on topics.",
	"Yeah, we should get going."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Herbalist Intro Garden"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hello there.\nThe three thousand hundred seventy... uh... third one?",
	"Probably. I'll just call you the everwarrior.",
	"Anyway, you have the potential\nto use one of your key abilities.",
	"It is so important, that you can cheat Death with it!",
	"But! I don't think you need it in these beautiful gardens.\nSo meet me in the forest up ahead.",
	"I'll teach you all of the ropes there."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Intro Forest"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hello there.\nThe three thousand hundred seventy... uh... third one?",
	"Probably. I'll just call you the everwarrior.",
	"Anyway, you have the potential\nto use one of your key abilities.",
	"It is so important, that you can cheat Death with it!",
	"This forest is quite dangerous with\nall of those bandits and thugs constantly ambushing us.",
	"If you are willing to pay me a small fee,\nI will help you use your innate ability to persist.",
	"Just give me the coins when you're ready."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Intro Generic"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hello there.\nThe three thousand hundred seventy... uh... third one?",
	"Probably. I'll just call you the everwarrior.",
	"Anyway, you have the potential\nto use one of your key abilities.",
	"It is so important, that you can cheat Death with it!",
	"This place is quite dangerous. We both can die at any moment.",
	"But if you are willing to pay me a small fee,\nI will help you use your innate ability to persist.",
	"Just give me the coins when you're ready."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Intro Brin"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Hello there. I see that you have a new friend.",
	"Yes. It does.", "Well, a friend of a friend is my friend!",
	"I'm the Herbalist. How should I refer to you?",
	"You can call me Bri... Bringer.\nYeah, my nickname's Bringer.",
	"Nice to meet you, Bringer.",
	"Despite being nicknamed the Herbalist,\nmy main purpose is to help everwarriors persist.",
	"Persist? Haven't heard of that.",
	"It's a skill native only to some.\nIt allows them to go back in time and alter their fates!",
	"And you're saying our friend can do that?", "Yes, but only with my help.", "I see."],
	[0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Generic"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hi everwarrior."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Generic Brin"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Hi guys.", "Hey."],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Sick 0"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hey, everwarrior! Check out my new look!"],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Sick 1"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hey. It's getting harder to notice you."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Sick 1 Brin"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64], [snd_heretic_talk_1, 1, 3, #2FA108]],
	["Hey. It's getting harder to notice you.",
	"Are you okay?", "...", "Hey. Can you hear me?"],
	[0, 1],
	"none"]
	
	global.dialogues[$ "Herbalist Greet Danger"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["DANGER. NEARING.", "No, it isn't danger necessarily.",
	"BANDIT. WITH SWORD.", "Oh. That is dangerous.",
	"Mr Bandit, please, go away.\nFor your own good.",
	"...", "SILENT.", "I guess we have to fight back."],
	[0, 1, 0, 1, 1, 0, 0, 1],
	"herbalist_battle"]
	
	global.dialogues[$ "Herbalist Greet Danger Brin"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64],
	[snd_heretic_talk_1, 1, 3, #2FA108]],
	["DANGER. NEARING.", "No, it isn't danger necessarily.",
	"BANDITS. WITH SWORDS.", "Hey! We aren't bandits.",
	"Oh. That is dangerous.",
	"Bandits, please, go away.\nFor your own good.",
	"Everwarrior, perhaps we should leave.", "AGGRESSIVE.",
	"What!? Can you not hear me?", "I guess we have to fight back."],
	[0, 1, 0, 2, 1, 1, 2, 0, 2, 1],
	"herbalist_battle"]
	
	global.dialogues[$ "Herbalist Tutorial"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Hi, everwarrior. I was anticipating this moment.",
	"I will help you use your persistence.",
	"But only if you are willing to pay me a small fee.\nIt is somewhat at my expense, that's the only reason I charge you.",
	"Just give me the coins when you're ready."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save Too Early 0"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Nuh-uh-uh! Sneaky, sneaky!\nYou can't fool me like that.",
	"Just because I don't use persistence myself\ndoesn't mean that I don't understand how it works.",
	"I'll let you use my help in the next area, friend.",
	"For now I will act as if nothing happened."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save Too Early 1"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Friend. No."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 0"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["So you do want to do it.",
	"Okay, just close your eyes.\nBreathe in. And breathe out.",
	"...", "Are you going to close your eyes?",
	"Oh, I feel that you managed to persist without doing that.",
	"Wow, your potential is incredible compared to others.",
	"Now, if you happen to perish,\nyou will end up here at this exact moment.",
	"And as long as you are stubborn.. err I mean, persistant enough,\nyou can live forever.",
	"Only if you accept your defeat, you will actually stop existing."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 0 Broke"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["That's a bit too little, but since we are good friends\nI will make an exception.",
	"Okay, just close your eyes.\nBreathe in. And breathe out.",
	"...", "Are you going to close your eyes?",
	"Oh, I feel that you managed to persist without doing that.",
	"Wow, your potential is incredible compared to others.",
	"Now, if you happen to perish,\nyou will end up here at this exact moment.",
	"And as long as you are stubborn.. err I mean, persistant enough,\nyou can live forever.",
	"Only if you accept your defeat, you will actually stop existing."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 1"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Alrighty, close your. Oh wait you don't need to.",
	"Just breathe in. And out.",
	"...",
	"Good job. Now it is a little different.",
	"Your persistence will take you here now."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 1 Broke"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["That's slightly less than needed, but I'll let it slide.",
	"Anyway, close your. Oh wait you don't need to.",
	"Just breathe in. And out.",
	"...",
	"Good job. Now it is a little different.",
	"Your persistence will take you here now."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 2"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Okay, breathe in. Breathe out.",
	"...",
	"Okay, nice. You are getting\nso much better at it already.",
	"Not sure why you need me anymore, but I do appreciate it."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 2 Broke"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Oh, you barely don't have enough.\nDon't worry, I'll still accept it.",
	"Anyway, breathe in. Breathe out.",
	"...",
	"Okay, nice. You are getting\nso much better at it already.",
	"Not sure why you waste your last savings on me at this point\n, but I do appreciate it."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 3"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Alright. Do your thing.",
	"...",
	"Good job."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Save 3 Broke"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["That's not enough, but I don't really care.\nNot like I play a cruical role here.",
	"Anyway, do your thing.",
	"...",
	"Good job."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Poor"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["You need quite a few more coins to afford it.",
	"Even if we are friends,\nit doesn't mean I do my services for free."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Battling Generic 0"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["DIE.", "Please, leave.",
	"SILENT.", "Why are they so aggressive to us?",
	"NOT. KNOWN."],
	[0, 1, 0, 1, 0],
	"none"]
	
	global.dialogues[$ "Herbalist Battling Generic 1"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["How injured are they?", "NOT. KNOWN.",
	"When will this end?"],
	[1, 0, 1],
	"none"]
	
	global.dialogues[$ "Herbalist Battling End"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Please... stop.", "SILENT.",
	"How do they even... look?", "TALL. BALD. EYES AWAY.",
	"Wait... Is that the everwarrior?\nIs their sword long?",
	"YES.", "Oh Great Cycle! Why... did you not tell me?",
	"NOT. KNOWN.", "Everwarrior... I'm sorry.",
	"These are my final... breaths.",
	"But... I can try to help you... persist."],
	[1, 0, 1, 0, 1, 0, 1, 0, 1],
	"save_buttons_appear"]
	
	global.dialogues[$ "Herbalist Battling End Persist"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["...", "Stay safe... friend."],
	[1],
	"kill_herbalist"]
	
	global.dialogues[$ "Herbalist Battling End Reject"] = [
	[[snd_bush_talk, 1, 3, #8CFF64], [snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["You... reject it?", "...", "Stay safe... friend."],
	[1],
	"kill_herbalist"]
	
	global.dialogues[$ "Herbalist Talk: Introduction"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Are you asking me who I am?",
	"Well, I'm the Herbalist. I like plants.",
	"But unlike other plant mages,\nI actually care for my little herbs.",
	"Speaking of, did you know that you are one too?\nAt least that's what your parent says.",
	"And that's why I want to help you!\nBecause I'm taking care of you that way."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Shopkeeper"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Have you seen the Shopkeeper?",
	"I wanted to chat with him,\nbut it seems like he cares only for bartering.",
	"His eyes are quite creepy. Way too vertical."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Deep Forest"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["This place was initially known as Forest of Protection.",
	"The mysterious God, that ruled these lands,\nprovided safe haven for anyone.",
	"Not sure why your parent saw her as a threat,\nbut who am I to judge? I'm merely a mortal human."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Cave"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["This place is of pure hatred for\nyour kind and followers of your parent.",
	"Their ruler, the one you need to consume, was really awful.",
	"He would 'decorate' and 'spice up' others.\nWhich is just twisting their bodies in creepy and disgusting ways.",
	"Rumours say that one of his most\nloyal followers was mourning the death of their child.",
	"And guess what he did. He took away their ability to cry!",
	"Awful, sadistic."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Tundra"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["I'm turning into solid ice here.",
	"I don't remember what your parent said about these lands' ruler.",
	"But it did say that I would freeze here to death."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Canyon"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["This place sounded so peaceful,\nbut why are there so many spiders!?",
	"And those angels. Ugh. As attractive as they look,\nthey make such awful sounds.",
	"I wonder if the ruler of this place also sounded this atrocious."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Desert"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Your parent was right about this place.",
	"Eyes are plentiful and they are always watching.",
	"I will have a panic attack if I stay here for too long."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: Rotten Forest"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["There are so many acids here.",
	"I asked for help from those robed figures,\nas their robes seemed to protect them.",
	"But they didn't even listen and attacked me!",
	"What even is this place?\nWhere is the Holy Forest that your parent was talking about?"],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: No Dialog"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["Sorry, I don't have anything to say."],
	[0],
	"none"]
	
	global.dialogues[$ "Herbalist Talk: No Dialog Sick"] = [
	[[snd_herbalist_talk_0, 1, 3, #8CFF64]],
	["..."],
	[0],
	"none"]
	
	global.dialogues[$ "Peace Seeker: Intro"] = [
	[[snd_hp_decrease, 1.5, 3, #FFFFFF]],
	["Hey, this is unfinished. It's spoilers."],
	[0],
	"none"]
	
	global.dialogues[$ "Brin Too Low HP 0"] = [
	[[snd_heretic_talk_1, 1, 3, #2FA108]],
	["Warrior. I'm sorry. I am hurt way too much.",
	"I will rejoin you right after this battle.",
	"Good luck."],
	[0],
	"brin_escape"]
	
	global.dialogues[$ "Brin Too Low HP 1"] = [
	[[snd_heretic_talk_1, 1, 3, #2FA108]],
	["I'm bleeding a lot.",
	"I will rejoin you after this battle.",
	"Good luck."],
	[0],
	"brin_escape"]
	
	global.dialogues[$ "Brin Too Low HP 2"] = [
	[[snd_heretic_talk_1, 1, 3, #2FA108]],
	["I am about to die.",
	"Sorry, good luck."],
	[0],
	"brin_escape"]
	
	global.dialogues[$ "Bandit Concerned 0"] = [
	[[snd_bandit_talk, 1, 3, #FF8C50]],
	["Kid, you're okay?"],
	[0],
	"none"]
	
	global.dialogues[$ "Bandit Concerned 1"] = [
	[[snd_bandit_talk, 1, 3, #FF8C50]],
	["Kid, you sure you want to fight?"],
	[0],
	"none"]
	
	global.dialogues[$ "Icewarrior Concerned 0"] = [
	[[snd_bandit_talk, 1.5, 3, #6DE1FF]],
	["Are you sure you can handle our tundra?"],
	[0],
	"none"]
	
	global.dialogues[$ "Icewarrior Concerned 1"] = [
	[[snd_bandit_talk, 1.5, 3, #6DE1FF]],
	["If you want to live, you better get out of here, warrior.",
	"Calling you a warrior is an insult to myself."],
	[0],
	"none"]
	
	global.dialogues[$ "Crystal Assasin Concerned 0"] = [
	[[snd_bandit_talk, 1.25, 3, #FF00FF]],
	["And why did he warn us about your kind?"],
	[0],
	"none"]
	
	global.dialogues[$ "Crystal Assasin Concerned 1"] = [
	[[snd_bandit_talk, 1.25, 3, #FF00FF]],
	["Really? This is who Cycle sends out?"],
	[0],
	"none"]
}