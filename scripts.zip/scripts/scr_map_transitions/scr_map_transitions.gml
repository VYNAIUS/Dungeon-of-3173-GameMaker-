function transition_to_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "fight"
		global.fight_type = "none"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_tedious_battle, 0, false, 1, 0, 1)
		switch global.area_id
		{
			case 0:
				global.battle_song_played = audio_play_sound(mus_battle_garden, 1, true, 0)
				break
			case 1:
				global.battle_song_played = audio_play_sound(mus_battle_forest, 1, true, 0)
				break
			case 2:
				global.battle_song_played = audio_play_sound(mus_battle_cave, 1, true, 0)
				break
			case 3:
				global.battle_song_played = audio_play_sound(mus_battle_tundra, 1, true, 0)
				break
			case 4:
				global.battle_song_played = audio_play_sound(mus_battle_canyon, 1, true, 0)
				break
			case 5:
				global.battle_song_played = audio_play_sound(mus_battle_desert, 1, true, 0)
				break
			case 6:
				global.battle_song_played = audio_play_sound(mus_battle_rotten, 1, true, 0)
				break
			default:
				global.battle_song_played = audio_play_sound(mus_tedious_battle, 1, true, 0)
				break
		}
		audio_sound_gain(global.battle_song_played, 0.9, 7000)
	}
}

function transition_to_altar()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "altar"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_whispers, 0, false, 1, 0, 1)
	}
}

function transition_to_altar_grand()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "altar_grand"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_whispers_grand, 0, false, 1, 0, 1)
	}
}

function transition_to_altar_corrupted()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "altar_corrupted"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_whispers_mana, 0, false, 1, 0, 1)
	}
}

function transition_to_treasure()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "treasure"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_whispers, 0, false, 1, 0, 1)
	}
}

function transition_to_map()
{
	if instance_exists(obj_transition) == false
	{
		global.is_map_transitioning = true
		global.transition_type = "map"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.battle_song_played != undefined and audio_is_playing(global.battle_song_played)
		{
			audio_sound_gain(global.battle_song_played, 0, 1000)
		}
		if global.npc_song_played != undefined and audio_is_playing(global.npc_song_played)
		{
			audio_sound_gain(global.npc_song_played, 0, 1000)
		}
	}
}

function transition_to_finale()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "finale"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		global.npc_song_played = audio_play_sound(mus_cycles_creations, 1, true, 0)
		audio_sound_gain(global.npc_song_played, 0.6, 2000)
	}
}

function transition_to_boss()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		if not(global.final_area)
		{
			global.transition_type = "boss"
			global.fight_type = "boss"
			instance_create_layer(0, 0, "Instances", obj_transition)
			if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
			{
				audio_sound_gain(global.area_song_played, 0, 1000)
			}
			audio_play_sound(snd_intro_epic_battle, 0, false, 1, 0, 1)
			switch global.area_id
			{
				case 0:
					global.battle_song_played = audio_play_sound(mus_epic_battle_garden, 1, true, 0)
					break
				case 1:
					global.battle_song_played = audio_play_sound(mus_epic_battle_forest, 1, true, 0)
					break
				case 2:
					global.battle_song_played = audio_play_sound(mus_epic_battle_cave, 1, true, 0)
					break
				case 3:
					global.battle_song_played = audio_play_sound(mus_epic_battle_tundra, 1, true, 0)
					break
				case 4:
					global.battle_song_played = audio_play_sound(mus_epic_battle_canyon, 1, true, 0)
					break
				case 5:
					global.battle_song_played = audio_play_sound(mus_epic_battle_desert, 1, false, 0)
					break
				case 6:
					global.battle_song_played = audio_play_sound(mus_epic_battle_rotten, 1, false, 0)
					break
				default:
					global.battle_song_played = audio_play_sound(mus_epic_battle, 1, true, 0)
					break
			}
			audio_sound_gain(global.battle_song_played, 1, 7000)
		}
		else
		{
			global.transition_type = "boss_3173"
			global.fight_type = "3173"
			instance_create_layer(0, 0, "Instances", obj_transition)
			audio_play_sound(snd_intro_3173, 0, false, 1, 0, 1)
			global.battle_song_played = audio_play_sound(mus_3173, 1, true, 0)
			audio_sound_gain(global.battle_song_played, 1, 7000)
		}
	}
}

function transition_to_fight_elite()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "fight_elite"
		global.fight_type = "elite"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_epic_battle, 0, false, 1, 0, 1)
		switch global.area_id
		{
			case 0:
				global.battle_song_played = audio_play_sound(mus_epic_battle_garden, 1, true, 0)
				break
			case 1:
				global.battle_song_played = audio_play_sound(mus_epic_battle_forest, 1, true, 0)
				break
			case 2:
				global.battle_song_played = audio_play_sound(mus_epic_battle_cave, 1, true, 0)
				break
			case 3:
				global.battle_song_played = audio_play_sound(mus_epic_battle_tundra, 1, true, 0)
				break
			case 4:
				global.battle_song_played = audio_play_sound(mus_epic_battle_canyon, 1, true, 0)
				break
			case 5:
				global.battle_song_played = audio_play_sound(mus_epic_battle_desert, 1, false, 0)
				break
			case 6:
				global.battle_song_played = audio_play_sound(mus_epic_battle_rotten, 1, false, 0)
				break
			default:
				global.battle_song_played = audio_play_sound(mus_epic_battle, 1, true, 0)
				break
		}
		audio_sound_gain(global.battle_song_played, 1, 7000)
	}
}

function transition_to_shop()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "shop"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_shop, 0, false, 1, 0, 1)
		global.npc_song_played = audio_play_sound(mus_shopkeeper, 1, true, 0)
		audio_sound_gain(global.npc_song_played, 0.6, 6000)
	}
}

function transition_to_herbalist()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "herbalist"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_herbalist, 0, false, 1, 0, 1)
		global.npc_song_played = audio_play_sound(mus_herbalist, 1, true, 0)
		audio_sound_gain(global.npc_song_played, 0.6, 6000)
	}
}

function transition_to_alchemist()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "alchemist"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_alchemist, 0, false, 1, 0, 1)
		global.npc_song_played = audio_play_sound(mus_alchemist, 1, true, 0)
		audio_sound_gain(global.npc_song_played, 0.6, 6000)
	}
}

function transition_to_alchemist_secondary()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "alchemist_2"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		global.npc_song_played = audio_play_sound(mus_alchemist, 1, true, 0)
		audio_sound_gain(global.npc_song_played, 0.6, 6000)
	}
}

function transition_to_escape_main()
{
	if instance_exists(obj_transition) == false
	{
		global.current_exit_type = "none"
		global.player_can_move = false
		global.transition_type = "escape_main"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_steps_multiple, 0, false, 0.5, 0, 1)
	}
}

function transition_to_escape_extra()
{
	if instance_exists(obj_transition) == false
	{
		global.current_exit_type = "shortcut"
		global.player_can_move = false
		global.transition_type = "escape_main"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0.2, 1000)
		}
		audio_play_sound(snd_steps_multiple, 0, false, 0.5, 0, 1)
	}
}

function transition_to_area_popup()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "new_area"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		if global.area_ambiance_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_ambiance_played, 0, 1000)
		}
		global.area_song_played = undefined
		instance_create_layer(0, 0, "Instances", obj_transition)
	}
}

function transition_to_quit_game()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "quit_game"
		instance_create_layer(0, 0, "Instances", obj_transition)
	}
}

function transition_to_shopkeeper_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "shopkeeper_fight"
		global.fight_type = "shopkeeper_fight"
		global.shopkeeper_dead_rn = true
		global.shopkeeper_encounters = 0
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		audio_play_sound(snd_intro_no_theft, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_no_theft, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 7000)
	}
}

function transition_to_herbalist_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "herbalist_fight"
		global.fight_type = "herbalist_fight"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		audio_play_sound(snd_intro_persistor, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_persistor, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 7000)
	}
}

function transition_to_alchemist_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "alchemist_fight"
		global.fight_type = "alchemist_fight"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		audio_play_sound(snd_intro_no_payment, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_no_payment, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 7000)
	}
}

function transition_to_boatperson()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "boat_person"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 500)
		}
		if global.death_state == 1 and global.area_id == 4
		{
			audio_play_sound(snd_intro_death, 1, false, 1, 0, 1)
		}
		else
		{
			global.npc_song_played = audio_play_sound(mus_boat_person, 1, false, 0.6)
		}
	}
}

function transition_to_death_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "death_fight"
		global.fight_type = "death_fight"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		global.battle_song_played = audio_play_sound(mus_death, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 1000)
	}
}

function transition_to_change()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "change"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 500)
		}
	}
}

function transition_to_change_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "change_fight"
		global.fight_type = "change_fight"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		audio_play_sound(snd_intro_change_battle, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_change_battle, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 4000)
	}
}

function transition_to_heretic()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "heretic"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 500)
		}
		global.npc_song_played = audio_play_sound(mus_heretics, 1, true, 0.6)
	}
}

function transition_to_heretic_tutorial_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "heretic_tutorial_fight"
		global.fight_type = "heretic_tutorial_fight"
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		if global.npc_song_played != undefined and audio_is_playing(global.npc_song_played)
		{
			audio_sound_gain(global.npc_song_played, 0, 1000)
		}
		instance_create_layer(0, 0, "Instances", obj_transition)
		audio_play_sound(snd_intro_tedious_battle, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_tedious_battle, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 1, 7000)
	}
}

function transition_to_mimic_golden()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "mimic_golden"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		if global.gmimic_encounters >= 1
		{
			global.npc_song_played = audio_play_sound(mus_friendly_mimic, 1, true, 0.3)
			audio_sound_gain(global.npc_song_played, 1, 1000)
		}
	}
}

function transition_to_mimic_steel()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "mimic_steel"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		if global.smimic_encounters >= 1 and not(global.smimic_locked)
		{
			global.npc_song_played = audio_play_sound(mus_affectionate_mimic, 1, true, 0.3)
			audio_sound_gain(global.npc_song_played, 1, 1000)
		}
	}
}

function transition_to_seeker_fight()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.transition_type = "seeker_fight"
		global.fight_type = "seeker_fight"
		instance_create_layer(0, 0, "Instances", obj_transition)
		if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
		{
			audio_sound_gain(global.area_song_played, 0, 1000)
		}
		audio_play_sound(snd_intro_seeker, 0, false, 1, 0, 1)
		global.battle_song_played = audio_play_sound(mus_seeker, 1, true, 0)
		audio_sound_gain(global.battle_song_played, 0.9, 7000)
	}
}

function transition_to_balance()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.is_map_transitioning = true
		global.transition_type = "balance"
		trigger("mute_everything")
		instance_create_layer(0, 0, "Instances", obj_transition)
	}
}

function transition_to_gameover()
{
	if instance_exists(obj_transition) == false
	{
		global.player_can_move = false
		global.is_map_transitioning = true
		global.transition_type = "gameover"
		trigger("mute_everything")
		instance_create_layer(0, 0, "Instances", obj_transition)
	}
}

function transition_to_main_menu()
{
	global.is_map_transitioning = true
	global.is_paused = false
	global.current_ui_layer = 0
	global.transition_type = "main_menu"
	window_set_caption("Dungeon of 3173")
	instance_create_layer(0, 0, "Instances", obj_transition)
	trigger("mute_everything")
	trigger("delete_uistuff")
}