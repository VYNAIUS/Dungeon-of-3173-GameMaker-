function create_settings_box(xcoord = 0, ycoord = 0, xscale = 1, yscale = 1, affected_by_enemy_stats = false)
{
	var settings_box = instance_create_depth(xcoord, ycoord, depth - 10, obj_settings_box)
	settings_box.image_xscale = xscale
	settings_box.image_yscale = yscale
	settings_box.affected_by_enemy_stats = affected_by_enemy_stats
	global.current_ui_layer += 1
	settings_box.ui_layer = global.current_ui_layer
	return settings_box
}