function trigger(trigger_name = "none")
{
	switch trigger_name
	{
		case "none":
			break
		case "player_stare":
			with obj_shop_player
			{
				sprite_index = spr_player
			}
			with obj_fight_player
			{
				sprite_index = spr_player
			}
			break
		case "transition_shopkeeper":
			if room == rom_map
			{
				if array_length(global.saved_tiles) == 0
				{
					save_tiles()
				}
			}
			transition_to_shop()
			break
		case "transition_map":
			transition_to_map()
			break
		case "shopkeeper_battle":
			trigger("shopkeeper_reset_sus")
			var new_shopkeeper_items_array = []
			for (var i = 0; i < array_length(global.shopkeeper_items); i++)
			{
				var shop_item = global.shopkeeper_items[i]
				array_push(new_shopkeeper_items_array, shop_item.id_name)
			}
			global.shopkeeper_items = new_shopkeeper_items_array
			global.shopkeeper_told_dialog = []
			transition_to_shopkeeper_fight()
			break
		case "herbalist_battle":
			transition_to_herbalist_fight()
			break
		case "save_buttons_appear":
			global.herbalist_defeated = true
			if global.battle_song_played != undefined and audio_is_playing(global.battle_song_played)
			{
				audio_sound_gain(global.battle_song_played, 0, 1000)
			}
			var box = create_settings_box(683, 384, 3, 1, false)
			instance_create_depth(491, 384, box.depth - 10, obj_button_herbalist_battle_save)
			instance_create_depth(875, 384, box.depth - 10, obj_button_herbalist_battle_reject)
			break
		case "kill_herbalist":
			with obj_fight_bush_herbalist
			{
				dialogue_progress = 99
				hp = 0
			}
			break
		case "alchemist_battle":
			global.alchemist_anger = 0
			var new_alchemist_items_array = []
			for (var i = 0; i < array_length(global.alchemist_items); i++)
			{
				var shop_item = global.alchemist_items[i]
				array_push(new_alchemist_items_array, shop_item.id_name)
			}
			global.alchemist_items = new_alchemist_items_array
			global.alchemist_told_dialog = []
			transition_to_alchemist_fight()
			break
		case "boss_battle":
			transition_to_boss()
			break
		case "player_lose_control":
			with obj_fight_player
			{
				pissed_off = true
			}
			break
		case "alchemist_boost_0":
			global.alchemist_anger = -1
			global.player_money_boost += 5
			global.upgrade_description = "midas_bottle"
			break
		case "midas":
			global.midas_state = 1
			break
		case "finale_cycle_appear":
			trigger("delete_uistuff")
			instance_create_layer(1184, 288, "Instances", obj_shop_cycle_finale)
			break
		case "finale_midas_appear":
			trigger("delete_uistuff")
			instance_create_layer(520, 320, "Instances", obj_shop_midas_finale)
			break
		case "finale_change_appear":
			trigger("delete_uistuff")
			instance_create_layer(160, 288, "Instances", obj_shop_change_finale)
			break
		case "finale_death_appear":
			trigger("delete_uistuff")
			instance_create_layer(448, 352, "Instances", obj_shop_death_finale)
			break
		case "finale_heretics_appear":
			instance_create_layer(64, 352, "Instances", obj_shop_shopkeeper_finale)
			instance_create_layer(224, 352, "Instances", obj_shop_heretic_finale)
			break
		case "shopkeeper_pay_debt_prompt":
			var xcoord = 683
			var ycoord = 384
			create_settings_box(xcoord, ycoord - 20, 3, 1)
			instance_create_depth(xcoord - 192, ycoord, depth - 11, obj_button_refuse_debt)
			instance_create_depth(xcoord + 192, ycoord, depth - 11, obj_button_pay_debt)
			var text = instance_create_depth(xcoord, ycoord - 108, depth - 11, obj_text)
			text.text = "Pay " + string(global.shopkeeper_debt) + " coins?"
			text.scale = 0.1875
			break
		case "shopkeeper_reset_sus":
			global.shopkeeper_debt = 0
			global.shopkeeper_knows = false
			global.shopkeeper_suspicion = 0
			break
		case "death_crawl_away":
			with obj_shop_boatperson
			{
				xstart += 1366
				hspeed += 10
			}
			with obj_button_parent
			{
				event_user(0)
			}
			instance_create_layer(683, 640, "Instances_UI", obj_button_altar_continue)
			break
		case "changetransform":
			trigger("delete_uistuff")
			audio_play_sound(snd_change_transform, 0, false)
			with obj_shop_change
			{
				instance_create_layer(x, y, "Instances", obj_shop_change_transformed)
				instance_destroy()
			}
			break
		case "changegoaway":
			with obj_shop_change
			{
				xstart += 1366
				hspeed += 10
			}
			with obj_shop_change_transformed
			{
				ystart -= 768
				vspeed -= 10
			}
			if room == rom_change
			{
				trigger("delete_uistuff")
				instance_create_layer(683, 544, "Instances_UI", obj_button_altar_continue)
			}
			break
		case "midasgoaway":
			with obj_shop_midas_finale
			{
				xstart -= 1366
				hspeed -= 10
			}
			var button = instance_create_layer(160, 672, "Instances_UI", obj_button_finale_leave)
			button.image_xscale = 0.75
			button.image_yscale = 0.75
			instance_create_layer(683, 384, "Instances_UI", obj_button_finale_fight)
			break
		case "spawn fearspirit":
			scr_battle_spawn(obj_fight_spirit_fear)
			obj_fight_spirit_fear.is_spawning = false
			if global.battle_song_played != undefined and audio_is_playing(global.battle_song_played)
			{
				audio_stop_sound(global.battle_song_played)
			}
			global.battle_song_played = audio_play_sound(mus_doppleganger_fight, 1, true, 0)
			audio_sound_gain(global.battle_song_played, 0.6, 1000)
			break
		case "change_battle":
			transition_to_change_fight()
			break
		case "death_battle":
			transition_to_death_fight()
			break
		case "main_menu_quit":
			transition_to_main_menu()
			break
		case "mute_everything":
			if global.battle_song_played != undefined and audio_is_playing(global.battle_song_played)
			{
				audio_sound_gain(global.battle_song_played, 0, 1000)
			}
			if global.area_song_played != undefined and audio_is_playing(global.area_song_played)
			{
				audio_sound_gain(global.area_song_played, 0, 1000)
			}
			if global.npc_song_played != undefined and audio_is_playing(global.npc_song_played)
			{
				audio_sound_gain(global.npc_song_played, 0, 1000)
			}
			if global.area_ambiance_played != undefined and audio_is_playing(global.area_ambiance_played)
			{
				audio_sound_gain(global.area_ambiance_played, 0, 1000)
			}
			if global.panic_ambiance_played != undefined and audio_is_playing(global.panic_ambiance_played)
			{
				audio_sound_gain(global.panic_ambiance_played, 0, 1000)
			}
			if global.rain_ambiance_played != undefined and audio_is_playing(global.rain_ambiance_played)
			{
				audio_sound_gain(global.rain_ambiance_played, 0, 1000)
			}
			if global.blizzard_ambiance_played != undefined and audio_is_playing(global.blizzard_ambiance_played)
			{
				audio_sound_gain(global.blizzard_ambiance_played, 0, 1000)
			}
			if global.sandstorm_ambiance_played != undefined and audio_is_playing(global.sandstorm_ambiance_played)
			{
				audio_sound_gain(global.sandstorm_ambiance_played, 0, 1000)
			}
			break
		case "delete_uistuff":
			with (obj_button_parent)
			{
				event_user(0)
			}
			with (obj_settings_box)
			{
				event_user(0)
			}
			with (obj_slider_parent)
			{
				event_user(0)
			}
			with (obj_text)
			{
				event_user(0)
			}
			break
		case "end_battle":
			with obj_fight_turn_manager
			{
				force_win = true
			}
			break
		case "whistle that summons a heretic":
			audio_play_sound(snd_whistle, 0, false)
			var brin = instance_create_layer(1000, 416, "Instances", obj_shop_heretic_brin_intro)
			brin.xstart = 896
			break
		case "heretic_tutorial_fight":
			transition_to_heretic_tutorial_fight()
			break
		case "brin_escape":
			with obj_fight_heretic_brin_ally
			{
				escaping = true
			}
			global.is_turn = true
			break
		case "transition_balance":
			transition_to_balance()
			break
	}
}

function lower_ui_layer(value = undefined)
{
	if value == undefined
	{
		with (obj_button_parent)
		{
			if ui_layer == global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_settings_box)
		{
			if ui_layer == global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_slider_parent)
		{
			if ui_layer == global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_text)
		{
			if ui_layer == global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_item_box_fight)
		{
			if ui_layer == global.current_ui_layer
			{
				destroy_self = true
			}
		}
		global.current_ui_layer -= 1
	}
	else
	{
		global.current_ui_layer = value
		with (obj_button_parent)
		{
			if ui_layer > global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_settings_box)
		{
			if ui_layer > global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_slider_parent)
		{
			if ui_layer > global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_text)
		{
			if ui_layer > global.current_ui_layer
			{
				event_user(0)
			}
		}
		with (obj_item_box_fight)
		{
			if ui_layer > global.current_ui_layer
			{
				destroy_self = true
			}
		}
	}
}

function xp_needed(level = 0)
{
	var xp = round(15 * power(1.4, level))
	return xp
}

function level_up()
{
	global.player_max_hp += 5
	global.player_dmg += 1
	global.player_base_defense += 1
	global.player_crit_chance += 0.02
	global.player_base_magic_defense += 1
	if global.player_level == 3
	{
		if not(is_inside_array("magic_defend", global.player_skills)) and global.player_current_skill_0 != "magic_defend" and global.player_current_skill_1 != "magic_defend"
		{
			array_push(global.player_skills, "magic_defend")
			global.skill_tutorial = 0
		}
	}
	if global.player_level == 6
	{
		if not(is_inside_array("cleanse", global.player_skills)) and global.player_current_skill_0 != "cleanse" and global.player_current_skill_1 != "cleanse"
		{
			array_push(global.player_skills, "cleanse")
			global.skill_tutorial = 0
		}
	}
}

function arrays_identical(array1, array2)
{
    if array_length(array1) != array_length(array2)
	{
		return false
	}
    
    for (var i = 0; i < array_length(array1); i++)
	{
		if is_array(array1[i]) and is_array(array2[i])
		{
			if not(arrays_identical(array1[i], array2[i]))
			{
				return false
			}
		}
        else if array1[i] != array2[i]
		{
			return false
		}
    }
    
    return true
}

function variables_identical(var1, var2)
{
	if is_array(var1) and is_array(var2)
	{
		if not(arrays_identical(var1, var2))
		{
			return false
		}
	}
	else if var1 != var2
	{
		return false
	}
	
	return true
}

function is_inside_array(variable, array)
{
	for (var i = 0; i < array_length(array); i++)
	{
		if variables_identical(array[i], variable)
		{
			return true
		}
	}
	return false
}

function key_to_text(keybind)
{
	var text = "?"
	if keybind == undefined
	{
		text = "None"
	}
	else if (keyboard_get_map(keybind) >= 65 and keyboard_get_map(keybind) <= 90) or (keyboard_get_map(keybind) >= 48 and keyboard_get_map(keybind) <= 58)
	{
		text = chr(keyboard_get_map(keybind))
	}
	else if keybind == vk_space
	{
		text = "Space"
	}
	else if keybind == vk_right
	{
		text = ">"
	}
	else if keybind == vk_left
	{
		text = "<"
	}
	else if keybind == vk_up
	{
		text = "^"
	}
	else if keybind == vk_down
	{
		text = "v"
	}
	return text
}

function choose_weighted(items, weights)
{
    var total = 0
    for (var i = 0; i < array_length(weights); i++)
	{
        total += weights[i]
    }
	if total <= 0
	{
		var max_weight = -2147483648
		for (var i = 0; i < array_length(weights); i++)
		{
			if weights[i] > max_weight
			{
				max_weight = weights[i]
			}
		}
		for (var i = 0; i < array_length(weights); i++)
		{
			weights[i] += 1 - max_weight
		}
	}

    var epic_random_value = random(total)
    var sum = 0

    for (var i = 0; i < array_length(weights); i++)
	{
        sum += weights[i]
        if (epic_random_value < sum)
		{
            return items[i]
        }
    }
}

function ds_map_copy_fully(original_map)
{
    var new_map = ds_map_create()
    var keys = ds_map_keys_to_array(original_map)
    for (var i = 0; i < array_length(keys); i++)
	{
        var key = keys[i]
        var value = original_map[? key]
        ds_map_add(new_map, key, value)
    }
    return new_map
}

function scr_tile_key(vx, vy, vlayer)
{
	return string(floor(vx)) + "_" + string(floor(vy)) + "_" + string(floor(vlayer))
}